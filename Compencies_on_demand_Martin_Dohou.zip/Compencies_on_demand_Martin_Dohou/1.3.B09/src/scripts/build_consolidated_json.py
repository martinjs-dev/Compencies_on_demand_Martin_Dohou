#!/usr/bin/env python3
"""
Construit qcms_data/qcms.consolidated.json a partir de :
  - qcms_data/docs/questions.md          source primaire (930 questions au format propre)
  - qcms_data/manual-overrides.json      overrides pour cas speciaux
                                         (questions a options visuelles, bugs source)
  - qcms_data/qcms_images/*              images attachees aux questions (jpeg/jpg/png/webp)
  - qcms_data/qcms_audios/{lang}/*        audios par langue (mp3/m4a/ogg/opus/wav/webm)

Sorties :
  - qcms_data/qcms.consolidated.json     dataset final (930 questions)
  - qcms_data/data-issues-report.json    rapport audit/anomalies

Usage :
  python3 scripts/qcms/build_consolidated_json.py
  python3 scripts/qcms/build_consolidated_json.py --carry-over

Mode ADDITIF (--carry-over) : pour chaque couple (question, langue) SANS fichier
audio local, reporte la reference audio du qcms.consolidated.json precedent. Sert
a ne pas effacer une langue (ex: fon) ou des numeros absents du scan local mais
deja references/en prod. Sans ce drapeau, seuls les audios presents localement
sont retenus (comportement historique, plein regen).
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

# Reutiliser le parser questions.md
sys.path.insert(0, str(Path(__file__).parent))
from validate_against_md import parse_md_questions

ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT / "qcms_data"
SOURCE_MD = DATA_DIR / "docs" / "questions.md"
OVERRIDES_JSON = DATA_DIR / "manual-overrides.json"
OUTPUT_JSON = DATA_DIR / "qcms.consolidated.json"
ISSUES_JSON = DATA_DIR / "data-issues-report.json"

IMAGES_DIR = DATA_DIR / "qcms_images"
AUDIOS_DIR = DATA_DIR / "qcms_audios"
# Doit rester aligne sur `prisma/seeds/languages.seed.ts` (langues actives).
# `ditamari` (8e langue nationale) manquait ici alors qu'elle est seedee et
# presente en base : ses audios etaient donc ignores a la consolidation.
LANGUAGES = [
    "fr",
    "fon",
    "goun",
    "bariba",
    "dendi",
    "mina",
    "yoruba",
    "adja",
    "ditamari",
]

S3_BUCKET = "pbj-private"
# Le backend est AGNOSTIQUE au format image (cf. IMAGE_EXTENSION_BY_MIMETYPE
# dans questions.service.ts, qui accepte deja jpeg/jpg/png/webp) : la cle S3
# porte l'extension reelle du fichier local (`{ext}` = suffixe avec point, ex
# ".webp"). Ordre de PREFERENCE quand plusieurs formats coexistent pour un
# meme numero (migration jpeg -> webp, memes principe que AUDIO_EXTENSIONS).
IMAGE_EXTENSIONS = [".webp", ".jpeg", ".jpg", ".png"]
S3_KEY_IMAGE = "questions/images/q-{number:03d}{ext}"
# Le backend est AGNOSTIQUE au format audio : la cle S3 porte l'extension reelle
# du fichier (`{ext}` = suffixe avec point, ex ".m4a"). Ordre de PREFERENCE
# quand plusieurs formats coexistent pour un meme numero (migration mp3 -> m4a).
AUDIO_EXTENSIONS = [".m4a", ".mp3", ".ogg", ".opus", ".aac", ".wav", ".webm"]
S3_KEY_AUDIO = "questions/audios/{lang}/q-{number:03d}{ext}"
S3_KEY_OPTION_IMAGE = "questions/images/options/q-{number:03d}/q-{number:03d}_{letter}.png"
OPTION_PLACEHOLDER_LOCAL = "qcms_images/options/placeholder.png"

# Themes avec leurs plages de numeros.
# ALIGNE sur prisma/seeds/data/qcms.consolidated.json committe + themes.data.ts
# + bornes ADR-044 §15 (CHAPTER_BOUNDS_BY_JSON_THEME_ID de referentiel.spec.ts).
# Le theme 1 "Generalites" (chapitre I du manuel) ne porte AUCUNE question :
# plage vide (0, -1) -> theme_for ne le renvoie jamais, mais il figure dans
# themes[] avec questionCount 0. Les questions portent donc themeId 2-11 (JAMAIS
# 1). NE PAS revenir a une numerotation 1-10 : cela reverte l'alignement (le
# theme Generalites a ete introduit, cf. project_audio_format_agnostic_migration).
THEMES: list[dict[str, Any]] = [
    {"id": 1, "code": "01/11", "title": "Generalites",
     "subtitle": "Abreviations, definitions, familles de panneaux, balises, vehicules prioritaires et categories de permis",
     "range": (0, -1)},
    {"id": 2, "code": "02/11", "title": "Signalisations",
     "subtitle": "Signalisation horizontale, verticale, lumineuse et signes des agents de securite",
     "range": (1, 205)},
    {"id": 3, "code": "03/11", "title": "Regles de priorite, depassement et croisement",
     "range": (206, 359)},
    {"id": 4, "code": "04/11", "title": "Arret, stationnement, vitesse et manoeuvres",
     "range": (360, 404)},
    {"id": 5, "code": "05/11", "title": "Route pour automobile et autoroute",
     "range": (405, 507)},
    {"id": 6, "code": "06/11", "title": "Infractions, incivisme et secourisme",
     "range": (508, 645)},
    {"id": 7, "code": "07/11", "title": "Permis A1, A2, A3 - Motocyclettes",
     "range": (646, 678), "permitTypes": ["A1", "A2", "A3"]},
    {"id": 8, "code": "08/11", "title": "Permis B - Voiture de tourisme",
     "range": (679, 688), "permitTypes": ["B"]},
    {"id": 9, "code": "09/11", "title": "Permis C et C1 - Poids lourds",
     "range": (689, 738), "permitTypes": ["C", "C1"]},
    {"id": 10, "code": "10/11", "title": "Permis D - Transport en commun",
     "range": (739, 799), "permitTypes": ["D"]},
    {"id": 11, "code": "11/11", "title": "Equipement, entretien et documents administratifs",
     "subtitle": "Moteur, freins, pneumatiques, feux, documents, entretien courant",
     "range": (800, 930)},
]


@dataclass
class Issue:
    number: int
    themeId: int
    kind: str
    detail: str


@dataclass
class AssetRef:
    localPath: str
    s3Key: str
    exists: bool


def theme_for(number: int) -> dict[str, Any] | None:
    for t in THEMES:
        if t["range"][0] <= number <= t["range"][1]:
            return t
    return None


def collect_asset_indexes() -> tuple[dict[int, str], dict[str, dict[int, str]]]:
    # number -> extension reelle (avec point). Si plusieurs formats coexistent
    # pour un meme numero, on garde le plus prioritaire (IMAGE_EXTENSIONS).
    image_ext_rank = {ext: i for i, ext in enumerate(IMAGE_EXTENSIONS)}
    image_exts: dict[int, str] = {}
    if IMAGES_DIR.is_dir():
        for p in IMAGES_DIR.iterdir():
            suffix = p.suffix.lower()
            if suffix not in image_ext_rank:
                continue
            try:
                num = int(p.stem)
            except ValueError:
                continue
            current = image_exts.get(num)
            if current is None or image_ext_rank[suffix] < image_ext_rank[current]:
                image_exts[num] = suffix

    # number -> extension reelle (avec point). Si plusieurs formats coexistent
    # pour un meme numero, on garde le plus prioritaire (AUDIO_EXTENSIONS).
    ext_rank = {ext: i for i, ext in enumerate(AUDIO_EXTENSIONS)}
    audio_exts: dict[str, dict[int, str]] = {lang: {} for lang in LANGUAGES}
    for lang in LANGUAGES:
        lang_dir = AUDIOS_DIR / lang
        if not lang_dir.is_dir():
            continue
        for p in lang_dir.iterdir():
            suffix = p.suffix.lower()
            if suffix not in ext_rank:
                continue
            try:
                num = int(p.stem)
            except ValueError:
                continue
            current = audio_exts[lang].get(num)
            if current is None or ext_rank[suffix] < ext_rank[current]:
                audio_exts[lang][num] = suffix
    return image_exts, audio_exts


def load_overrides() -> dict[int, dict[str, Any]]:
    if not OVERRIDES_JSON.is_file():
        return {}
    with OVERRIDES_JSON.open(encoding="utf-8") as f:
        data = json.load(f)
    return {int(k): v for k, v in data.get("overrides", {}).items()}


def apply_override(
    question: dict[str, Any],
    override: dict[str, Any],
    issues: list[Issue],
) -> dict[str, Any]:
    action = override.get("action")
    number = question["number"]
    theme_id = question["themeId"]
    reason = override.get("reason", "")

    if action == "mark-visual":
        count = int(override.get("visualOptionsCount", 4))
        letters = list("ABCDE")[:count]
        if "statement" in override:
            question["statement"] = override["statement"]
        if "correctAnswers" in override:
            question["correctAnswers"] = override["correctAnswers"]
        question["options"] = [{"letter": ltr, "text": None} for ltr in letters]
        question["hasVisualOptions"] = True
        question["visualOptionsCount"] = count
        question["overrideApplied"] = "mark-visual"
        issues.append(Issue(number, theme_id, "override_visual",
                            reason or "options visuelles (planche d'images)"))
        return question

    if action == "flag-source-bug":
        if "correctAnswers" in override:
            question["correctAnswers"] = override["correctAnswers"]
        question["sourceBug"] = True
        question["sourceBugReason"] = reason
        question["overrideApplied"] = "flag-source-bug"
        issues.append(Issue(number, theme_id, "override_source_bug",
                            reason or "bug du manuel source"))
        return question

    issues.append(Issue(number, theme_id, "override_unknown_action",
                        f"Action non geree : {action}"))
    return question


def build_question(
    number: int,
    md_q: Any,
    image_exts: dict[int, str],
    audio_exts: dict[str, dict[int, str]],
    issues: list[Issue],
    carry_audios: dict[int, dict[str, dict[str, Any]]] | None = None,
) -> dict[str, Any] | None:
    theme = theme_for(number)
    if theme is None:
        issues.append(Issue(number, 0, "no_theme",
                            f"Numero {number} hors plage des themes 1-930"))
        return None

    image_ref: dict[str, Any] | None = None
    image_ext = image_exts.get(number)
    if image_ext:
        image_ref = asdict(AssetRef(
            localPath=f"qcms_images/{number}{image_ext}",
            s3Key=S3_KEY_IMAGE.format(number=number, ext=image_ext),
            exists=True,
        ))

    audios: dict[str, dict[str, Any]] = {}
    for lang in LANGUAGES:
        ext = audio_exts.get(lang, {}).get(number)
        if ext:
            audios[lang] = asdict(AssetRef(
                localPath=f"qcms_audios/{lang}/{number:03d}{ext}",
                s3Key=S3_KEY_AUDIO.format(lang=lang, number=number, ext=ext),
                exists=True,
            ))
        elif carry_audios:
            # Mode additif : aucun fichier local pour ce (numero, langue), mais
            # une reference existait dans le JSON precedent -> on la conserve
            # telle quelle (ex: fon sans .mp3 en local, deja en prod).
            prev = carry_audios.get(number, {}).get(lang)
            if prev is not None:
                audios[lang] = prev

    if "fr" not in audios:
        issues.append(Issue(number, theme["id"], "audio_fr_missing",
                            f"Pas d'audio fr pour q-{number:03d} "
                            f"(formats acceptes : {', '.join(AUDIO_EXTENSIONS)})"))

    # Detection automatique des options visuelles : toutes les options sont "(image)"
    options = list(md_q.options)
    has_visual = bool(options) and all(o["text"] == "(image)" for o in options)
    if has_visual:
        options = [
            {
                "letter": o["letter"],
                "text": None,
                # `localPath` pointe vers un PLACEHOLDER LOCAL partage (image
                # generique en attente d'extraction), jamais vers le fichier
                # reel de l'option - `s3Key` designe une cle par-question/
                # par-lettre qui n'a JAMAIS ete televersee a ce nom. Marquer
                # `exists=True` ici a fige 58 cles fantomes dans le bucket de
                # prod (questions 123, 165, 341-348, 350, 626, 912 : incident
                # 2026-09-27, manifeste media servant des cles absentes du
                # bucket en boucle). `exists=False` tant que l'extraction
                # reelle de l'image de l'option n'a pas eu lieu.
                "image": asdict(AssetRef(
                    localPath=OPTION_PLACEHOLDER_LOCAL,
                    s3Key=S3_KEY_OPTION_IMAGE.format(
                        number=number, letter=o["letter"].lower(),
                    ),
                    exists=False,
                )),
            }
            for o in options
        ]

    question: dict[str, Any] = {
        "number": number,
        "themeId": theme["id"],
        "statement": md_q.statement,
        "options": options,
        "correctAnswers": md_q.correct_answers,
        "image": image_ref,
        "audios": audios,
    }
    if has_visual:
        question["hasVisualOptions"] = True
        question["visualOptionsCount"] = len(options)
    if "permitTypes" in theme:
        question["permitTypes"] = theme["permitTypes"]

    # Audit : verifier que les correctAnswers sont valides vs options
    valid_letters = {o["letter"] for o in question["options"]}
    if question["options"] and any(a not in valid_letters for a in question["correctAnswers"]):
        issues.append(Issue(number, theme["id"], "correct_answer_out_of_range",
                            f"reponses {question['correctAnswers']} vs options {sorted(valid_letters)}"))
    if not question["correctAnswers"]:
        issues.append(Issue(number, theme["id"], "correct_answers_empty",
                            "Aucune reponse correcte trouvee"))

    return question


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Construit qcms_data/qcms.consolidated.json.",
    )
    parser.add_argument(
        "--carry-over",
        action="store_true",
        help=(
            "Mode additif : reporte du JSON precedent les audios (question, "
            "langue) absents du scan local (ex: fon). Sinon, plein regen."
        ),
    )
    args = parser.parse_args()

    if not SOURCE_MD.is_file():
        print(f"[ERROR] Source introuvable : {SOURCE_MD}", file=sys.stderr)
        return 1

    carry_audios: dict[int, dict[str, dict[str, Any]]] = {}
    if args.carry_over:
        if OUTPUT_JSON.is_file():
            prev = json.loads(OUTPUT_JSON.read_text(encoding="utf-8"))
            for q in prev.get("questions", []):
                a = q.get("audios") or {}
                if a:
                    carry_audios[q["number"]] = a
            print(
                f"Mode additif : {OUTPUT_JSON.name} precedent charge "
                f"({sum(len(v) for v in carry_audios.values())} refs reportables)"
            )
        else:
            print(
                f"[WARN] --carry-over demande mais {OUTPUT_JSON.name} absent : "
                "rien a reporter (plein regen)."
            )

    print(f"Lecture {SOURCE_MD.relative_to(ROOT)}...")
    md_text = SOURCE_MD.read_text(encoding="utf-8")
    md_questions = parse_md_questions(md_text)
    print(f"  {len(md_questions)} questions extraites")

    overrides = load_overrides()
    if overrides:
        print(f"Chargement {OVERRIDES_JSON.name} : {len(overrides)} overrides")

    print("Indexation des assets locaux...")
    image_exts, audio_exts = collect_asset_indexes()
    print(f"  images: {len(image_exts)} | audios: "
          + ", ".join(f"{lang}={len(nums)}" for lang, nums in audio_exts.items()))

    questions: list[dict[str, Any]] = []
    issues: list[Issue] = []
    overridden_numbers: dict[int, str] = {}

    for number in sorted(md_questions.keys()):
        q = build_question(
            number, md_questions[number], image_exts, audio_exts, issues,
            carry_audios if args.carry_over else None,
        )
        if q is None:
            continue
        if number in overrides:
            q = apply_override(q, overrides[number], issues)
            overridden_numbers[number] = overrides[number].get("action", "?")
        questions.append(q)

    # Suppression des issues "correct_answer_out_of_range" remplacees par flag-source-bug
    # (le bug est documente via override_source_bug, pas besoin de doubler)
    flagged_bugs = {n for n, a in overridden_numbers.items() if a == "flag-source-bug"}
    issues = [it for it in issues
              if not (it.kind == "correct_answer_out_of_range" and it.number in flagged_bugs)]

    # Orphelins : assets dont le numero n'est pas dans questions.md
    seen = {q["number"] for q in questions}
    # Les questions 931+ partagent les memes dossiers d'assets mais sont
    # decrites par prisma/seeds/data/qcms.nouveaux.json (build_nouveaux_json.py) :
    # leurs fichiers ont une question, simplement pas dans ce fichier-ci. Les
    # compter en orphelins ferait mentir le rapport et les reuploaderait sous
    # l'etiquette d'orphelins.
    nouveaux = ROOT / "prisma" / "seeds" / "data" / "qcms.nouveaux.json"
    if nouveaux.is_file():
        seen |= {q["number"] for q in json.loads(nouveaux.read_text(encoding="utf-8"))["questions"]}
    orphan_images = sorted(n for n in image_exts if n not in seen)
    # (number, extension) des audios dont le numero n'est pas dans questions.md
    orphan_audios: dict[str, list[tuple[int, str]]] = {}
    for lang, exts in audio_exts.items():
        items = sorted((n, e) for n, e in exts.items() if n not in seen)
        if items:
            orphan_audios[lang] = items

    # Themes meta
    themes_meta: list[dict[str, Any]] = []
    for t in THEMES:
        nums = sorted(q["number"] for q in questions if q["themeId"] == t["id"])
        meta = {
            "id": t["id"],
            "code": t["code"],
            "title": t["title"],
            "questionCount": len(nums),
            "questionRange": {"from": nums[0], "to": nums[-1]} if nums else None,
        }
        if "subtitle" in t:
            meta["subtitle"] = t["subtitle"]
        if "permitTypes" in t:
            meta["permitTypes"] = t["permitTypes"]
        themes_meta.append(meta)

    counts_by_lang = {lang: sum(1 for q in questions if lang in q["audios"]) for lang in LANGUAGES}
    by_action: dict[str, int] = {}
    for action in overridden_numbers.values():
        by_action[action] = by_action.get(action, 0) + 1

    consolidated: dict[str, Any] = {
        "metadata": {
            "source": "Manuel du Candidat a l'Examen du Permis de Conduire - Edition 2011 (Benin)",
            "generatedFrom": str(SOURCE_MD.relative_to(ROOT)),
            "country": "BJ",
            "totalThemes": len(themes_meta),
            "totalQuestions": len(questions),
            "languages": LANGUAGES,
            "defaultLanguage": "fr",
            "minio": {
                "bucket": S3_BUCKET,
                "imageKeyPattern": S3_KEY_IMAGE,
                "audioKeyPattern": S3_KEY_AUDIO,
            },
            "assetCoverage": {
                "imagesAttached": sum(1 for q in questions if q["image"]),
                "audioByLanguage": counts_by_lang,
            },
            "overridesApplied": {
                "total": len(overridden_numbers),
                "byAction": by_action,
                "source": OVERRIDES_JSON.name if overrides else None,
            },
        },
        "themes": themes_meta,
        "questions": questions,
        "orphanAssets": {
            "images": [
                {"number": n, "localPath": f"qcms_images/{n}{image_exts[n]}",
                 "s3Key": S3_KEY_IMAGE.format(number=n, ext=image_exts[n])}
                for n in orphan_images
            ],
            "audios": {
                lang: [
                    {"number": n,
                     "localPath": f"qcms_audios/{lang}/{n:03d}{ext}",
                     "s3Key": S3_KEY_AUDIO.format(lang=lang, number=n, ext=ext)}
                    for n, ext in items
                ]
                for lang, items in orphan_audios.items()
            },
        },
    }

    OUTPUT_JSON.write_text(
        json.dumps(consolidated, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"[OK] {OUTPUT_JSON.relative_to(ROOT)} ({len(questions)} questions)")

    issues_payload: dict[str, Any] = {
        "summary": {"total": len(issues), "byKind": {}},
        "items": [asdict(i) for i in issues],
    }
    for it in issues:
        issues_payload["summary"]["byKind"][it.kind] = (
            issues_payload["summary"]["byKind"].get(it.kind, 0) + 1
        )
    ISSUES_JSON.write_text(
        json.dumps(issues_payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"[OK] {ISSUES_JSON.relative_to(ROOT)} ({len(issues)} entrees)")
    print("Resume :")
    for kind, count in sorted(issues_payload["summary"]["byKind"].items()):
        print(f"  - {kind}: {count}")
    print(f"Orphelins : images={len(orphan_images)}, "
          f"audios={ {lang: len(nums) for lang, nums in orphan_audios.items()} }")

    if args.carry_over:
        carried_by_lang: dict[str, int] = {}
        for q in questions:
            for lang in q.get("audios") or {}:
                if audio_exts.get(lang, {}).get(q["number"]) is None:
                    carried_by_lang[lang] = carried_by_lang.get(lang, 0) + 1
        print(f"Reportes du JSON precedent (additif) : "
              f"{dict(sorted(carried_by_lang.items())) or '(aucun)'}")
    print(f"Couverture audio finale : {dict(sorted(counts_by_lang.items()))}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
