#!/usr/bin/env python3
"""
Manuel complet des questions du code de la route (Benin), dans la
numerotation officielle, images et reponses comprises.

Sources, toutes versionnees dans le depot, aucune base de donnees :
  prisma/seeds/data/qcms.consolidated.json  -> questions 1 a 930 (manuel 2011)
  prisma/seeds/data/qcms.nouveaux.json      -> questions 931 a 1578 (sortie de
                                               build_nouveaux_json.py, c'est
                                               elle qui porte la numerotation
                                               officielle et les reponses)
  prisma/seeds/data/numeros-nouveaux.json   -> table de correspondance
  qcms_data/qcms_images/<numero>.webp       -> illustrations

⛔ NE PAS repartir de qcms.consolidated.avec-nouveaux.json : c'est le fichier
d'ENTREE de la renumerotation, ses numeros 931+ sont ceux d'origine. 644 de ses
648 enonces ne correspondent plus au numero qu'ils portent.

Sortie : un HTML autonome, converti en PDF par Chrome.
"""

from __future__ import annotations

import html
import json
from pathlib import Path

from PIL import Image

RACINE = Path("/home/martin-js/Martin_JS/Permis-BJ/Code/pbj-backend")
DATA = RACINE / "prisma/seeds/data"
IMAGES_SRC = RACINE / "qcms_data/qcms_images"
SORTIE = Path(
    "/tmp/claude-1000/-home-martin-js-Martin-JS-Permis-BJ-Code/"
    "b868616a-8283-4139-b62b-f5a63e761562/scratchpad/manuel"
)
IMAGES_OUT = SORTIE / "img"

LARGEUR_MAX = 560

# Les jeux de donnees sont ecrits sans accents (convention du depot). Un
# document destine a la lecture, lui, les porte.
TITRES_MANUEL = {
    1: "Généralités",
    2: "Signalisations",
    3: "Règles de priorité, dépassement et croisement",
    4: "Arrêt, stationnement, vitesse et manœuvres",
    5: "Route pour automobile et autoroute",
    6: "Infractions, incivisme et secourisme",
    7: "Permis A1, A2, A3 - Motocyclettes",
    8: "Permis B - Voiture de tourisme",
    9: "Permis C et C1 - Poids lourds",
    10: "Permis D - Transport en commun",
    11: "Équipement, entretien et documents administratifs",
}

TITRES_NOUVEAUX = {
    "circulation": "Circulation",
    "conducteur": "Le conducteur",
    "diverses": "Questions diverses",
    "environnement": "Environnement",
    "mecanique": "Mécanique",
    "route": "La route",
    "secours": "Secours",
    "securite": "Sécurité",
    "vehicules": "Les véhicules",
}

options_illustrees: dict[tuple[int, str], str] = {}


def scanner_options() -> None:
    dossier = SORTIE / "opt"
    if not dossier.exists():
        return
    for fichier in dossier.iterdir():
        tige = fichier.stem
        if "_" not in tige:
            continue
        numero, lettre = tige.split("_", 1)
        if numero.isdigit():
            options_illustrees[(int(numero), lettre)] = fichier.name


def charger() -> tuple[list[dict], list[dict], dict[str, int]]:
    manuel = json.loads((DATA / "qcms.consolidated.json").read_text(encoding="utf-8"))
    nouveaux = json.loads((DATA / "qcms.nouveaux.json").read_text(encoding="utf-8"))
    numeros = json.loads((DATA / "numeros-nouveaux.json").read_text(encoding="utf-8"))

    anciennes = sorted(manuel["questions"], key=lambda q: q["number"])
    recentes = sorted(nouveaux["questions"], key=lambda q: q["number"])
    return anciennes, recentes, numeros["attribution"]


def preparer_images(questions: list[dict]) -> dict[int, str]:
    IMAGES_OUT.mkdir(parents=True, exist_ok=True)
    trouvees: dict[int, str] = {}
    manquantes: list[int] = []

    for q in questions:
        if not q.get("image"):
            continue
        numero = q["number"]
        candidats = sorted(IMAGES_SRC.glob(f"{numero}.*"))
        if not candidats:
            manquantes.append(numero)
            continue

        destination = IMAGES_OUT / f"{numero}.jpg"
        if not destination.exists():
            with Image.open(candidats[0]) as im:
                im = im.convert("RGB")
                if im.width > LARGEUR_MAX:
                    hauteur = round(im.height * LARGEUR_MAX / im.width)
                    im = im.resize((LARGEUR_MAX, hauteur), Image.LANCZOS)
                im.save(destination, "JPEG", quality=84, optimize=True)
        trouvees[numero] = destination.name

    if manquantes:
        print(f"  images introuvables : {len(manquantes)} -> {manquantes[:10]}")
    return trouvees


def lettres(reponses: list[str]) -> str:
    return " - ".join(r.lower() for r in reponses)


def bloc_question(q: dict, images: dict[int, str]) -> str:
    numero = q["number"]
    morceaux = [f'<article class="q" id="q{numero}">']

    if numero in images:
        morceaux.append(
            f'<img class="illus" src="img/{images[numero]}" '
            f'alt="Illustration de la question {numero}">'
        )

    morceaux.append(f"<h3>Question n° {numero}</h3>")
    morceaux.append(f'<p class="enonce">{html.escape(q["statement"])}</p>')

    morceaux.append('<ol class="options">')
    for option in q["options"]:
        texte = option.get("text")
        if texte:
            morceaux.append(f"<li>{html.escape(texte)}</li>")
            continue
        # Option purement visuelle (planche de panneaux). Son image dediee
        # n'existe sur S3 que pour une poignee de questions ; ailleurs, la
        # planche complete figure dans l'illustration de la question.
        vignette = options_illustrees.get((numero, option["letter"].lower()))
        if vignette:
            morceaux.append(
                f'<li class="visuelle"><img src="opt/{vignette}" '
                f'alt="Option {option["letter"].lower()}"></li>'
            )
        else:
            morceaux.append('<li class="visuelle vide">panneau illustré ci-contre</li>')
    morceaux.append("</ol>")

    reponses = q.get("correctAnswers") or []
    if reponses:
        etiquette = "Réponses" if len(reponses) > 1 else "Réponse"
        morceaux.append(
            f'<p class="reponse">{etiquette} : <strong>{lettres(reponses)}</strong></p>'
        )
    else:
        morceaux.append('<p class="reponse manquante">Réponse à valider</p>')

    if q.get("explanation"):
        morceaux.append(f'<p class="explication">{html.escape(q["explanation"])}</p>')

    morceaux.append("</article>")
    return "\n".join(morceaux)


def bloc_correspondance(attribution: dict[str, int]) -> str:
    lignes = sorted(attribution.items(), key=lambda kv: kv[1])
    def lisible(chemin: str) -> str:
        morceaux = chemin.replace(".mp3", "").split("/")
        return " ".join(morceaux[1:]) if len(morceaux) > 1 else chemin

    cellules = [
        f'<li><span class="num">{numero}</span>'
        f'<span class="src">{html.escape(lisible(source))}</span></li>'
        for source, numero in lignes
    ]
    return (
        '<section class="chapitre annexe">'
        "<h2>Annexe - Table de correspondance des numéros 931 et suivants</h2>"
        '<p class="intro">Chaque question ajoutée après le manuel 2011 provient '
        "d'un enregistrement d'origine. Le tableau ci-dessous donne, pour chaque "
        "numéro officiel, le fichier dont la question est issue. Cette "
        "correspondance est figée : un numéro attribué ne sera jamais réattribué, "
        "car il vit dans les fichiers audio et image, dans la composition des "
        "sujets d'examen et sur les copies déjà rendues.</p>"
        f'<ol class="correspondance">{"".join(cellules)}</ol>'
        "</section>"
    )


CSS = """
@page { size: A4; margin: 16mm 14mm; }
* { box-sizing: border-box; }
body {
  font-family: Georgia, "Times New Roman", serif;
  font-size: 10.4pt; line-height: 1.42; color: #14181d; margin: 0;
  -webkit-print-color-adjust: exact; print-color-adjust: exact;
}
h1, h2, h3, .sans { font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; }

.couverture { height: 258mm; position: relative; page-break-after: always; padding-top: 62mm; text-align: center; }
.couverture .sur { font-size: 9.4pt; letter-spacing: .2em; text-transform: uppercase; color: #5b6673;
  font-family: "Helvetica Neue", Arial, sans-serif; }
.couverture h1 { font-size: 31pt; line-height: 1.1; margin: 12mm 0 5mm; letter-spacing: -.015em; }
.couverture .sous { font-size: 12.5pt; color: #3d4753; margin: 0 0 14mm; }
.couverture .filet { width: 42mm; height: 3px; background: #0f7a4d; margin: 0 auto 14mm; }
.couverture .chiffres { display: flex; justify-content: center; gap: 18mm; }
.couverture .chiffre b { display: block; font-size: 21pt; color: #0f7a4d;
  font-family: "Helvetica Neue", Arial, sans-serif; }
.couverture .chiffre span { font-size: 8.6pt; color: #5b6673; letter-spacing: .08em;
  text-transform: uppercase; font-family: "Helvetica Neue", Arial, sans-serif; }
.couverture .pied { position: absolute; bottom: 0; left: 0; right: 0;
  font-size: 9pt; color: #77828f; }

.liminaire { page-break-after: always; }
.liminaire h2 { font-size: 16pt; margin: 0 0 6mm; }
.liminaire p { margin: 0 0 4mm; max-width: 152mm; }
.encadre { border-left: 3px solid #0f7a4d; background: #f4f8f6; padding: 5mm 6mm; margin: 6mm 0; }
.encadre p:last-child { margin-bottom: 0; }

table.sommaire { width: 100%; border-collapse: collapse; margin-top: 3mm; }
table.sommaire th, table.sommaire td { text-align: left; padding: 2.2mm 2mm; border-bottom: 1px solid #dfe4ea; }
table.sommaire th { font-family: "Helvetica Neue", Arial, sans-serif; font-size: 8.4pt;
  text-transform: uppercase; letter-spacing: .08em; color: #5b6673; }
table.sommaire tr.partie td { background: #f4f8f6; font-family: "Helvetica Neue", Arial, sans-serif;
  font-size: 8.6pt; text-transform: uppercase; letter-spacing: .1em; color: #0f7a4d; padding-top: 3.4mm; }
table.sommaire td.plage, table.sommaire td.nb { font-variant-numeric: tabular-nums; white-space: nowrap; }
table.sommaire td.nb { text-align: right; }

.separateur { page-break-before: always; height: 245mm; display: flex; flex-direction: column;
  justify-content: center; text-align: center; }
.separateur .etiquette { font-family: "Helvetica Neue", Arial, sans-serif; font-size: 9pt;
  letter-spacing: .22em; text-transform: uppercase; color: #0f7a4d; margin-bottom: 6mm; }
.separateur h2 { font-size: 24pt; margin: 0 0 5mm; }
.separateur p { max-width: 128mm; margin: 0 auto; color: #3d4753; }

.chapitre { page-break-before: always; }
.chapitre > h2 { font-size: 15pt; margin: 0 0 1.5mm; padding-bottom: 2.5mm; border-bottom: 2px solid #0f7a4d; }
.chapitre .soustitre { font-size: 9.6pt; color: #5b6673; margin: 0 0 6mm; }

.q { page-break-inside: avoid; margin: 0 0 5.5mm; padding-bottom: 4mm;
  border-bottom: 1px solid #edf0f3; overflow: hidden; }
.q h3 { font-size: 9.2pt; letter-spacing: .05em; text-transform: uppercase; color: #0f7a4d; margin: 0 0 1.6mm; }
.q .enonce { margin: 0 0 2mm; font-weight: 700; }
.q .illus { float: right; width: 38mm; margin: 0 0 3mm 5mm; border: 1px solid #dfe4ea; border-radius: 2px; }
ol.options { margin: 0 0 2.4mm; padding-left: 7mm; list-style: lower-alpha; }
ol.options li { margin: 0 0 .8mm; }
ol.options li.visuelle img { height: 13mm; vertical-align: middle; border: 1px solid #dfe4ea;
  border-radius: 2px; padding: .6mm; background: #fff; }
ol.options li.visuelle.vide { color: #8d97a3; font-style: italic; }
.reponse { margin: 0; font-family: "Helvetica Neue", Arial, sans-serif; font-size: 9.4pt; color: #0f7a4d; }
.reponse.manquante { color: #b25000; }
.explication { margin: 1.6mm 0 0; font-size: 9.3pt; color: #3d4753;
  border-left: 2px solid #dfe4ea; padding-left: 3mm; }

.annexe .intro { max-width: 152mm; margin-bottom: 6mm; }
ol.correspondance { column-count: 3; column-gap: 8mm; list-style: none; margin: 0; padding: 0;
  font-size: 8.6pt; font-variant-numeric: tabular-nums; }
ol.correspondance li { break-inside: avoid; padding: .7mm 0; border-bottom: 1px solid #f0f2f5;
  display: flex; gap: 2.5mm; }
ol.correspondance .num { color: #0f7a4d; font-weight: 700; min-width: 11mm; }
ol.correspondance .src { color: #46505c; }
"""


def chapitres_manuel(anciennes: list[dict], images: dict[int, str]) -> tuple[str, list]:
    par_theme: dict[int, list[dict]] = {}
    for q in anciennes:
        par_theme.setdefault(q["themeId"], []).append(q)

    sections, sommaire = [], []
    for theme_id in sorted(par_theme):
        liste = sorted(par_theme[theme_id], key=lambda q: q["number"])
        titre = TITRES_MANUEL.get(theme_id, f"Chapitre {theme_id}")
        sommaire.append((titre, liste[0]["number"], liste[-1]["number"], len(liste)))
        sections.append(
            '<section class="chapitre"><h2>'
            + html.escape(titre)
            + "</h2>"
            + "\n".join(bloc_question(q, images) for q in liste)
            + "</section>"
        )
    return "".join(sections), sommaire


def chapitres_nouveaux(recentes: list[dict], images: dict[int, str]) -> tuple[str, list]:
    """Les questions 931+ restent dans l'ordre des numeros ; un intertitre
    marque chaque changement de theme, et les questions dont la reponse n'est
    pas confirmee sont regroupees en fin de serie."""
    sections, sommaire = [], []
    courant: str | None = None
    tampon: list[str] = []
    depart = fin = 0
    compte = 0

    def fermer() -> None:
        nonlocal tampon, courant, depart, fin, compte
        if not tampon:
            return
        titre = TITRES_NOUVEAUX.get(courant, courant or "")
        sommaire.append((titre, depart, fin, compte))
        sections.append(
            '<section class="chapitre"><h2>'
            + html.escape(titre)
            + "</h2>"
            + "".join(tampon)
            + "</section>"
        )
        tampon = []
        compte = 0

    for q in recentes:
        slug = q.get("themeSlug")
        if slug != courant:
            fermer()
            courant, depart = slug, q["number"]
        tampon.append(bloc_question(q, images))
        fin = q["number"]
        compte += 1
    fermer()
    return "".join(sections), sommaire


def construire_html(
    anciennes: list[dict],
    recentes: list[dict],
    attribution: dict[str, int],
    images: dict[int, str],
) -> str:
    corps_manuel, sommaire_manuel = chapitres_manuel(anciennes, images)
    corps_nouveaux, sommaire_nouveaux = chapitres_nouveaux(recentes, images)

    total = len(anciennes) + len(recentes)
    sans_reponse = sum(1 for q in recentes if not q.get("correctAnswers"))

    def rangs(entrees: list) -> str:
        return "".join(
            f"<tr><td>{html.escape(t)}</td>"
            f'<td class="plage">{a} à {b}</td>'
            f'<td class="nb">{n}</td></tr>'
            for t, a, b, n in entrees
        )

    return f"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Banque de questions - Code de la route du Bénin</title>
<style>{CSS}</style>
</head>
<body>

<section class="couverture">
  <p class="sur">République du Bénin - Examen du permis de conduire</p>
  <h1>Banque de questions<br>du code de la route</h1>
  <p class="sous">Énoncés, illustrations et réponses, dans la numérotation officielle</p>
  <div class="filet"></div>
  <div class="chiffres">
    <div class="chiffre"><b>{total}</b><span>questions</span></div>
    <div class="chiffre"><b>{len(images)}</b><span>illustrations</span></div>
    <div class="chiffre"><b>{len(sommaire_manuel) + len(sommaire_nouveaux)}</b><span>sections</span></div>
  </div>
  <p class="pied">Document de travail - Permis Bénin</p>
</section>

<section class="liminaire">
  <h2>Comment lire ce document</h2>
  <p>Chaque question porte le <strong>numéro officiel</strong> sous lequel elle est
  diffusée dans l'application et utilisée dans la composition des sujets. C'est ce
  numéro, et lui seul, qui désigne une question sans ambiguïté.</p>

  <div class="encadre">
    <p><strong>Les 930 premières questions</strong> reprennent la numérotation du
    manuel officiel de la Direction Générale des Transports Terrestres, édition 2011.
    Elle est figée et ne bougera pas.</p>
    <p><strong>À partir de 931</strong>, le numéro est attribué par la plateforme.
    Les questions prêtes à être diffusées occupent une suite continue ; celles dont
    la correction reste à confirmer ont été repoussées en fin de série, afin qu'aucune
    question déjà publiée n'ait jamais à changer de numéro. La correspondance avec les
    enregistrements d'origine figure en annexe.</p>
  </div>

  <p>La réponse attendue est indiquée sous chaque question par la lettre de l'option.
  Plusieurs lettres signifient que plusieurs options sont correctes et doivent toutes
  être cochées.</p>
  <p>{sans_reponse} questions portent la mention <em>Réponse à valider</em> : leur
  énoncé est arrêté, leur correction ne l'est pas. Elles ne sont pas diffusées aux
  candidats en l'état.</p>
  <p>Les illustrations sont celles que l'application sert réellement.</p>
</section>

<section class="liminaire">
  <h2>Sommaire</h2>
  <table class="sommaire">
    <thead><tr><th>Section</th><th>Questions</th><th>Nombre</th></tr></thead>
    <tbody>
      <tr class="partie"><td colspan="3">Première partie - Manuel officiel 2011</td></tr>
      {rangs(sommaire_manuel)}
      <tr class="partie"><td colspan="3">Seconde partie - Questions complémentaires</td></tr>
      {rangs(sommaire_nouveaux)}
    </tbody>
  </table>
</section>

<section class="separateur">
  <p class="etiquette">Première partie</p>
  <h2>Manuel officiel 2011</h2>
  <p>Les 930 questions du manuel du candidat à l'examen du permis de conduire,
  dans l'ordre et la numérotation d'origine.</p>
</section>

{corps_manuel}

<section class="separateur">
  <p class="etiquette">Seconde partie</p>
  <h2>Questions complémentaires</h2>
  <p>Les {len(recentes)} questions ajoutées après le manuel, de la n° 931 à la
  n° {recentes[-1]["number"]}, dans l'ordre de leur numéro officiel. Les sections
  suivent les thèmes ; les dernières questions sont celles dont la correction
  reste à confirmer.</p>
</section>

{corps_nouveaux}

{bloc_correspondance(attribution)}

</body>
</html>"""


def main() -> None:
    SORTIE.mkdir(parents=True, exist_ok=True)
    scanner_options()
    print(f"  {len(options_illustrees)} options illustrées disponibles")

    print("Lecture des sources...")
    anciennes, recentes, attribution = charger()
    print(f"  manuel : {len(anciennes)} | complémentaires : {len(recentes)} | "
          f"correspondances : {len(attribution)}")

    print("Préparation des images...")
    images = preparer_images(anciennes + recentes)
    poids = sum(f.stat().st_size for f in IMAGES_OUT.iterdir()) / 1_048_576
    print(f"  {len(images)} images ({poids:.1f} Mo)")

    print("Génération du HTML...")
    page = construire_html(anciennes, recentes, attribution, images)
    cible = SORTIE / "manuel.html"
    cible.write_text(page, encoding="utf-8")
    print(f"  {cible.name} ({cible.stat().st_size / 1_048_576:.1f} Mo)")


if __name__ == "__main__":
    main()
