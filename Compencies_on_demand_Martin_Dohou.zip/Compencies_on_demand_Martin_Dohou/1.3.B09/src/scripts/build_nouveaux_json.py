#!/usr/bin/env python3
"""
Construit prisma/seeds/data/qcms.nouveaux.json : les 648 questions ajoutees
apres le manuel 2011 (numeros 931-1578), completes - enonce, propositions,
bonnes reponses, explication, image, audios - et met leurs fichiers en place.

Pourquoi un fichier a part
--------------------------
`qcms.consolidated.json` est REGENERE par build_consolidated_json.py a partir
de qcms_data/docs/questions.md, qui ne connait que les 930 questions du manuel.
Y verser les nouvelles, c'est les voir disparaitre a la prochaine
regeneration, sans que rien ne le signale. Elles vivent donc dans leur propre
fichier, lu par leur propre seed (prisma/seeds/questions-nouveaux.seed.ts).

D'ou vient chaque champ
-----------------------
Le THEME vient du dossier d'origine du clip audio (`sourceAudio` du fichier
avec-nouveaux).

Le NUMERO, lui, NOUS APPARTIENT. Les 930 questions du manuel sont figees ;
au-dela, nous attribuons le numero que nous voulons, et c'est
`prisma/seeds/data/numeros-nouveaux.json` qui le fige, question d'origine par
question d'origine. La numerotation des dossiers d'origine ne sert plus qu'a
retrouver les fichiers : les ORIGINAUX ne sont jamais renommes, c'est la copie
posee dans `qcms_data/` et sa clef S3 qui portent le numero officiel.

Regle d'attribution (`attribuer()`) : les questions PRETES prennent les
numeros du bas, en suite continue ; celles auxquelles il manque un element
sont repoussees a la fin. Une question activee le reste donc, et celle qui se
completera plus tard s'activera sur place, sans decaler personne ni laisser de
trou dans la zone active.

⛔ Un numero attribue ne se reprend JAMAIS : il vit dans les clefs S3, dans les
compositions de sujets et d'epreuves, dans les QR d'examen blanc deja signes
et dans les copies rendues.

Le CONTENU vient du catalogue de l'application (Assets/Audios/
.catalogue-prive.json, API segmomo/ForGPBD, chapitres 13-21). C'est le texte
source, pas une transcription : il ne confond pas « soixante-dix » avec
« cent dix », ne coupe pas « Tout droit et a droite » en deux propositions,
et porte la bonne reponse (drapeau `r`), l'explication (`e`) et le drapeau
image (`i`). La correspondance se fait par (theme, numero dans le theme),
la clef que partagent le nom du clip et le champ `n` du catalogue
(`1CIRCULATION426`). Verifie sur les 602 questions communes : meme nombre
de propositions, dans le meme ordre - l'audio lit donc bien ce que l'ecran
affiche.

45 questions n'existent pas dans le catalogue (audio encore en ligne,
question retiree de la base). Pour elles seules on garde la transcription de
l'audio, et la bonne reponse ne peut venir que de la saisie manuelle
(Assets/Audios/Transcriptions/nouvelles-questions.csv, colonne
`correctAnswers`). Sans elle, la question est creee INACTIVE : absente des
quiz, elle s'active le jour ou sa reponse arrive.

Images : Assets/Audios/Traitement/Nouveaux-images/webp/<numero>.webp,
produites depuis les JPEG de la CDN par scripts/images/optimiser_adaptatif.py,
comme celles des 930. Audios : un dossier traite par langue (AUDIOS_TRAITES).

Usage :
  python3 scripts/qcms/build_nouveaux_json.py --dry-run
  python3 scripts/qcms/build_nouveaux_json.py
  python3 scripts/qcms/build_nouveaux_json.py --attribuer   # 1re fois, ou
                                                            # nouvelles venues
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]            # .../Code/pbj-backend
ASSETS = ROOT.parents[1] / "Assets" / "Audios"
SOURCE_JSON = ROOT / "prisma/seeds/data/qcms.consolidated.avec-nouveaux.json"
CATALOGUE = ASSETS / ".catalogue-prive.json"
SAISIE_CSV = ASSETS / "Transcriptions/nouvelles-questions.csv"
IMAGES_WEBP = ASSETS / "Traitement/Nouveaux-images/webp"
# Une entree par langue dont les audios des questions 931+ sont traites. Une
# langue absente ici, ou un numero sans fichier, laisse simplement la question
# sans audio dans cette langue.
AUDIOS_TRAITES = {
    "fr": ASSETS / "Traitement/Nouveaux-fr/Traitement/05_final/Fr-nouveaux",
    "fon": ASSETS / "Traitement/Nouveaux-fon/Traitement/05_final/Fon-nouveaux",
}
DATA_DIR = ROOT / "qcms_data"
SORTIE = ROOT / "prisma/seeds/data/qcms.nouveaux.json"
# Table de correspondance « question d'origine -> numero officiel ». Voir
# `attribuer()`. Commitee : c'est elle qui fige la numerotation.
ATTRIBUTION = ROOT / "prisma/seeds/data/numeros-nouveaux.json"

PREMIER_NUMERO = 931
CHAPITRES_PRIVES = {str(c) for c in range(13, 22)}

# Dossier d'origine -> slug du theme (prisma/seeds/themes.data.ts).
SLUG_PAR_DOSSIER = {
    "CIRCULATION": "circulation",
    "CONDUCTEUR": "conducteur",
    "DIVERSES": "diverses",
    "ENVIRONNEMENT": "environnement",
    "MECANIQUE": "mecanique",
    "ROUTE": "route",
    "SECOURS": "secours",
    "SECURITE": "securite",
    "VEHICULES": "vehicules",
}

LETTRES = "ABCDEF"


def propre(texte: str | None) -> str:
    """Espaces multiples et bords : le catalogue en porte (« 80 km/h :  Oui »)."""
    return re.sub(r"\s+", " ", texte or "").strip()


def catalogue() -> dict[tuple[str, int], dict]:
    """{(THEME, numero dans le theme): question du catalogue}."""
    if not CATALOGUE.is_file():
        print(f"[ERROR] catalogue introuvable : {CATALOGUE}", file=sys.stderr)
        sys.exit(1)
    d = json.loads(CATALOGUE.read_text(encoding="utf-8"))
    out = {}
    for q in json.loads(d["Q"]):
        if str(q.get("c")) not in CHAPITRES_PRIVES:
            continue
        m = re.match(r"^(\d+)([A-Z]+)426$", str(q.get("n", "")))
        if m:
            out[(m.group(2), int(m.group(1)))] = q
    return out


def reponses_saisies() -> dict[int, dict]:
    """{numero: {"correctAnswers": [...], "invalides": [...]}} - saisie manuelle."""
    if not SAISIE_CSV.is_file():
        return {}
    out = {}
    with SAISIE_CSV.open(encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            try:
                n = int(r["number"])
            except (KeyError, ValueError):
                continue
            # « A », « A,C », « A C », « AC » : tout se lit comme une suite de
            # lettres ; un caractere hors A-F signale une saisie a revoir
            lettres = re.findall(r"[A-Z]", (r.get("correctAnswers") or "").upper())
            invalides = [x for x in lettres if x not in LETTRES]
            out[n] = {"correctAnswers": sorted(set(lettres) - set(invalides)),
                      "invalides": invalides}
    return out


def est_complete(b: dict) -> bool:
    """Une question PRETE a partir aux candidats.

    Memes elements que la regle du seed (questions-nouveaux.seed.ts) : une
    bonne reponse, l'image quand elle est attendue, et l'audio francais. Le fon
    ne compte pas : une question sans fon reste jouable.
    """
    return (
        bool(b["correctAnswers"])
        and (not b["veutImage"] or b["imageSrc"] is not None)
        and "fr" in b["audiosSrc"]
    )


def charger_attribution() -> dict[str, int]:
    """{sourceAudio: numero officiel} - vide si la table n'existe pas encore."""
    if not ATTRIBUTION.is_file():
        return {}
    d = json.loads(ATTRIBUTION.read_text(encoding="utf-8"))
    return {k: int(v) for k, v in d["attribution"].items()}


def attribuer(brouillons: list[dict], attribution: dict[str, int]) -> list[dict]:
    """Donne un numero officiel aux questions qui n'en ont pas encore.

    La numerotation des 931+ nous appartient : celle des dossiers d'origine ne
    vaut que pour retrouver les fichiers. Les questions PRETES prennent les
    numeros du bas, en suite continue ; celles auxquelles il manque un element
    sont repoussees a la fin. Une question activee le reste donc, et celle qui
    se completera plus tard s'activera sur place, sans jamais decaler personne.

    Un numero deja attribue n'est JAMAIS repris, meme si la question change
    d'etat : il vit dans les clefs S3, dans les compositions de sujets et dans
    les copies deja rendues. C'est tout l'interet de figer la table.

    Retourne les brouillons nouvellement numerotes.
    """
    inedits = [b for b in brouillons if b["sourceAudio"] not in attribution]
    if not inedits:
        return []
    inedits.sort(key=lambda b: (0 if est_complete(b) else 1, b["numeroSource"]))
    occupes = set(attribution.values())
    prochain = PREMIER_NUMERO
    for b in inedits:
        while prochain in occupes:
            prochain += 1
        attribution[b["sourceAudio"]] = prochain
        occupes.add(prochain)
    return inedits


def purger_derives() -> None:
    """Retire de `qcms_data/` les fichiers derives des 931+, avant reecriture.

    Une attribution reaffecte des numeros que d'autres questions portaient au
    passage precedent. Or la copie est conditionnelle (« seulement si
    l'original est plus recent ») : sans purge, le fichier de l'ancienne
    occupante du numero reste en place, et c'est LUI qui part sur S3 sous la
    clef de la nouvelle. Une question afficherait l'image d'une autre.

    Ne touche que les numeros >= 931 : le dossier porte aussi les 930
    officielles, qui ne se renumerotent jamais.
    """
    def numero(chemin: Path) -> int | None:
        try:
            return int(chemin.stem)
        except ValueError:
            return None

    cibles = list((DATA_DIR / "qcms_images").glob("*.webp"))
    cibles += list((DATA_DIR / "qcms_audios").glob("*/*.m4a"))
    retires = 0
    for f in cibles:
        n = numero(f)
        if n is not None and n >= PREMIER_NUMERO:
            f.unlink()
            retires += 1
    if retires:
        print(f"  purge des derives 931+ : {retires} fichier(s)")


def ecrire_attribution(attribution: dict[str, int]) -> None:
    doc = {
        "metadata": {
            "description": "Numero officiel de chaque question 931+, par "
                           "question d'origine. Un numero attribue ne change "
                           "JAMAIS : il vit dans les clefs S3, les "
                           "compositions de sujets et les copies rendues. "
                           "Genere par scripts/qcms/build_nouveaux_json.py.",
            "premierNumero": PREMIER_NUMERO,
            "attribuees": len(attribution),
        },
        "attribution": dict(sorted(attribution.items(), key=lambda kv: kv[1])),
    }
    ATTRIBUTION.write_text(
        json.dumps(doc, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument(
        "--attribuer",
        action="store_true",
        help="donne un numero officiel aux questions qui n'en ont pas encore "
             "et met a jour la table de correspondance",
    )
    args = ap.parse_args()

    if not SOURCE_JSON.is_file():
        print(f"[ERROR] source introuvable : {SOURCE_JSON}", file=sys.stderr)
        return 1
    src = json.loads(SOURCE_JSON.read_text(encoding="utf-8"))
    neuves = [q for q in src["questions"] if q["number"] >= PREMIER_NUMERO]
    cat = catalogue()
    saisie = reponses_saisies()

    # Passe 1 - on lit les ORIGINAUX sous leur numero d'origine, sans rien
    # nommer encore : le numero officiel n'est attribue qu'ensuite.
    brouillons = []
    par_source = {"catalogue": 0, "transcription": 0}
    for q in neuves:
        n_src = q["number"]
        _, dossier, fichier = q["sourceAudio"].split("/")
        slug = SLUG_PAR_DOSSIER[dossier]
        c = cat.get((dossier, int(Path(fichier).stem)))
        alertes = []

        if c:
            statement = propre(c.get("q"))
            options = [{"letter": LETTRES[i], "text": propre(p.get("c"))}
                       for i, p in enumerate(c.get("p", []))]
            reponses = [LETTRES[i] for i, p in enumerate(c.get("p", []))
                        if str(p.get("r", "")).strip() == "1"]
            explication = propre(c.get("e")) or None
            veut_image = str(c.get("i", "")).strip() == "1"
            origine = "catalogue"
            if not reponses:
                alertes.append("aucune bonne reponse dans le catalogue")
        else:
            statement = q["statement"]
            options = q["options"]
            s = saisie.get(n_src, {})
            lettres_options = {o["letter"] for o in options}
            reponses = [x for x in s.get("correctAnswers", []) if x in lettres_options]
            hors = [x for x in s.get("correctAnswers", []) if x not in lettres_options]
            if s.get("invalides") or hors:
                alertes.append(
                    f"saisie « {', '.join(s.get('invalides', []) + hors)} »")
            explication = None
            # hors catalogue, l'image existe ou pas : c'est le fichier qui dit
            veut_image = (IMAGES_WEBP / f"{n_src}.webp").is_file()
            origine = "transcription"
        par_source[origine] += 1

        webp = IMAGES_WEBP / f"{n_src}.webp"
        if veut_image and not webp.is_file():
            alertes.append(f"image attendue, {webp.name} absent")

        brouillons.append({
            "numeroSource": n_src,
            "sourceAudio": q["sourceAudio"],
            "themeSlug": slug,
            "statement": statement,
            "options": options,
            "correctAnswers": reponses,
            "explanation": explication,
            "contentSource": origine,
            "veutImage": veut_image,
            "imageSrc": webp if webp.is_file() else None,
            "audiosSrc": {
                lang: d / f"q-{n_src}.m4a"
                for lang, d in AUDIOS_TRAITES.items()
                if (d / f"q-{n_src}.m4a").is_file()
            },
            "alertes": alertes,
        })

    # Attribution des numeros officiels.
    attribution = charger_attribution()
    deja_figes = len(attribution)
    inedits = attribuer(brouillons, attribution)
    if inedits and not args.attribuer:
        print(f"[ERROR] {len(inedits)} question(s) sans numero officiel.",
              file=sys.stderr)
        print("        Relancer avec --attribuer pour leur en donner un "
              "(les pretes d'abord, les incompletes a la fin).", file=sys.stderr)
        return 1

    # Passe 2 - tout est nomme d'apres le numero OFFICIEL : le fichier copie,
    # sa clef S3, et l'entree du dataset. Les originaux, eux, n'ont pas bouge.
    if inedits and not args.dry_run:
        purger_derives()
    questions, copies = [], 0
    par_langue = {lang: 0 for lang in AUDIOS_TRAITES}
    a_revoir = []
    brouillons.sort(key=lambda b: attribution[b["sourceAudio"]])
    renumerotees = 0
    for b in brouillons:
        n = attribution[b["sourceAudio"]]
        if n != b["numeroSource"]:
            renumerotees += 1
        for x in b["alertes"]:
            a_revoir.append(f"q{n} (origine {b['sourceAudio']}) : {x}")

        entree = {
            "number": n,
            "themeSlug": b["themeSlug"],
            "statement": b["statement"],
            "options": b["options"],
            "correctAnswers": b["correctAnswers"],
            "explanation": b["explanation"],
            "image": None,
            "audios": {},
            "sourceAudio": b["sourceAudio"],
            "sourceNumber": b["numeroSource"],
            "contentSource": b["contentSource"],
        }

        if b["veutImage"]:
            src = b["imageSrc"]
            if src is not None:
                dest = DATA_DIR / "qcms_images" / f"{n}.webp"
                if not args.dry_run:
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    if not dest.is_file() or dest.stat().st_mtime < src.stat().st_mtime:
                        shutil.copy2(src, dest)
                        copies += 1
                entree["image"] = {
                    "localPath": f"qcms_images/{n}.webp",
                    "s3Key": f"questions/images/q-{n:03d}.webp",
                    "exists": True,
                }
            else:
                # Image attendue mais pas encore traitee. On l'ECRIT quand meme,
                # avec exists: False : sans cela l'entree resterait `image: null`,
                # que le seed lit comme « question sans image par nature », donc
                # comme une question complete, donc ACTIVE. Une image manquante
                # serait alors indiscernable d'une absence d'image, et la
                # question partirait aux candidats amputee de son illustration.
                entree["image"] = {
                    "localPath": f"qcms_images/{n}.webp",
                    "s3Key": f"questions/images/q-{n:03d}.webp",
                    "exists": False,
                }

        for lang, src in b["audiosSrc"].items():
            dest = DATA_DIR / "qcms_audios" / lang / f"{n:03d}.m4a"
            if not args.dry_run:
                dest.parent.mkdir(parents=True, exist_ok=True)
                if not dest.is_file() or dest.stat().st_mtime < src.stat().st_mtime:
                    shutil.copy2(src, dest)
                    copies += 1
            entree["audios"][lang] = {
                "localPath": f"qcms_audios/{lang}/{n:03d}.m4a",
                "s3Key": f"questions/audios/{lang}/q-{n:03d}.m4a",
                "exists": True,
            }
            par_langue[lang] += 1
        questions.append(entree)

    avec_reponse = sum(1 for q in questions if q["correctAnswers"])
    avec_image = sum(1 for q in questions if q["image"] and q["image"]["exists"])
    image_manquante = sum(
        1 for q in questions if q["image"] and not q["image"]["exists"]
    )
    avec_explication = sum(1 for q in questions if q["explanation"])
    doc = {
        "metadata": {
            "description": "Questions ajoutees apres le manuel 2011 "
                           f"({questions[0]['number']}-{questions[-1]['number']}). "
                           "Genere par scripts/qcms/build_nouveaux_json.py ; "
                           "ne pas editer a la main.",
            "totalQuestions": len(questions),
            "contentSource": par_source,
            "withCorrectAnswers": avec_reponse,
            "withExplanation": avec_explication,
            "withImage": avec_image,
            "imageMissing": image_manquante,
            "withAudio": par_langue,
        },
        "questions": questions,
    }

    print(f"{len(questions)} questions ({questions[0]['number']}-{questions[-1]['number']})")
    print(f"  contenu du catalogue : {par_source['catalogue']}, "
          f"transcription de l'audio : {par_source['transcription']}")
    print(f"  avec bonne reponse   : {avec_reponse} (les autres seront creees inactives)")
    print(f"  avec explication     : {avec_explication}")
    print(f"  avec image           : {avec_image}")
    if image_manquante:
        print(f"  image ATTENDUE, absente : {image_manquante} "
              f"(ces questions seront creees inactives)")
    for lang, nb in par_langue.items():
        manque = [q["number"] for q in questions if lang not in q["audios"]]
        detail = (f" - sans : {', '.join(map(str, manque))}" if 0 < len(manque) <= 10
                  else "")
        print(f"  avec audio {lang:<9} : {nb}{detail}")
    for x in a_revoir:
        print(f"  a revoir : {x}")

    pretes = sum(1 for b in brouillons if est_complete(b))
    print(f"\nNumerotation : {deja_figes} numero(s) deja figes, "
          f"{len(inedits)} attribue(s) ce coup-ci")
    print(f"  pretes      : {pretes} (numeros du bas, suite continue)")
    print(f"  incompletes : {len(brouillons) - pretes} (repoussees a la fin)")
    if renumerotees:
        print(f"  ⚠ {renumerotees} question(s) ne portent PAS leur numero "
              f"d'origine : les assets doivent etre re-uploades")

    if args.dry_run:
        print("\n--dry-run : rien n'a ete ecrit")
        return 0
    SORTIE.write_text(json.dumps(doc, ensure_ascii=False, indent=1) + "\n",
                      encoding="utf-8")
    if inedits:
        ecrire_attribution(attribution)
        print(f"\n{ATTRIBUTION.relative_to(ROOT)}")
    print(f"\n{SORTIE.relative_to(ROOT)}")
    print(f"{copies} fichiers copies vers qcms_data/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
