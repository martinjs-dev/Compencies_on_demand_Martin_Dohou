#!/usr/bin/env python3
"""
Upload des assets QCM (images + audios) vers MinIO / S3, sur la base de
qcms_data/qcms.consolidated.json (genere par build_consolidated_json.py).

- Bucket cible : variable d'env S3_PRIVATE_BUCKET (defaut "pbj-private")
- Cles S3 :
    questions/images/q-{number}.{ext}          (ext reelle : jpeg/jpg/png/webp)
    questions/audios/{lang}/q-{number}.{ext}   (ext reelle : mp3/m4a/ogg/...)
- Idempotent : compare la taille locale vs HEAD distant. --force pour reuploader.
- Concurrent : ThreadPoolExecutor (8 workers par defaut).
- Inclut les assets orphelins (numeros sans question) sauf si --skip-orphans.
- Genere qcms_data/upload-manifest.json a la fin (audit + traçabilite).

Variables d'env (alignees sur scripts/upload-seed-assets.ts) :
  S3_ENDPOINT          ex: http://localhost:9000
  S3_ACCESS_KEY
  S3_SECRET_KEY
  S3_REGION            defaut "us-east-1"
  S3_PRIVATE_BUCKET    defaut "pbj-private"
  S3_USE_PATH_STYLE    "true" pour MinIO (defaut true ici)

Usage :
  python3 scripts/qcms/upload_qcms_assets.py [--dry-run] [--force]
                                             [--only images|audios]
                                             [--lang fr,fon]
                                             [--from N --to M]
                                             [--workers 8]
                                             [--create-bucket]
                                             [--skip-orphans]
                                             [--limit N]
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

from dotenv import load_dotenv

try:
    import boto3
    from botocore.client import Config
    from botocore.exceptions import ClientError
except ImportError:
    print(
        "[ERROR] boto3 n'est pas installe. Installe-le avec :\n"
        "  pip install boto3\n  # ou : pipx install boto3 && pipx ensurepath",
        file=sys.stderr,
    )
    sys.exit(1)

ROOT = Path(__file__).resolve().parents[2]

load_dotenv(ROOT / ".env")

DATA_DIR = ROOT / "qcms_data"
CONSOLIDATED = DATA_DIR / "qcms.consolidated.json"
MANIFEST_OUT = DATA_DIR / "upload-manifest.json"

CONTENT_TYPES = {
    ".jpeg": "image/jpeg",
    ".jpg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
    # Audio : Content-Type derive du suffixe reel du fichier local. Doit rester
    # aligne sur common/audio/audio-format.ts (backend agnostique au format).
    ".mp3": "audio/mpeg",
    ".m4a": "audio/mp4",
    ".aac": "audio/mp4",
    ".ogg": "audio/ogg",
    ".opus": "audio/ogg",
    ".wav": "audio/wav",
    ".webm": "audio/webm",
}


@dataclass
class UploadTask:
    kind: str  # "image" | "audio"
    lang: str | None
    number: int
    local_path: Path
    s3_key: str
    is_orphan: bool


@dataclass
class UploadResult:
    s3_key: str
    status: str  # "uploaded" | "skipped" | "missing" | "error"
    size: int | None = None
    etag: str | None = None
    detail: str | None = None


def env_required(name: str) -> str:
    val = os.environ.get(name)
    if not val:
        print(f"[ERROR] Variable d'env manquante : {name}", file=sys.stderr)
        sys.exit(2)
    return val


def build_s3_client():
    endpoint = env_required("S3_ENDPOINT")
    access_key = env_required("S3_ACCESS_KEY")
    secret_key = env_required("S3_SECRET_KEY")
    region = os.environ.get("S3_REGION", "us-east-1")
    use_path_style = os.environ.get("S3_USE_PATH_STYLE", "true").lower() == "true"

    return boto3.client(
        "s3",
        endpoint_url=endpoint,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        region_name=region,
        config=Config(
            signature_version="s3v4",
            s3={"addressing_style": "path" if use_path_style else "auto"},
            retries={"max_attempts": 3, "mode": "standard"},
        ),
    )


def ensure_bucket(s3, bucket: str, create: bool) -> None:
    try:
        s3.head_bucket(Bucket=bucket)
        return
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        if code in ("404", "NoSuchBucket", "NotFound") and create:
            print(f"[INFO] Creation du bucket {bucket}...")
            s3.create_bucket(Bucket=bucket)
            return
        raise


def collect_tasks(consolidated: dict, args) -> list[UploadTask]:
    tasks: list[UploadTask] = []
    in_range = lambda n: (args.from_ is None or n >= args.from_) and (
        args.to is None or n <= args.to
    )
    lang_filter: set[str] | None = (
        set(args.lang.split(",")) if args.lang else None
    )

    if args.only in (None, "images"):
        for q in consolidated["questions"]:
            if not in_range(q["number"]):
                continue
            img = q.get("image")
            if img:
                tasks.append(
                    UploadTask(
                        kind="image",
                        lang=None,
                        number=q["number"],
                        local_path=DATA_DIR / img["localPath"],
                        s3_key=img["s3Key"],
                        is_orphan=False,
                    )
                )
            # Images d'options (questions visuelles : 1 image S3 par option,
            # toutes pointant vers le placeholder local en attendant les vraies sous-images)
            for opt in q.get("options") or []:
                opt_img = opt.get("image")
                if opt_img:
                    tasks.append(
                        UploadTask(
                            kind="image",
                            lang=None,
                            number=q["number"],
                            local_path=DATA_DIR / opt_img["localPath"],
                            s3_key=opt_img["s3Key"],
                            is_orphan=False,
                        )
                    )
        if not args.skip_orphans:
            for img in consolidated.get("orphanAssets", {}).get("images", []):
                if in_range(img["number"]):
                    tasks.append(
                        UploadTask(
                            kind="image",
                            lang=None,
                            number=img["number"],
                            local_path=DATA_DIR / img["localPath"],
                            s3_key=img["s3Key"],
                            is_orphan=True,
                        )
                    )

    if args.only in (None, "audios"):
        for q in consolidated["questions"]:
            for lang, ref in (q.get("audios") or {}).items():
                if lang_filter and lang not in lang_filter:
                    continue
                if not in_range(q["number"]):
                    continue
                tasks.append(
                    UploadTask(
                        kind="audio",
                        lang=lang,
                        number=q["number"],
                        local_path=DATA_DIR / ref["localPath"],
                        s3_key=ref["s3Key"],
                        is_orphan=False,
                    )
                )
        if not args.skip_orphans:
            for lang, items in (
                consolidated.get("orphanAssets", {}).get("audios", {}).items()
            ):
                if lang_filter and lang not in lang_filter:
                    continue
                for it in items:
                    if not in_range(it["number"]):
                        continue
                    tasks.append(
                        UploadTask(
                            kind="audio",
                            lang=lang,
                            number=it["number"],
                            local_path=DATA_DIR / it["localPath"],
                            s3_key=it["s3Key"],
                            is_orphan=True,
                        )
                    )

    if args.limit is not None:
        tasks = tasks[: args.limit]
    return tasks


def remote_size(s3, bucket: str, key: str) -> int | None:
    try:
        head = s3.head_object(Bucket=bucket, Key=key)
        return head["ContentLength"]
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        if code in ("404", "NoSuchKey", "NotFound"):
            return None
        raise


def upload_one(s3, bucket: str, task: UploadTask, force: bool) -> UploadResult:
    if not task.local_path.is_file():
        return UploadResult(
            s3_key=task.s3_key, status="missing",
            detail=f"Fichier local introuvable : {task.local_path}",
        )

    local_size = task.local_path.stat().st_size
    if not force:
        existing = remote_size(s3, bucket, task.s3_key)
        if existing == local_size:
            return UploadResult(s3_key=task.s3_key, status="skipped", size=local_size)

    content_type = CONTENT_TYPES.get(task.local_path.suffix.lower(), "application/octet-stream")
    with task.local_path.open("rb") as f:
        resp = s3.put_object(
            Bucket=bucket,
            Key=task.s3_key,
            Body=f,
            ContentType=content_type,
        )
    etag = (resp.get("ETag") or "").strip('"') or None
    return UploadResult(s3_key=task.s3_key, status="uploaded", size=local_size, etag=etag)


def humanize(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n = n / 1024
    return f"{n:.1f} TB"


def main() -> int:
    parser = argparse.ArgumentParser(description="Upload des assets QCM vers MinIO/S3.")
    parser.add_argument("--dry-run", action="store_true", help="Liste les actions sans uploader.")
    parser.add_argument("--force", action="store_true", help="Reupload meme si la taille distante matche.")
    parser.add_argument("--only", choices=["images", "audios"], help="Restreindre a un type.")
    parser.add_argument("--lang", help="Langues a uploader (csv). Ex: fr,fon")
    parser.add_argument("--from", dest="from_", type=int, help="Numero de question minimum.")
    parser.add_argument("--to", type=int, help="Numero de question maximum.")
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--create-bucket", action="store_true", help="Creer le bucket s'il n'existe pas.")
    parser.add_argument("--skip-orphans", action="store_true", help="Ignorer les assets orphelins.")
    parser.add_argument("--limit", type=int, help="Limite de tâches (utile pour tester).")
    parser.add_argument(
        "--consolidated",
        type=Path,
        default=CONSOLIDATED,
        help="JSON a lire (defaut qcms_data/qcms.consolidated.json). Ex: "
        "prisma/seeds/data/qcms.nouveaux.json pour les questions 931+.",
    )
    args = parser.parse_args()
    source = args.consolidated

    if not source.is_file():
        print(f"[ERROR] {source} introuvable. Lance d'abord build_consolidated_json.py.", file=sys.stderr)
        return 1

    with source.open(encoding="utf-8") as f:
        consolidated = json.load(f)

    # Garde-fou de renumerotation. Une question dont le numero officiel differe
    # de son numero d'origine ecrit sous une clef qu'une AUTRE question occupait
    # au passage precedent. Or on saute un objet quand sa taille distante egale
    # la taille locale : deux images differentes de meme taille passeraient donc
    # pour identiques, et l'ancienne resterait en ligne sous le nouveau numero.
    # Silencieux, et faux a l'ecran. --force est obligatoire dans ce cas.
    renumerotees = sum(
        1
        for q in consolidated.get("questions", [])
        if q.get("sourceNumber") is not None and q["sourceNumber"] != q["number"]
    )
    if renumerotees and not args.force and not args.dry_run:
        print(
            f"[ERROR] {renumerotees} question(s) ne portent pas leur numero "
            "d'origine.\n"
            "        Leur clef S3 a change de contenu : la comparaison de "
            "taille ne peut pas\n"
            "        le voir. Relancer avec --force.",
            file=sys.stderr,
        )
        return 1

    bucket = os.environ.get("S3_PRIVATE_BUCKET", "pbj-private")
    tasks = collect_tasks(consolidated, args)
    if not tasks:
        print("Aucune tache a traiter.")
        return 0

    total_bytes = sum(t.local_path.stat().st_size for t in tasks if t.local_path.is_file())
    by_kind: dict[str, int] = {}
    for t in tasks:
        key = f"{t.kind}{':orphan' if t.is_orphan else ''}"
        by_kind[key] = by_kind.get(key, 0) + 1
    print(f"Bucket : s3://{bucket}/  (endpoint : {os.environ.get('S3_ENDPOINT', '?')})")
    print(f"Taches : {len(tasks)}  ({by_kind})  taille locale ~ {humanize(total_bytes)}")

    if args.dry_run:
        print("[DRY-RUN] Aucun upload effectue. Echantillon :")
        for t in tasks[:10]:
            print(f"  - [{t.kind}{'/orphan' if t.is_orphan else ''}] {t.local_path} -> s3://{bucket}/{t.s3_key}")
        if len(tasks) > 10:
            print(f"  ... +{len(tasks) - 10} autres")
        return 0

    s3 = build_s3_client()
    ensure_bucket(s3, bucket, args.create_bucket)

    results: list[UploadResult] = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(upload_one, s3, bucket, t, args.force): t for t in tasks}
        done = 0
        total = len(futures)
        for fut in as_completed(futures):
            t = futures[fut]
            try:
                res = fut.result()
            except Exception as e:  # noqa: BLE001
                res = UploadResult(s3_key=t.s3_key, status="error", detail=str(e))
            results.append(res)
            done += 1
            if done % 50 == 0 or done == total or res.status in ("error", "missing"):
                print(f"  [{done:>5}/{total}] {res.status:>9}  {res.s3_key}"
                      + (f"  ({res.detail})" if res.detail else ""))

    summary: dict[str, int] = {}
    for r in results:
        summary[r.status] = summary.get(r.status, 0) + 1
    print("\nResume :")
    for k, v in sorted(summary.items()):
        print(f"  {k}: {v}")

    manifest = {
        "bucket": bucket,
        "endpoint": os.environ.get("S3_ENDPOINT"),
        "summary": summary,
        "results": [asdict(r) for r in results],
    }
    MANIFEST_OUT.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(f"[OK] Manifeste ecrit : {MANIFEST_OUT.relative_to(ROOT)}")

    if summary.get("error", 0) or summary.get("missing", 0):
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
