#!/usr/bin/env python3
"""
Valide Questions_Permis_BJ.json (export Excel) contre la transcription propre
qcms_data/docs/questions.md.

questions.md est la source la plus fiable : format markdown regulier
(## Question n°N, - a) ..., #### Reponse : x, ---). 814 questions textuelles
sur les 918 de l'Excel (les 104 manquantes sont en grande partie les questions
a options visuelles).

Sorties :
  - qcms_data/md-validation-report.json     rapport detaille des divergences
  - qcms_data/md-suggested-overrides.json   overrides candidats au format
                                            manual-overrides.json (revue
                                            humaine requise avant fusion)

Aucune dependance Python externe.

Usage :
  python3 scripts/qcms/validate_against_md.py
  python3 scripts/qcms/validate_against_md.py --md "<autre.md>"
  python3 scripts/qcms/validate_against_md.py --min-similarity 0.80
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import unicodedata
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT / "qcms_data"
DEFAULT_MD = DATA_DIR / "docs" / "questions.md"
EXCEL_JSON = DATA_DIR / "Questions_Permis_BJ.json"
REPORT_JSON = DATA_DIR / "md-validation-report.json"
SUGGESTED_JSON = DATA_DIR / "md-suggested-overrides.json"

QUESTION_RE = re.compile(
    # Formats supportes :
    #   "## Question_N - Enonce..." (nouveau format propre)
    #   "## Question n°N", "Question N", "Questionn°N" (legacy)
    r"^(?:##\s*)?Question(?:_(\d+)\s*-\s*(.*)|\s*(?:n\s*[°ºo]?\s*)?(\d+))\s*$",
    re.IGNORECASE | re.MULTILINE,
)
# Option : tolere "- a) text", "- a text", "- a- text", "- cje text" (lettre collee),
# et prefixe page colle "81- a) text".
OPTION_RE = re.compile(
    r"^\d{0,3}\s*-\s*([a-eA-E])(?:\s+|[\)\.\-]\s*|(?=\S))(.*)$"
)
ANSWER_RE = re.compile(
    r"^####\s*R[ée]ponses?\s*:?\s*(.+?)\s*$", re.IGNORECASE
)
SEPARATOR_RE = re.compile(r"^---\s*$")
# Numero de page colle au debut (ex: "73Sur cette chaussee")
PAGE_PREFIX_RE = re.compile(r"^\d{1,3}(?=[A-ZÉÈÀÂÎÔÛÇa-z])")


@dataclass
class MdQuestion:
    number: int
    statement: str
    options: list[dict[str, str]]
    correct_answers: list[str]
    raw_lines: list[str] = field(default_factory=list)


def parse_answer_letters(raw: str) -> list[str]:
    """Normalise 'a-c-d', 'a, c, d', 'a et c', 'a/b' -> ['A','C','D']. Tolere 'e' invalide."""
    parts = re.split(r"[\.,;\-/\s]+|et\b", raw, flags=re.IGNORECASE)
    out: list[str] = []
    for p in parts:
        p = p.strip().upper()
        if len(p) == 1 and p in "ABCDE":
            out.append(p)
    return out


def clean_statement(text: str) -> str:
    """Strip prefixe page colle, espaces multiples, ponctuation parasite."""
    text = re.sub(r"\s+", " ", text).strip()
    # Retire prefixe page colle ("73Sur..." -> "Sur...")
    text = PAGE_PREFIX_RE.sub("", text)
    return text


def clean_value(text: str) -> str:
    """Nettoie statement ou option : retire ---, numeros de page parasites, espaces."""
    # Retire les sequences --- (separateurs markdown)
    text = re.sub(r"\s*-{3,}\s*", " ", text)
    # Retire prefixe numerique parasite. Cas geres :
    #   "1 2 Sur..." / "95 31 2 3 Sur..."  -> 2+ nombres separes par espace
    #   "96 3A cette..."                   -> 2 nombres dont le 2e colle a une majuscule
    #   "73Sur cette..."                   -> 1 nombre colle a une majuscule
    # On ne touche PAS aux nombres legitimes type "130 km/h" (1 nombre + minuscule).
    text = re.sub(r"^\s*\d{1,3}\s+\d{1,3}(?=[A-Z])", "", text)
    text = re.sub(r"^\s*(?:\d+\s+){2,}(?=[A-Za-zÀ-ÿ])", "", text)
    text = re.sub(r"^\s*\d{1,3}(?=[A-Z])", "", text)
    # Retire numeros de page (1-3 chiffres) en fin de chaine
    text = re.sub(r"\s+\d{1,3}\s*$", "", text)
    # Retire numero de page suivi de marqueur d'option fantome (ex: "85c-")
    text = re.sub(r"\s+\d{1,3}[a-eA-E][\-\)]\s*$", "", text)
    # Retire chapitre/header colle (ex: "47CHAPITRE III ...")
    text = re.sub(r"\s+\d{0,3}\s*CHAPITRE.*$", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s+", " ", text).strip().rstrip(" .;,")
    return text


def parse_md_questions(text: str) -> dict[int, MdQuestion]:
    """
    Parse le markdown. Tolere :
      - separateurs `---` parfois manquants entre 2 questions
      - headers `## Question n°N` ou simplement `Question n °N` (sans ##)
    Strategie : on decoupe par headers (toutes variantes), pas par `---`.
    """
    headers = list(QUESTION_RE.finditer(text))
    questions: dict[int, MdQuestion] = {}

    for idx, header in enumerate(headers):
        # Nouveau format : group(1)=N, group(2)=enonce
        # Legacy format : group(3)=N
        if header.group(1):
            number = int(header.group(1))
            inline_statement = (header.group(2) or "").strip()
        else:
            number = int(header.group(3))
            inline_statement = ""
        # Bloc = du debut du header courant au debut du suivant (ou fin du fichier)
        end = headers[idx + 1].start() if idx + 1 < len(headers) else len(text)
        block = text[header.end():end]
        body_lines = block.splitlines()

        statement_parts: list[str] = []
        options: list[dict[str, str]] = []
        answers: list[str] = []
        seen_options = False

        for line in body_lines:
            stripped = line.strip()
            if not stripped:
                continue

            am = ANSWER_RE.match(stripped)
            if am:
                answers = parse_answer_letters(am.group(1))
                continue

            om = OPTION_RE.match(stripped)
            if om:
                seen_options = True
                letter = om.group(1).upper()
                opt_text = om.group(2).strip().rstrip(" .;,")
                # Cas "- cje ralentis" : lettre collee au texte, on accepte tel quel
                if letter in {o["letter"] for o in options}:
                    # collision : continuation de l'option precedente ?
                    if options:
                        options[-1]["text"] += " " + stripped.lstrip("- ").strip()
                    continue
                options.append({"letter": letter, "text": opt_text})
                continue

            # Avant les options : suite de l'enonce
            if not seen_options:
                statement_parts.append(stripped)
            else:
                # Apres options, avant reponse : continuation de la derniere option
                if options and not stripped.isdigit():
                    options[-1]["text"] += " " + stripped

        # Nettoyage final : enleve aussi les artefacts markdown (---, numeros de page, etc.)
        # Si le header inclut deja l'enonce (nouveau format), on le prend directement.
        if inline_statement:
            statement = clean_value(clean_statement(inline_statement))
        else:
            statement = clean_value(clean_statement(" ".join(statement_parts)))
        for o in options:
            o["text"] = clean_value(o["text"])

        # Si la question apparait plusieurs fois (rare), on garde la version la plus riche
        new = MdQuestion(
            number=number,
            statement=statement,
            options=options,
            correct_answers=answers,
            raw_lines=body_lines,
        )
        existing = questions.get(number)
        if existing is None:
            questions[number] = new
        else:
            score_new = (
                len(new.statement)
                + 50 * len(new.options)
                + 20 * len(new.correct_answers)
            )
            score_old = (
                len(existing.statement)
                + 50 * len(existing.options)
                + 20 * len(existing.correct_answers)
            )
            if score_new > score_old:
                questions[number] = new

    return questions


# ---------------------------------------------------------------------------
# Excel JSON
# ---------------------------------------------------------------------------


@dataclass
class ExcelQuestion:
    number: int
    statement: str
    options: list[dict[str, str]]
    correct_answers: list[str]


def load_excel_questions() -> dict[int, ExcelQuestion]:
    if not EXCEL_JSON.is_file():
        sys.exit(f"[ERROR] {EXCEL_JSON} introuvable")
    with EXCEL_JSON.open(encoding="utf-8") as f:
        data = json.load(f)
    out: dict[int, ExcelQuestion] = {}
    for theme_questions in data.values():
        for q in theme_questions:
            number = q["numero_question"]
            statement = re.sub(r"\s+", " ", str(q.get("enonce", "")).strip())
            options: list[dict[str, str]] = []
            for letter in ("A", "B", "C", "D", "E"):
                key = f"option_{letter}"
                if key in q and q[key]:
                    text = re.sub(r"\s+", " ", str(q[key]).strip().rstrip(" .;,"))
                    options.append({"letter": letter, "text": text})
            answers_raw = str(q.get("reponses_correctes", ""))
            answers = [a.strip().upper() for a in re.split(r"[,;\-/\s]+", answers_raw)
                       if a.strip() and len(a.strip()) == 1 and a.strip().upper() in "ABCDE"]
            out[number] = ExcelQuestion(number, statement, options, answers)
    return out


# ---------------------------------------------------------------------------
# Comparaison
# ---------------------------------------------------------------------------


def normalize_for_compare(text: str) -> str:
    nfkd = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in nfkd if not unicodedata.combining(c))
    text = text.lower()
    text = re.sub(r"[^\w\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, normalize_for_compare(a), normalize_for_compare(b)).ratio()


@dataclass
class Divergence:
    number: int
    kind: str
    detail: str
    md: Any = None
    excel: Any = None


def compare_one(
    number: int,
    md_q: MdQuestion | None,
    excel_q: ExcelQuestion | None,
    min_sim: float,
) -> tuple[list[Divergence], dict[str, Any] | None]:
    divs: list[Divergence] = []

    if md_q is None and excel_q is not None:
        # Question Excel absente du .md : peut etre une question a options visuelles
        # (c'est le cas le plus commun). On ne propose pas d'override automatique.
        divs.append(Divergence(
            number, "missing_in_md",
            "Question presente dans l'Excel mais absente de questions.md "
            "(probablement options visuelles ou question manquante de la transcription)",
            excel=excel_q.statement[:100],
        ))
        return divs, None

    if excel_q is None and md_q is not None:
        divs.append(Divergence(
            number, "missing_in_excel",
            "Question presente dans questions.md mais absente de l'Excel",
            md=md_q.statement[:100],
        ))
        return divs, None

    if md_q is None or excel_q is None:
        return divs, None

    suggested: dict[str, Any] = {}

    # 1. Statement
    sim_stmt = similarity(md_q.statement, excel_q.statement)
    if sim_stmt < min_sim and md_q.statement and excel_q.statement:
        divs.append(Divergence(
            number, "statement_mismatch",
            f"similarite {sim_stmt:.2f} (< {min_sim})",
            md=md_q.statement, excel=excel_q.statement,
        ))
        suggested["statement"] = md_q.statement

    # 2. Options : nombre
    if len(md_q.options) != len(excel_q.options):
        divs.append(Divergence(
            number, "options_count_mismatch",
            f".md={len(md_q.options)} options, Excel={len(excel_q.options)} options",
            md=[o["letter"] for o in md_q.options],
            excel=[o["letter"] for o in excel_q.options],
        ))
        # On ne suggere les options du .md que si le .md en a plus que l'Excel
        # (cas typique : Excel a 0 options -> .md a 3-4 options propres)
        if len(md_q.options) > len(excel_q.options):
            suggested["options"] = md_q.options
    else:
        # 3. Options : texte
        opt_diffs: list[str] = []
        for mo, eo in zip(md_q.options, excel_q.options):
            if mo["letter"] != eo["letter"]:
                divs.append(Divergence(
                    number, "option_letter_mismatch",
                    f"position {mo['letter']} != {eo['letter']}",
                ))
                continue
            opt_sim = similarity(mo["text"], eo["text"])
            if opt_sim < min_sim:
                opt_diffs.append(mo["letter"])
                divs.append(Divergence(
                    number, "option_text_mismatch",
                    f"option {mo['letter']} similarite {opt_sim:.2f}",
                    md=mo["text"], excel=eo["text"],
                ))
        if opt_diffs:
            suggested.setdefault("options", md_q.options)

    # 4. Reponses : seul cas critique. Le .md est plus fiable que l'Excel sur ce point.
    if set(md_q.correct_answers) != set(excel_q.correct_answers):
        # Si les deux ont des reponses, on ne suggere QUE si l'Excel a un probleme
        # evident (ex: out-of-range vs options Excel). Sinon on flag pour revue.
        excel_letters = {o["letter"] for o in excel_q.options}
        excel_oor = any(a not in excel_letters for a in excel_q.correct_answers) if excel_q.options else False
        md_letters = {o["letter"] for o in md_q.options}
        md_oor = any(a not in md_letters for a in md_q.correct_answers) if md_q.options else False
        kind = "correct_answers_mismatch"
        if excel_oor and not md_oor:
            kind = "correct_answers_excel_invalid"
        elif md_oor and not excel_oor:
            kind = "correct_answers_md_invalid"
        divs.append(Divergence(
            number, kind,
            f".md={md_q.correct_answers}, Excel={excel_q.correct_answers}",
            md=md_q.correct_answers, excel=excel_q.correct_answers,
        ))
        # On suggere la reponse du .md uniquement si Excel est invalide
        if kind == "correct_answers_excel_invalid":
            suggested["correctAnswers"] = md_q.correct_answers

    if not suggested:
        return divs, None

    # Construire l'override
    out: dict[str, Any] = {"action": "patch"}
    if "statement" in suggested:
        out["statement"] = suggested["statement"]
    if "options" in suggested:
        out["options"] = suggested["options"]
    if "correctAnswers" in suggested:
        out["correctAnswers"] = suggested["correctAnswers"]
    kinds = sorted({d.kind for d in divs})
    out["reason"] = f".md != Excel sur : {', '.join(kinds)}"
    return divs, out


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--md", default=str(DEFAULT_MD), help="Chemin du fichier .md")
    parser.add_argument("--min-similarity", type=float, default=0.85,
                        help="Seuil de similarite (0-1). Defaut: 0.85")
    args = parser.parse_args()

    md_path = Path(args.md)
    if not md_path.is_file():
        sys.exit(f"[ERROR] {md_path} introuvable")

    md_text = md_path.read_text(encoding="utf-8")
    md_questions = parse_md_questions(md_text)
    print(f"Parser .md  : {len(md_questions)} questions extraites de {md_path.name}.")

    excel_questions = load_excel_questions()
    print(f"Excel JSON  : {len(excel_questions)} questions.")

    all_numbers = sorted(set(md_questions) | set(excel_questions))
    divergences: list[Divergence] = []
    suggested: dict[str, dict[str, Any]] = {}
    matched = 0
    for n in all_numbers:
        divs, override = compare_one(
            n,
            md_questions.get(n),
            excel_questions.get(n),
            args.min_similarity,
        )
        if not divs:
            matched += 1
        divergences.extend(divs)
        if override is not None:
            suggested[str(n)] = override

    summary_kinds: dict[str, int] = {}
    for d in divergences:
        summary_kinds[d.kind] = summary_kinds.get(d.kind, 0) + 1

    report = {
        "metadata": {
            "mdSource": str(md_path.relative_to(ROOT) if md_path.is_relative_to(ROOT) else md_path),
            "excelSource": EXCEL_JSON.name,
            "mdQuestions": len(md_questions),
            "excelQuestions": len(excel_questions),
            "intersection": len(set(md_questions) & set(excel_questions)),
            "matched": matched,
            "minSimilarity": args.min_similarity,
        },
        "summary": summary_kinds,
        "divergences": [
            {
                "number": d.number,
                "kind": d.kind,
                "detail": d.detail,
                **({"md": d.md} if d.md is not None else {}),
                **({"excel": d.excel} if d.excel is not None else {}),
            }
            for d in divergences
        ],
    }
    REPORT_JSON.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n",
                           encoding="utf-8")
    print(f"[OK] {REPORT_JSON.relative_to(ROOT)} ({len(divergences)} divergences)")

    suggested_payload = {
        "$schema": "manual-overrides-v1",
        "description": "Overrides candidats generes par validate_against_md.py. "
                       "REVUE HUMAINE REQUISE avant fusion dans manual-overrides.json. "
                       "Source : qcms_data/docs/questions.md (transcription la plus propre).",
        "appliedTo": "Questions_Permis_BJ.json",
        "generatedFrom": md_path.name,
        "overrides": suggested,
    }
    SUGGESTED_JSON.write_text(json.dumps(suggested_payload, ensure_ascii=False, indent=2) + "\n",
                              encoding="utf-8")
    print(f"[OK] {SUGGESTED_JSON.relative_to(ROOT)} ({len(suggested)} overrides candidats)")

    print()
    print("Resume des divergences :")
    for kind, count in sorted(summary_kinds.items()):
        print(f"  {kind}: {count}")
    print()
    intersection = len(set(md_questions) & set(excel_questions))
    print(f"Questions parfaitement concordantes : {matched}/{intersection} "
          f"de l'intersection ({100 * matched / max(1, intersection):.1f}%)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
