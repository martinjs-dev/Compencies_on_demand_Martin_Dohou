// =============================================================================
// Scénario 03 - Utilisateur authentifié (dashboard + quiz)
// =============================================================================
// Objectif : simuler des candidats connectés qui consultent leur progression,
//            démarrent un quiz et soumettent des réponses. Ces requêtes
//            touchent la base de données (pas de cache) - le test valide les
//            performances des requêtes Prisma sous charge.
//
// Prérequis :
//   K6_AUTH_TOKEN  JWT access token valide (obligatoire)
//   K6_QUIZ_ID     UUID d'un quiz existant (obligatoire)
//   K6_BASE_URL    URL de base de l'API (défaut: http://localhost:3000)
//
// Obtenir un token pour les tests :
//   1. Se connecter via POST /api/v1/auth puis POST /api/v1/auth/login/verify
//   2. Copier l'accessToken de la réponse
//   3. Exporter : export K6_AUTH_TOKEN="eyJhbGci..."
//
// Profil de charge :
//   0 -> 10 VUs en 1 min  (montée progressive)
//   10 VUs pendant 3 min  (charge stable)
//   10 -> 0 VUs en 30 s   (descente)
//
// Thresholds :
//   p95 < 500 ms  (requêtes DB, latence acceptable)
//   p99 < 2000 ms (seuil critique)
//   error rate < 1%
//
// Usage :
//   K6_AUTH_TOKEN="<token>" K6_QUIZ_ID="<uuid>" k6 run k6/03-authenticated-user.k6.js
// =============================================================================

import { check, sleep, fail } from 'k6';
import http from 'k6/http';
import { randomIntBetween } from 'https://jslib.k6.io/k6-utils/1.4.0/index.js';
import { buildHeaders, checkApiShape } from './helpers/http.js';

const BASE_URL = __ENV.K6_BASE_URL || 'http://localhost:3000';
const API = `${BASE_URL}/api/v1`;
const AUTH_TOKEN = __ENV.K6_AUTH_TOKEN;
const QUIZ_ID = __ENV.K6_QUIZ_ID;

// Validation des variables d'environnement au démarrage
export function setup() {
  if (!AUTH_TOKEN) {
    fail(
      'K6_AUTH_TOKEN est requis. Exportez un JWT valide avant de lancer le test.',
    );
  }
  if (!QUIZ_ID) {
    fail(
      "K6_QUIZ_ID est requis. Exportez l'UUID d'un quiz existant.",
    );
  }
  return { token: AUTH_TOKEN, quizId: QUIZ_ID };
}

export const options = {
  stages: [
    { duration: '1m', target: 10 },  // Montée progressive
    { duration: '3m', target: 10 },  // Charge stable
    { duration: '30s', target: 0 },  // Descente
  ],
  thresholds: {
    // Requêtes DB - latence cible < 500 ms au p95
    http_req_duration: ['p(95)<500', 'p(99)<2000'],
    // Moins de 1% d'erreurs
    http_req_failed: ['rate<0.01'],
    // 95% des checks réussis
    checks: ['rate>0.95'],
  },
};

export default function ({ token, quizId }) {
  const headers = buildHeaders(token);

  // -------------------------------------------------------------------------
  // 1. Vérification du profil (GET /auth/me)
  // -------------------------------------------------------------------------
  const meRes = http.get(`${API}/auth/me`, { headers });
  check(meRes, { 'auth/me - 200': (r) => r.status === 200 });
  checkApiShape(meRes, 'auth/me');
  sleep(randomIntBetween(1, 2));

  // -------------------------------------------------------------------------
  // 2. Statistiques de progression (GET /users/me/stats)
  //    Requête agrégée : lessons, courses, quiz - représentatif de la DB
  // -------------------------------------------------------------------------
  const statsRes = http.get(`${API}/users/me/stats`, { headers });
  check(statsRes, { 'users/me/stats - 200': (r) => r.status === 200 });
  checkApiShape(statsRes, 'users/me/stats');
  sleep(randomIntBetween(1, 2));

  // -------------------------------------------------------------------------
  // 3. Progression globale (GET /progression/me)
  //    Cours inscrits + leçons complétées
  // -------------------------------------------------------------------------
  const progressionRes = http.get(`${API}/progression/me`, { headers });
  check(progressionRes, {
    'progression/me - 200': (r) => r.status === 200,
  });
  checkApiShape(progressionRes, 'progression/me');
  sleep(randomIntBetween(1, 3));

  // -------------------------------------------------------------------------
  // 4. Liste des quiz disponibles (GET /quizzes?page=1&limit=10)
  // -------------------------------------------------------------------------
  const quizzesPage = randomIntBetween(1, 3);
  const quizzesRes = http.get(
    `${API}/quizzes?page=${quizzesPage}&limit=10`,
    { headers },
  );
  check(quizzesRes, { 'quizzes - 200': (r) => r.status === 200 });
  sleep(randomIntBetween(1, 2));

  // -------------------------------------------------------------------------
  // 5. Démarrage d'une tentative de quiz (POST /quizzes/:id/attempts)
  //    Requête d'écriture - insère en base et charge les questions
  // -------------------------------------------------------------------------
  const attemptRes = http.post(
    `${API}/quizzes/${quizId}/attempts`,
    JSON.stringify({}),
    { headers },
  );
  check(attemptRes, {
    'quiz attempt - 201 ou 200': (r) =>
      r.status === 201 || r.status === 200,
    "quiz attempt - pas d'erreur 5xx": (r) => r.status < 500,
  });
  sleep(randomIntBetween(2, 4));

  // -------------------------------------------------------------------------
  // 6. Récupération des questions (GET /quizzes/:id/questions)
  //    Simule l'affichage du quiz en cours
  // -------------------------------------------------------------------------
  const questionsRes = http.get(
    `${API}/quizzes/${quizId}/questions`,
    { headers },
  );
  check(questionsRes, {
    'quiz questions - 200': (r) => r.status === 200,
  });
  sleep(randomIntBetween(3, 6)); // Temps de lecture des questions
}
