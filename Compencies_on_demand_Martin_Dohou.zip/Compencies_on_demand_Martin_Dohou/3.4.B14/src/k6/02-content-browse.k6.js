// =============================================================================
// Scénario 02 - Content browsing (charge progressive, contenu public)
// =============================================================================
// Objectif : simuler N candidats qui naviguent dans le contenu public
//            (cours, thèmes, FAQ, annuaire). Ces endpoints sont mis en cache
//            par Redis - le test valide que le cache absorbe la charge.
//
// Profil de charge :
//   0 -> 20 VUs en 1 min  (montée progressive)
//   20 VUs pendant 3 min  (charge stable)
//   20 -> 0 VUs en 30 s   (descente)
//
// Thresholds :
//   p95 < 200 ms  (Redis cache, latence attendue faible)
//   error rate < 1%
//
// Usage :
//   k6 run k6/02-content-browse.k6.js
//   K6_BASE_URL=https://api.example.com k6 run k6/02-content-browse.k6.js
// =============================================================================

import { check, sleep } from 'k6';
import http from 'k6/http';
import { randomIntBetween } from 'https://jslib.k6.io/k6-utils/1.4.0/index.js';
import { buildHeaders, checkApiShape } from './helpers/http.js';

const BASE_URL = __ENV.K6_BASE_URL || 'http://localhost:3000';
const API = `${BASE_URL}/api/v1`;

export const options = {
  stages: [
    { duration: '1m', target: 20 },  // Montée progressive
    { duration: '3m', target: 20 },  // Charge stable
    { duration: '30s', target: 0 },  // Descente
  ],
  thresholds: {
    // Endpoints mis en cache Redis - latence cible < 200 ms au p95
    http_req_duration: ['p(95)<200', 'p(99)<500'],
    // Moins de 1% d'erreurs
    http_req_failed: ['rate<0.01'],
    // 95% des checks réussis
    checks: ['rate>0.95'],
  },
};

// Simule un utilisateur qui navigue dans le catalogue
export default function () {
  const headers = buildHeaders();

  // --- Visite la page d'accueil du catalogue ---
  const coursesPage = randomIntBetween(1, 5);
  const coursesRes = http.get(
    `${API}/courses/public?page=${coursesPage}&limit=20`,
    { headers },
  );
  check(coursesRes, {
    'courses/public - 200': (r) => r.status === 200,
  });
  checkApiShape(coursesRes, 'courses/public');
  sleep(randomIntBetween(1, 3));

  // --- Parcourt les thèmes ---
  const themesRes = http.get(`${API}/themes`, { headers });
  check(themesRes, { 'themes - 200': (r) => r.status === 200 });
  sleep(randomIntBetween(1, 2));

  // --- Consulte la FAQ ---
  const faqRes = http.get(`${API}/faq`, { headers });
  check(faqRes, { 'faq - 200': (r) => r.status === 200 });
  sleep(randomIntBetween(1, 2));

  // --- Annuaire des écoles (avec pagination aléatoire) ---
  const schoolsPage = randomIntBetween(1, 3);
  const schoolsRes = http.get(
    `${API}/directory/schools?page=${schoolsPage}&limit=10`,
    { headers },
  );
  check(schoolsRes, { 'directory/schools - 200': (r) => r.status === 200 });
  sleep(randomIntBetween(1, 2));

  // --- Plans d'abonnement (liste statique, fortement mis en cache) ---
  const plansRes = http.get(`${API}/subscription-plans`, { headers });
  check(plansRes, { 'subscription-plans - 200': (r) => r.status === 200 });
  sleep(randomIntBetween(2, 4));
}
