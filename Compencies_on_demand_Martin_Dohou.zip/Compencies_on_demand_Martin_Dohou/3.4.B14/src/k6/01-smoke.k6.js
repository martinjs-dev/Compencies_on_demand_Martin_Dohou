// =============================================================================
// Scénario 01 - Smoke test
// =============================================================================
// Objectif : vérifier que tous les endpoints publics clés répondent correctement
//            avec une charge minimale (1 VU, 1 itération par endpoint).
//
// Usage :
//   k6 run k6/01-smoke.k6.js
//   K6_BASE_URL=https://api.example.com k6 run k6/01-smoke.k6.js
// =============================================================================

import { check, sleep } from 'k6';
import http from 'k6/http';
import { buildHeaders } from './helpers/http.js';

const BASE_URL = __ENV.K6_BASE_URL || 'http://localhost:3000';
const API = `${BASE_URL}/api/v1`;

export const options = {
  vus: 1,
  iterations: 1,
  thresholds: {
    // Chaque requête doit répondre en moins de 3s (seuil permissif pour smoke)
    http_req_duration: ['p(100)<3000'],
    // Aucune erreur tolérée en smoke test
    http_req_failed: ['rate<0.01'],
    checks: ['rate==1.0'],
  },
};

export default function () {
  const headers = buildHeaders();

  // -------------------------------------------------------------------------
  // Health checks
  // -------------------------------------------------------------------------
  let res;

  res = http.get(`${BASE_URL}/api/health/live`, { headers });
  check(res, { 'health/live - 200': (r) => r.status === 200 });
  sleep(0.2);

  res = http.get(`${BASE_URL}/api/health/ready`, { headers });
  check(res, { 'health/ready - 200': (r) => r.status === 200 });
  sleep(0.2);

  // -------------------------------------------------------------------------
  // Contenu public (cache Redis attendu)
  // -------------------------------------------------------------------------

  res = http.get(`${API}/courses/public`, { headers });
  check(res, {
    'courses/public - 200': (r) => r.status === 200,
    'courses/public - body JSON valide': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.success === true;
      } catch {
        return false;
      }
    },
  });
  sleep(0.2);

  res = http.get(`${API}/themes`, { headers });
  check(res, { 'themes - 200': (r) => r.status === 200 });
  sleep(0.2);

  res = http.get(`${API}/faq`, { headers });
  check(res, { 'faq - 200': (r) => r.status === 200 });
  sleep(0.2);

  res = http.get(`${API}/directory/schools`, { headers });
  check(res, { 'directory/schools - 200': (r) => r.status === 200 });
  sleep(0.2);

  res = http.get(`${API}/directory/monitors`, { headers });
  check(res, { 'directory/monitors - 200': (r) => r.status === 200 });
  sleep(0.2);

  res = http.get(`${API}/subscription-plans`, { headers });
  check(res, { 'subscription-plans - 200': (r) => r.status === 200 });
  sleep(0.2);

  // -------------------------------------------------------------------------
  // Routes protégées (doivent retourner 401 sans token)
  // -------------------------------------------------------------------------

  res = http.get(`${API}/users/me`, { headers });
  check(res, { 'users/me sans token - 401': (r) => r.status === 401 });
  sleep(0.2);

  res = http.get(`${API}/progression/me`, { headers });
  check(res, { 'progression/me sans token - 401': (r) => r.status === 401 });
  sleep(0.2);

  // -------------------------------------------------------------------------
  // Metrics Prometheus
  // -------------------------------------------------------------------------

  res = http.get(`${BASE_URL}/metrics`, { headers });
  check(res, {
    'metrics - 200': (r) => r.status === 200,
    'metrics - format texte Prometheus': (r) =>
      r.headers['Content-Type'] !== undefined &&
      r.headers['Content-Type'].includes('text/plain'),
  });
}
