// =============================================================================
// k6 Load Test - Chat WebSocket
// =============================================================================
//
// Profil :
//   - Ramp 100 → 1000 connexions WebSocket sur 5 min
//   - Steady state 30 min : 50% chat actif (1 msg/30s), 50% idle
//   - Métriques cibles : p95 latence ACK < 500ms, error rate < 0.1%
//
// Pré-requis :
//   - k6 + xk6 avec extension WebSocket Socket.io (xk6-socketio recommandé)
//     OU utiliser le module standard `k6/ws` avec encodage Engine.IO manuel
//   - JWT tokens de test pré-générés (script TOKENS_FILE=tokens.json)
//   - Env staging accessible (pas la prod)
//
// Usage :
//   K6_BASE_URL=https://staging-api.example.com \
//   K6_TOKENS_FILE=tokens.json \
//   k6 run tests/load/chat-load.js
//
// Voir tests/load/README.md pour la génération des tokens et l'analyse.
// =============================================================================

import ws from 'k6/ws';
import { check, sleep } from 'k6';
import { Counter, Trend, Rate } from 'k6/metrics';
import { SharedArray } from 'k6/data';

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const BASE_URL = __ENV.K6_BASE_URL || 'http://localhost:3000';
const TOKENS_FILE = __ENV.K6_TOKENS_FILE || 'tokens.json';
const TARGET_VUS = parseInt(__ENV.K6_TARGET_VUS || '1000', 10);
const STEADY_DURATION = __ENV.K6_STEADY_DURATION || '30m';

const tokens = new SharedArray('tokens', () =>
  JSON.parse(open(TOKENS_FILE)),
);

// ---------------------------------------------------------------------------
// Custom metrics
// ---------------------------------------------------------------------------

const ackLatency = new Trend('ws_ack_latency_ms', true);
const ackErrors = new Counter('ws_ack_errors');
const ackSuccesses = new Counter('ws_ack_successes');
const errorRate = new Rate('ws_error_rate');

// ---------------------------------------------------------------------------
// Scenarios
// ---------------------------------------------------------------------------

export const options = {
  scenarios: {
    chat_load: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '5m', target: TARGET_VUS }, // Ramp 0 → 1000 sur 5 min
        { duration: STEADY_DURATION, target: TARGET_VUS }, // Steady
        { duration: '2m', target: 0 }, // Ramp down
      ],
      gracefulRampDown: '30s',
    },
  },
  thresholds: {
    ws_ack_latency_ms: ['p(95)<500'], // p95 ACK < 500ms
    ws_error_rate: ['rate<0.001'], // < 0.1% erreurs
  },
};

// ---------------------------------------------------------------------------
// VU function
// ---------------------------------------------------------------------------

export default function () {
  const tokenEntry = tokens[__VU % tokens.length];
  const url = `${BASE_URL.replace(/^http/, 'ws')}/socket.io/?EIO=4&transport=websocket&namespace=/chat`;

  const params = {
    headers: {
      Authorization: `Bearer ${tokenEntry.accessToken}`,
    },
  };

  // Pattern : 50% des VUs envoient des messages, 50% restent idle (lecture)
  const isSender = __VU % 2 === 0;

  const res = ws.connect(url, params, function (socket) {
    const sendStartTimes = new Map(); // requestId → timestamp ms

    socket.on('open', () => {
      // Auth payload Socket.io (engine.io v4 format)
      socket.send(`40/chat,{"token":"${tokenEntry.accessToken}"}`);
    });

    socket.on('message', (raw) => {
      // Format Socket.io : `42/chat,["chat:message:ack",{...}]`
      const match = raw.match(/^42\/chat,(\[.+\])$/);
      if (!match) return;
      try {
        const [event, data] = JSON.parse(match[1]);
        if (event === 'chat:message:ack' && data?.requestId) {
          const start = sendStartTimes.get(data.requestId);
          if (start !== undefined) {
            ackLatency.add(Date.now() - start);
            sendStartTimes.delete(data.requestId);
            ackSuccesses.add(1);
            errorRate.add(false);
          }
        }
        if (event === 'chat:error') {
          ackErrors.add(1);
          errorRate.add(true);
        }
      } catch {
        // ignore parse errors
      }
    });

    socket.on('error', () => {
      errorRate.add(true);
    });

    if (isSender) {
      // Envoie un message toutes les 30s
      socket.setInterval(() => {
        const requestId = `${__VU}-${Date.now()}`;
        const conversationId = tokenEntry.conversationId;
        sendStartTimes.set(requestId, Date.now());
        socket.send(
          `42/chat,["chat:send",{"conversationId":"${conversationId}","content":"load test","requestId":"${requestId}"}]`,
        );
      }, 30_000);
    }

    // Tient la connexion ouverte pour la durée du test
    socket.setTimeout(() => {
      socket.close();
    }, parseInt(STEADY_DURATION, 10) * 60_000 + 60_000);
  });

  check(res, { 'connected': (r) => r && r.status === 101 });
  sleep(1);
}
