#!/usr/bin/env bash
# Script de provisionnement KVM4 pour OryStack
# Compatible : Ubuntu 24.04 LTS (identique à KVM2)
# Usage : bash provision-kvm4.sh
set -euo pipefail

COOLIFY_VERSION="4.0.0-beta.463"
UBUNTU_CODENAME="noble"  # Ubuntu 24.04 LTS

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"; }

log "=== PROVISIONNEMENT KVM4 - OryStack ==="
log "OS cible : Ubuntu 24.04 LTS"
log "Coolify cible : $COOLIFY_VERSION"

# --- Étape 1 : Mise à jour du système ---
log "[1/7] Mise à jour du système..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -q
apt-get upgrade -y -q

# --- Étape 2 : Packages de base ---
log "[2/7] Installation des packages de base..."
apt-get install -y -q \
  curl wget git unzip \
  ufw fail2ban \
  ca-certificates gnupg lsb-release \
  htop ncdu net-tools

# --- Étape 3 : Configuration UFW (Firewall) ---
log "[3/7] Configuration UFW..."
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp comment "SSH"
ufw allow 80/tcp comment "HTTP"
ufw allow 443/tcp comment "HTTPS"
ufw allow 8000/tcp comment "Coolify Dashboard"
ufw --force enable
ufw status verbose

# --- Étape 4 : Configuration fail2ban ---
log "[4/7] Configuration fail2ban..."
cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime  = 1h
findtime = 10m
maxretry = 5
destemail = root@localhost
action = %(action_mwl)s

[sshd]
enabled = true
port    = ssh
logpath = %(sshd_log)s
backend = %(sshd_backend)s
maxretry = 3
EOF
systemctl enable fail2ban
systemctl restart fail2ban

# --- Étape 5 : Installation Docker ---
log "[5/7] Installation Docker (version identique KVM2)..."
# Supprimer les vieilles versions si présentes
apt-get remove -y docker docker.io containerd runc 2>/dev/null || true
apt-get remove -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin 2>/dev/null || true

# Ajouter le dépôt officiel Docker
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
chmod a+r /etc/apt/keyrings/docker.gpg
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  tee /etc/apt/sources.list.d/docker.list > /dev/null

apt-get update -q
apt-get install -y -q docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

systemctl enable docker
systemctl start docker

log "Docker version : $(docker --version)"
log "Docker Compose version : $(docker compose version)"

# --- Étape 6 : Installation Coolify ---
log "[6/7] Installation Coolify $COOLIFY_VERSION..."
mkdir -p /data/coolify
curl -fsSL https://cdn.coollabs.io/coolify/install.sh | bash -s -- --version "$COOLIFY_VERSION"

# --- Étape 7 : Vérifications ---
log "[7/7] Vérifications finales..."
sleep 10

# Test Docker
docker ps
log "✓ Docker opérationnel"

# Test Coolify (attend que les conteneurs démarrent)
COOLIFY_URL="http://localhost:8000"
MAX_WAIT=120
WAITED=0
while [ $WAITED -lt $MAX_WAIT ]; do
  if curl -s -o /dev/null -w "%{http_code}" "$COOLIFY_URL" | grep -q "200\|302"; then
    log "✓ Coolify accessible sur $COOLIFY_URL"
    break
  fi
  sleep 5
  WAITED=$((WAITED + 5))
done

if [ $WAITED -ge $MAX_WAIT ]; then
  log "⚠️  Coolify pas encore accessible (attendre encore quelques minutes)"
fi

log "=== PROVISIONNEMENT TERMINÉ ==="
log "Coolify Dashboard : http://$(curl -s ifconfig.me):8000"
log ""
log "PROCHAINES ÉTAPES :"
log "1. Se connecter au dashboard Coolify et créer le compte admin"
log "2. Configurer les clés SSH dans Coolify"
log "3. Baisser le TTL DNS à 300s pour tous les domaines"
log "4. Notifier DevOps Engineer de l'IP KVM4 pour la migration"
