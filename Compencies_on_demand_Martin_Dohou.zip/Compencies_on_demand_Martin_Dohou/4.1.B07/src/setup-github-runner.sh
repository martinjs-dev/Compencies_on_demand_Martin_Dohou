#!/usr/bin/env bash
# ==============
# setup-github-runner.sh - Installe un runner GitHub Actions self-hosted
#                          en service systemd sur l'hote Coolify
# ==============
#
# A lancer EN ROOT sur le serveur, apres avoir genere un jeton d'enregistrement
# sur https://github.com/organizations/OryStack/settings/actions/runners/new
# (ce jeton expire au bout d'environ 1 heure).
#
#   sudo RUNNER_TOKEN=AXXXXXXXXXXXXXXXXXXXXXXXXX ./setup-github-runner.sh
#
# Pourquoi un service systemd et non `./run.sh` : `run.sh` est un processus au
# premier plan, il meurt a la fermeture de la session SSH et ne repart pas au
# redemarrage du serveur. `svc.sh install` pose une unite systemd qui survit
# aux deux.
#
# Variables surchargeables :
#   RUNNER_TOKEN    (obligatoire) jeton d'enregistrement, valable ~1 h
#   RUNNER_URL      cible de l'enregistrement            (defaut: org OryStack)
#   RUNNER_NAME     nom affiche dans GitHub              (defaut: coolify-01)
#   RUNNER_LABELS   labels, cibles par `runs-on:`        (defaut: coolify)
#   RUNNER_USER     compte systeme dedie                 (defaut: ghrunner)
#   RUNNER_VERSION  version du runner                    (defaut: 2.337.0)
#   RUNNER_SHA256   somme SHA-256 attendue de l'archive  (defaut: connue en x64)
#   RUNNER_GROUP    groupe de runners de l'organisation  (defaut: Default)

set -euo pipefail

RUNNER_VERSION="${RUNNER_VERSION:-2.337.0}"
RUNNER_URL="${RUNNER_URL:-https://github.com/OryStack}"
RUNNER_TOKEN="${RUNNER_TOKEN:-}"
RUNNER_NAME="${RUNNER_NAME:-coolify-01}"
RUNNER_LABELS="${RUNNER_LABELS:-coolify}"
RUNNER_USER="${RUNNER_USER:-ghrunner}"
RUNNER_GROUP="${RUNNER_GROUP:-Default}"

# Somme publiee par GitHub pour la 2.337.0 en x64. Pour arm64, ou pour toute
# autre version, la recopier depuis la page "Create self-hosted runner" via
# RUNNER_SHA256=... : le script refuse de verifier une somme qu'il ne connait
# pas plutot que d'en inventer une.
SHA256_2_337_0_x64="70920811a4f8ad4328818682bca5c6469c1c942fab52448868071d0063816613"

log()  { printf '\033[1;34m[runner]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[runner]\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31m[runner]\033[0m %s\n' "$*" >&2; exit 1; }

# Execute une commande sous le compte du runner. `runuser` fait partie de
# util-linux, donc toujours present, la ou `sudo` peut manquer sur un serveur
# minimal alors que ce script tourne deja en root.
as_runner() {
  if command -v runuser >/dev/null 2>&1; then
    runuser -u "$RUNNER_USER" -- "$@"
  else
    sudo -u "$RUNNER_USER" "$@"
  fi
}

# --- Prealables -------------------------------------------------------------

[ "$(id -u)" -eq 0 ] || die "A lancer en root (sudo)."
[ -n "$RUNNER_TOKEN" ] || die "RUNNER_TOKEN manquant. Generez-en un sur GitHub (valable ~1 h)."

command -v systemctl >/dev/null 2>&1 || die "systemd introuvable : ce script ne convient pas a cet hote."
command -v curl >/dev/null 2>&1 || die "curl manquant (apt install curl)."
command -v tar  >/dev/null 2>&1 || die "tar manquant (apt install tar)."

# Docker est indispensable, pas optionnel : les jobs `check_prisma` et
# `run_tests` de quality-check.yml declarent `services: postgres:16-alpine`,
# que le runner demarre comme conteneur. Sans Docker ces jobs echouent au
# demarrage du service, avant meme le checkout.
command -v docker >/dev/null 2>&1 || die "Docker manquant. Sur un hote Coolify il devrait deja etre installe."
docker info >/dev/null 2>&1 || die "Le daemon Docker ne repond pas (systemctl status docker)."

# --- Architecture -----------------------------------------------------------

case "$(uname -m)" in
  x86_64)          RUNNER_ARCH="x64" ;;
  aarch64 | arm64) RUNNER_ARCH="arm64" ;;
  *)               die "Architecture non geree par le runner GitHub : $(uname -m)" ;;
esac
log "Architecture detectee : $(uname -m) -> ${RUNNER_ARCH}"

if [ "$RUNNER_ARCH" = "arm64" ]; then
  warn "Hote arm64. Deux consequences a connaitre AVANT de router des jobs ici :"
  warn "  1. Ni deploy-api-*.yml ni deploy-web-*.yml ne fixent 'platforms:' dans"
  warn "     docker/build-push-action : les images publiees suivraient donc"
  warn "     l'architecture de CET hote. Elles seraient arm64, la ou"
  warn "     ubuntu-latest produisait de l'amd64."
  warn "  2. Google ne publie pas de build-tools Android pour Linux/arm64 :"
  warn "     distribute-android-*.yml doit rester sur ubuntu-latest."
fi

ARCHIVE="actions-runner-linux-${RUNNER_ARCH}-${RUNNER_VERSION}.tar.gz"
DOWNLOAD_URL="https://github.com/actions/runner/releases/download/v${RUNNER_VERSION}/${ARCHIVE}"

EXPECTED_SHA256="${RUNNER_SHA256:-}"
if [ -z "$EXPECTED_SHA256" ] && [ "$RUNNER_VERSION" = "2.337.0" ] && [ "$RUNNER_ARCH" = "x64" ]; then
  EXPECTED_SHA256="$SHA256_2_337_0_x64"
fi

# --- Compte dedie -----------------------------------------------------------

# Un compte a lui, jamais root : le runner execute le contenu des depots, et
# `RUNNER_ALLOW_RUNASROOT` donnerait a ce contenu les pleins pouvoirs sur
# l'hote sans le moindre garde-fou.
if id "$RUNNER_USER" >/dev/null 2>&1; then
  log "Compte ${RUNNER_USER} deja present."
else
  log "Creation du compte ${RUNNER_USER}."
  useradd -m -s /bin/bash "$RUNNER_USER"
fi

# Appartenance au groupe docker : requise pour les `services:` et les
# `docker build` des workflows de deploiement. A savoir, et a assumer : le
# groupe docker equivaut a un acces root sur l'hote. Tout workflow capable de
# tourner ici peut donc en prendre le controle.
if getent group docker >/dev/null 2>&1; then
  usermod -aG docker "$RUNNER_USER"
  log "Compte ${RUNNER_USER} ajoute au groupe docker."
else
  die "Groupe docker absent : installation Docker inhabituelle, a verifier a la main."
fi

RUNNER_HOME="$(getent passwd "$RUNNER_USER" | cut -d: -f6)/actions-runner"

# --- Telechargement ---------------------------------------------------------

install -d -o "$RUNNER_USER" -g "$RUNNER_USER" -m 755 "$RUNNER_HOME"

if [ -x "${RUNNER_HOME}/config.sh" ]; then
  log "Runner deja extrait dans ${RUNNER_HOME}, telechargement saute."
else
  log "Telechargement de ${ARCHIVE}."
  as_runner curl --fail --location --show-error --silent \
    -o "${RUNNER_HOME}/${ARCHIVE}" "$DOWNLOAD_URL"

  if [ -n "$EXPECTED_SHA256" ]; then
    log "Verification de la somme SHA-256."
    echo "${EXPECTED_SHA256}  ${RUNNER_HOME}/${ARCHIVE}" | sha256sum -c - \
      || die "Somme SHA-256 incorrecte : archive corrompue ou alteree, on s'arrete."
  else
    warn "Aucune somme connue pour ${RUNNER_VERSION}/${RUNNER_ARCH}."
    warn "Recopiez celle affichee par GitHub dans RUNNER_SHA256=... pour la verifier."
  fi

  log "Extraction."
  as_runner tar xzf "${RUNNER_HOME}/${ARCHIVE}" -C "$RUNNER_HOME"
  rm -f "${RUNNER_HOME}/${ARCHIVE}"
fi

# --- Enregistrement ---------------------------------------------------------

if [ -f "${RUNNER_HOME}/.runner" ]; then
  log "Runner deja enregistre, configuration sautee."
  log "Pour le re-enregistrer : sudo -u ${RUNNER_USER} ${RUNNER_HOME}/config.sh remove --token <JETON>"
else
  log "Enregistrement aupres de ${RUNNER_URL} sous le nom ${RUNNER_NAME}."
  as_runner "${RUNNER_HOME}/config.sh" \
    --url "$RUNNER_URL" \
    --token "$RUNNER_TOKEN" \
    --name "$RUNNER_NAME" \
    --labels "$RUNNER_LABELS" \
    --runnergroup "$RUNNER_GROUP" \
    --work "_work" \
    --unattended \
    --replace
fi

# --- Service systemd --------------------------------------------------------

log "Installation du service systemd."
( cd "$RUNNER_HOME" && ./svc.sh install "$RUNNER_USER" )
( cd "$RUNNER_HOME" && ./svc.sh start )

sleep 2
( cd "$RUNNER_HOME" && ./svc.sh status ) || true

cat <<EOF

$(log "Termine.")

  Runner      : ${RUNNER_NAME}
  Labels      : ${RUNNER_LABELS}
  Repertoire  : ${RUNNER_HOME}
  Compte      : ${RUNNER_USER} (membre du groupe docker)

  Pour lui envoyer un job, dans un workflow :   runs-on: ${RUNNER_LABELS%%,*}

  Etat      : cd ${RUNNER_HOME} && sudo ./svc.sh status
  Journaux  : sudo journalctl -u "actions.runner.*" -f
  Arret     : cd ${RUNNER_HOME} && sudo ./svc.sh stop
  Retrait   : cd ${RUNNER_HOME} && sudo ./svc.sh uninstall \\
                && sudo -u ${RUNNER_USER} ./config.sh remove --token <NOUVEAU_JETON>

  Surveillez le disque : le runner ne purge jamais ${RUNNER_HOME}/_work tout seul.

EOF
