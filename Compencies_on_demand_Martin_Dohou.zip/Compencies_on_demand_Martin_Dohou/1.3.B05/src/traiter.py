#!/usr/bin/env python3
"""Etage 5 — Nettoyage, normalisation et encodage (LECTURE SEULE sur la source).

Chaine, dans cet ordre imperatif :

    source (aac/m4a/mp3/opus)
      -> WAV 48 kHz mono              (DeepFilterNet travaille en 48 kHz)
      -> DeepFilterNet                (debruitage sur le signal BRUT)
      -> trim des silences            (debut et fin uniquement, jamais au milieu)
      -> acompressor                  (resserre la dynamique interne)
      -> passe-haut 80 Hz             (rumbles de manipulation du telephone)
      -> loudnorm double passe        (-16 LUFS a l'arrivee, True Peak -1,5)
      -> HE-AAC v1 32 kbit/s mono     (fdkaac + libfdk-aac compilee, cf. plus bas)
      -> q-<numero>.m4a               (le numero vient du nom de la source)

Debruiter APRES normalisation reviendrait a amplifier le bruit puis a demander
a DeepFilterNet de le retirer : l'ordre n'est pas negociable.

La decoupe de l'annonce parlee (« Question 47 ») ne fait PAS partie de cette
chaine : elle se fera au fil de l'eau, plus tard, sur les sorties.

Usage :
    traiter.py --demo                          avant/apres sur 3 fichiers types
    traiter.py --langue Fr --limite 20         essai sur 20 fichiers
    traiter.py --langue Fr --profil lc48       une langue entiere
    traiter.py --langue Goun --source ~/Goun_renomme
"""
from __future__ import annotations

import argparse
import csv
import json
import multiprocessing
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

DOSSIER_SCRIPT = os.path.dirname(os.path.abspath(__file__))

# Sur la machine d'origine, les audios vivent dans Assets/Audios. Ailleurs —
# une seconde machine, une cle USB — on se rabat sur le dossier du script :
# il suffit alors d'y deposer un dossier par langue et de lancer sans
# argument. Aucun chemin a retenir.
_RACINE_PROJET = "/home/martin-js/Martin_JS/Permis-BJ/Assets/Audios"
RACINE_DEFAUT = os.environ.get(
    "PERMIS_AUDIO_ROOT",
    _RACINE_PROJET if os.path.isdir(os.path.join(_RACINE_PROJET, "Originaux"))
    else DOSSIER_SCRIPT)

EXT_AUDIO = (".aac", ".m4a", ".mp3", ".opus", ".wav", ".ogg")

# Cible de normalisation : standard voix mobile.
LUFS_CIBLE = -16.0
TRUE_PEAK = -1.5
LRA_CIBLE = 11.0

# HE-AAC exige le module SBR, absent de la libfdk-aac livree par Ubuntu (la
# variante "fdk-aac-free" est expurgee des modules brevetes). La bibliotheque
# complete de Fraunhofer a donc ete compilee dans ~/.local ; le binaire
# /usr/bin/fdkaac, lui, n'a pas bouge — il charge simplement la notre quand
# LD_LIBRARY_PATH la designe. Rien n'est modifie au niveau systeme.
#
#   cmake -S fdk-aac -B build -DBUILD_SHARED_LIBS=ON \
#         -DCMAKE_INSTALL_PREFIX=$HOME/.local && cmake --build build -j
#
# `aot` est le profil AAC passe a fdkaac : 2 = LC, 5 = HE-AAC v1 (avec SBR).
LIB_FDK = os.path.expanduser("~/.local/lib")

# `derive` : de combien le codec remonte le niveau perçu. SBR reconstruit les
# aigus, donc ajoute de l'energie, et la ponderation K de la mesure LUFS
# accentue justement les aigus : un WAV normalise a -16 ressort a -13,1.
# Mesure sur 15 fichiers francais : +2,89 LU, ecart-type 0,09, etendue +2,68
# a +3,05 — assez stable pour etre compensee en amont. En AAC-LC la derive est
# nulle (-0,03), ce qui confirme que SBR en est bien la cause.
#
# `derive_tp` : meme phenomene sur la crete, mais lui n'est PAS constant. Sur
# les 2 786 premiers fichiers encodes, la crete est montee jusqu'a +1,7 dBTP
# alors que le WAV visait -1,5 — soit +3,2 dB de derive, contre +0,5 en
# moyenne. Dix fichiers d'Adja et un de Bariba ont ainsi depasse le plein
# echelle. On prend donc une marge, quitte a ce que la crete finale soit
# souvent plus basse que necessaire : un fichier trop sage ne s'entend pas,
# un fichier ecrete si.
PROFILS = {
    "he32": {"debit": 32000, "freq": 48000, "aot": 5,
             "derive": 2.9, "derive_tp": 2.5,
             "libelle": "HE-AAC v1 32 kbit/s mono, 48 kHz — le brief"},
    "lc32": {"debit": 32000, "freq": 24000, "aot": 2,
             "derive": 0.0, "derive_tp": 0.3,
             "libelle": "AAC-LC 32 kbit/s mono, 24 kHz — repli sans SBR"},
    "lc48": {"debit": 48000, "freq": 24000, "aot": 2,
             "derive": 0.0, "derive_tp": 0.3,
             "libelle": "AAC-LC 48 kbit/s mono, 24 kHz"},
    "lc64": {"debit": 64000, "freq": 32000, "aot": 2,
             "derive": 0.0, "derive_tp": 0.3,
             "libelle": "AAC-LC 64 kbit/s mono, 32 kHz — confort"},
}
PROFIL_DEFAUT = "he32"

# Numerotation des questions. Le nom de sortie attendu par l'application.
MAX_QUESTION = 930
PREFIXE_SORTIE = "q-"

# Fichiers temoins pour la demo : les cas les plus difficiles du corpus.
TEMOINS = [
    ("Goun", None, "le plus fort du corpus (pic au plafond)"),
    ("Dendi", None, "le plus faible du corpus (-27 dB)"),
    ("Ditamari", None, "enregistre en 16 kHz (timbre mat)"),
]


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=600, **kw)


def deep_filter_dispo() -> str | None:
    for c in (shutil.which("deep-filter"),
              os.path.expanduser("~/.local/bin/deep-filter")):
        if c and os.path.exists(c) and os.access(c, os.X_OK):
            return c
    return None


# --------------------------------------------------------------------------
# Etapes

def vers_wav(src: str, dst: str, freq: int = 48000):
    """Decodage en WAV mono. Downmix propre si la source est stereo."""
    r = run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
             "-i", src, "-ac", "1", "-ar", str(freq),
             "-c:a", "pcm_s16le", "-y", dst])
    if r.returncode != 0:
        raise RuntimeError(f"decodage: {r.stderr.strip()[:200]}")


def denoiser(binaire: str, src: str, dossier_sortie: str) -> str:
    """DeepFilterNet. Ecrit <dossier_sortie>/<nom du src>."""
    r = run([binaire, "-o", dossier_sortie, src])
    produit = os.path.join(dossier_sortie, os.path.basename(src))
    if r.returncode != 0 or not os.path.exists(produit):
        raise RuntimeError(f"deep-filter: {r.stderr.strip()[:200]}")
    return produit


def mesurer_loudness(src: str, cible: float | None = None,
                     tp: float | None = None) -> dict:
    """Passe 1 de loudnorm : mesure du fichier.

    `cible` et `tp` doivent valoir exactement ceux de la passe 2 : loudnorm
    renvoie un `target_offset` calcule pour eux, et l'utiliser avec d'autres
    valeurs fausserait la correction.
    """
    cible = LUFS_CIBLE if cible is None else cible
    tp = TRUE_PEAK if tp is None else tp
    r = run(["ffmpeg", "-hide_banner", "-nostdin", "-i", src,
             "-af", f"loudnorm=I={cible}:TP={tp}:LRA={LRA_CIBLE}:"
                    "print_format=json",
             "-f", "null", "-"])
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", r.stderr, re.S)
    if not m:
        raise RuntimeError("loudnorm : mesure illisible")
    return json.loads(m.group())


def trim_et_comprimer(src: str, dst: str, pauses_courtes: bool = False,
                      seuil_pause: float = 0.35):
    """Coupe les silences de bord, resserre la dynamique.

    Doit s'executer AVANT la mesure de loudness : le double passage de
    loudnorm exige que la mesure porte sur exactement le signal qui entrera
    en passe 2. Mesurer avant le compresseur fausse la cible (constate :
    -18 LUFS au lieu de -16 sur les fichiers deja forts).

    `pauses_courtes` ramene a `seuil_pause` toute pause interne plus longue.
    Mesure sur 120 fichiers francais DEBRUITES, seuil 0,35 s : 21 % de duree
    en moins, mediane 22 % par fichier, aucun fichier sans gain. Un seuil plus
    haut conserve davantage le rythme et rend moins. Chercher ces pauses sur
    le signal brut ne donne rien — le souffle de fond tient le niveau au-dessus
    du seuil — d'ou la place de ce filtre apres DeepFilterNet.
    """
    # le passe-haut retire les rumbles de manipulation du telephone, que le
    # compresseur remonterait ensuite
    highpass = "highpass=f=80"
    # silenceremove applique deux fois autour de areverse : tete puis queue
    trim = ("silenceremove=start_periods=1:start_silence=0.15:"
            "start_threshold=-50dB:detection=peak")
    pauses = (f"silenceremove=stop_periods=-1:stop_duration={seuil_pause}:"
              "stop_threshold=-45dB:detection=peak")
    compression = ("acompressor=threshold=-18dB:ratio=3:attack=20:"
                   "release=250:makeup=2")
    etapes = [highpass, trim, "areverse", trim, "areverse"]
    if pauses_courtes:
        etapes.append(pauses)
    etapes.append(compression)
    r = run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
             "-i", src, "-af", ",".join(etapes), "-ac", "1", "-ar", "48000",
             "-c:a", "pcm_s16le", "-y", dst])
    if r.returncode != 0:
        raise RuntimeError(f"trim/compression: {r.stderr.strip()[:300]}")


def normaliser(src: str, dst: str, mesures: dict, freq: int,
               cible: float | None = None, tp: float | None = None):
    """loudnorm passe 2, sur le signal exactement mesure en passe 1."""
    cible = LUFS_CIBLE if cible is None else cible
    tp = TRUE_PEAK if tp is None else tp
    norm = (f"loudnorm=I={cible}:TP={tp}:LRA={LRA_CIBLE}"
            f":measured_I={mesures['input_i']}"
            f":measured_TP={mesures['input_tp']}"
            f":measured_LRA={mesures['input_lra']}"
            f":measured_thresh={mesures['input_thresh']}"
            f":offset={mesures['target_offset']}:linear=true:print_format=summary")
    r = run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
             "-i", src, "-af", norm, "-ac", "1", "-ar", str(freq),
             "-c:a", "pcm_s16le", "-y", dst])
    if r.returncode != 0:
        raise RuntimeError(f"normalisation: {r.stderr.strip()[:300]}")


def env_fdk() -> dict:
    """Environnement pointant vers la libfdk-aac complete (celle avec SBR)."""
    env = dict(os.environ)
    if os.path.isdir(LIB_FDK):
        ancien = env.get("LD_LIBRARY_PATH", "")
        env["LD_LIBRARY_PATH"] = f"{LIB_FDK}:{ancien}" if ancien else LIB_FDK
    return env


def encoder(src_wav: str, dst: str, profil: str):
    """Encodage via fdkaac. Le WAV d'entree est deja a la bonne frequence."""
    p = PROFILS[profil]
    r = run(["fdkaac", "-p", str(p["aot"]), "-b", str(p["debit"]),
             "-o", dst, src_wav], env=env_fdk())
    if r.returncode == 0 and os.path.exists(dst):
        return
    if p["aot"] != 2:
        # surtout ne pas se rabattre sur l'AAC-LC natif : on livrerait du LC
        # en croyant avoir du HE-AAC, et personne ne s'en apercevrait avant
        # d'avoir encode les 6000 fichiers.
        raise RuntimeError(
            f"HE-AAC indisponible ({r.stderr.strip()[:120]}). "
            f"Verifier {LIB_FDK}/libfdk-aac.so.2, ou choisir --profil lc32.")
    # en AAC-LC seulement, l'encodeur natif de ffmpeg est un repli acceptable
    r = run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
             "-i", src_wav, "-c:a", "aac", "-b:a", str(p["debit"]),
             "-ac", "1", "-ar", str(p["freq"]), "-y", dst])
    if r.returncode != 0 or not os.path.exists(dst):
        raise RuntimeError(f"encodage: {r.stderr.strip()[:200]}")


def duree_de(chemin: str) -> float:
    """Duree en secondes, 0 si illisible. Un fichier vide ou tronque sort a 0
    et se repere ainsi dans le journal, sans avoir a l'ecouter."""
    r = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "csv=p=0", chemin])
    try:
        return round(float(r.stdout.strip()), 2)
    except ValueError:
        return 0.0


def traiter_un(src: str, dst: str, profil: str, df: str | None,
               tmpd: str, pauses_courtes: bool = False,
               seuil_pause: float = 0.35) -> dict:
    """Chaine complete sur un fichier. Retourne les mesures avant/apres."""
    p = PROFILS[profil]
    base = os.path.join(tmpd, "t")
    wav0, wav_pre, wav1 = base + "_0.wav", base + "_pre.wav", base + "_1.wav"

    vers_wav(src, wav0, 48000)
    avant = mesurer_loudness(wav0)          # etat initial, pour le rapport

    courant = wav0
    if df:
        dnd = os.path.join(tmpd, "df")
        os.makedirs(dnd, exist_ok=True)
        courant = denoiser(df, courant, dnd)

    trim_et_comprimer(courant, wav_pre, pauses_courtes, seuil_pause)
    # on vise plus bas de ce que le codec ajoutera, en volume comme en crete,
    # pour arriver aux cibles une fois le fichier decode par le telephone
    cible = LUFS_CIBLE - p["derive"]
    tp = TRUE_PEAK - p["derive_tp"]
    mesures = mesurer_loudness(wav_pre, cible, tp)   # signal reel de passe 2
    normaliser(wav_pre, wav1, mesures, p["freq"], cible, tp)
    encoder(wav1, dst, profil)

    apres = mesurer_loudness(dst)
    return {
        "avant_lufs": float(avant["input_i"]),
        "avant_tp": float(avant["input_tp"]),
        "avant_duree": duree_de(src),
        "apres_lufs": float(apres["input_i"]),
        "apres_tp": float(apres["input_tp"]),
        "apres_duree": duree_de(dst),
        "octets": os.path.getsize(dst),
    }


# --------------------------------------------------------------------------
# Appariement nom de fichier -> numero de question

def _numero_adja(base: str) -> int | None:
    """Adja porte une serie « B ». Regle donnee par Martin : « B » suivi de
    DEUX chiffres, le B vaut 2 (B85 = 285) ; suivi de TROIS chiffres, le B
    disparait (B300 = 300).

    Verifie sur les 930 fichiers : 929 numeros distincts, une seule collision
    (273.m4a contre B73.aac) et un seul absent (381). Ces deux-la sont un
    arbitrage humain, pas une regle a deviner.
    """
    m = re.fullmatch(r"[Bb](\d{2})", base)
    if m:
        return int("2" + m.group(1))
    m = re.fullmatch(r"[Bb](\d{3})", base)
    if m:
        return int(m.group(1))
    return None


def _numero_goun(base: str) -> int | None:
    """Goun est nomme « Voix N » ou « Voice N », ou N EST le numero de la
    question — contrairement a ce qu'un compteur d'appareil laisserait croire.

    Le suffixe « -1 » de « Voix 001-1 » vient de l'appareil, qui l'ajoute
    quand le nom existe deja ; il ne dit rien de la question. Verifie : les 62
    fichiers ainsi suffixes comblent exactement 62 des 64 numeros absents,
    sans provoquer une seule collision. Il ne reste que 356 et 358 a trouver.
    """
    m = re.fullmatch(r"[Vv]oix?e?\s*0*(\d{1,3})(?:-\d+)?", base.strip())
    return int(m.group(1)) if m else None


# Une langue absente de cette table suit la regle generale de numero_de().
REGLES_LANGUE = {"Adja": _numero_adja, "Goun": _numero_goun}


def numero_de(nom_fichier: str, langue: str = "") -> int | None:
    """Le numero de question porte par un nom, ou None s'il est ambigu.

    Le renommage etant manuel, les formes varient : « 12 », « Q12 »,
    « Abomey-Calavi 45 ». Tant qu'un seul nombre figure dans le nom, il n'y a
    pas d'ambiguite et on le prend. Certaines langues ont leur convention
    propre, etablie avec les relecteurs : voir REGLES_LANGUE.

    On refuse tout nom portant plusieurs nombres sans regle connue
    (« 20260718_102409 ») : choisir reviendrait a fabriquer un numero, et un
    audio range sous le mauvais numero est pire qu'un audio absent —
    l'application lirait sereinement la mauvaise question.
    """
    base = os.path.splitext(os.path.basename(nom_fichier))[0]
    # « 833 (2) », « 647 (3) » : suffixe ajoute par le systeme de fichiers a
    # une copie. Il compte les exemplaires, pas les questions, et le fichier
    # reste une prise de la meme question — c'est choisir_meilleur() qui
    # departagera. « BIS » se traite tout seul : il ne porte aucun chiffre.
    base = re.sub(r"\s*\(\d+\)\s*$", "", base).strip()

    regle = REGLES_LANGUE.get(langue)
    if regle:
        n = regle(base)
        if n is not None:
            return n if 1 <= n <= MAX_QUESTION else None
        # pas de forme particuliere : le nom est peut-etre deja un simple
        # numero, on laisse la regle generale tenter sa chance

    grappes = re.findall(r"\d+", base)
    if len(grappes) == 1:
        n = int(grappes[0])
        return n if 1 <= n <= MAX_QUESTION else None

    # « 2O3 » : la lettre O frappee a la place du zero. On ne tente cette
    # lecture qu'en dernier recours — si le nom donnait deja un numero, on
    # ne va pas le reinterpreter — et seulement si le resultat est un nombre
    # entier propre, sans quoi on prefere ecarter le fichier.
    if re.fullmatch(r"[\dOo]+", base) and re.search(r"[Oo]", base):
        n = int(base.replace("O", "0").replace("o", "0"))
        return n if 1 <= n <= MAX_QUESTION else None
    return None


def qualite_audio(chemin: str) -> dict | None:
    """Mesures brutes servant a departager deux prises de la meme question.

    « Meilleur » veut dire ici : techniquement le plus propre. Une erreur de
    lecture, un mot avale, une phrase mal dite ne se mesurent pas — seule
    l'oreille les attrape. On se contente donc d'ecarter ce qui est
    manifestement abime.
    """
    r = run(["ffmpeg", "-hide_banner", "-nostdin", "-i", chemin,
             "-af", "astats=metadata=1", "-f", "null", "-"])
    valeurs = {}
    for clef, motif in (("pic", r"Peak level dB: (-?(?:[\d.]+|inf))"),
                        ("rms", r"RMS level dB: (-?(?:[\d.]+|inf))"),
                        ("bruit", r"Noise floor dB: (-?(?:[\d.]+|inf))"),
                        ("plat", r"Flat factor: ([\d.]+)")):
        m = re.search(motif, r.stderr)
        if not m:
            return None
        valeurs[clef] = float(m.group(1))
    # Un plancher de bruit a -inf n'est pas une anomalie : c'est un silence
    # numeriquement parfait, donc plutot bon signe. On le ramene a la limite
    # du 16 bits pour que le rapport signal/bruit reste un nombre.
    if valeurs["bruit"] == float("-inf"):
        valeurs["bruit"] = -96.0
    if valeurs["rms"] == float("-inf") or valeurs["pic"] == float("-inf"):
        return None                      # la, le fichier est vraiment muet
    valeurs["duree"] = duree_de(chemin)
    if valeurs["duree"] <= 0:
        return None

    # astats a decode tout le flux : ses erreurs de decodage sont dans la
    # meme sortie. On les COMPTE au lieu de les transformer en verdict : tous
    # les mp3 de Ditamari en produisent deux, en-tete bancal a l'origine, y
    # compris les fichiers parfaitement sains. Un seuil absolu les
    # condamnerait tous ; c'est la comparaison a l'interieur d'un groupe qui
    # est parlante.
    valeurs["erreurs"] = len(re.findall(
        r"Header missing|Invalid data|Error submitting packet|"
        r"corrupt|truncated", r.stderr, re.I))

    # rapport signal/bruit : l'ecart entre la parole et le fond
    valeurs["snr"] = valeurs["rms"] - valeurs["bruit"]
    return valeurs


def choisir_meilleur(chemins: list) -> tuple:
    """Parmi plusieurs prises d'une meme question, retenir la plus propre.

    Retourne (gagnant, [(perdant, motif), …]). L'ordre des criteres compte :
    on elimine d'abord ce qui est abime, on classe ensuite sur le bruit.
    """
    mesures = {c: qualite_audio(c) for c in chemins}
    lisibles = {c: m for c, m in mesures.items() if m}
    if not lisibles:
        return chemins[0], [(c, "illisible") for c in chemins[1:]]

    plus_longue = max(m["duree"] for m in lisibles.values())
    erreurs_min = min(m["erreurs"] for m in lisibles.values())

    def defauts(m: dict) -> tuple:
        """Les defauts d'une prise, du plus grave au plus benin.

        Un classement, et non des exclusions : meme lorsque toutes les prises
        sont imparfaites il reste un ordre. Ecarter d'abord puis departager
        les survivants faisait perdre le critere de duree des que tout le
        monde etait ecarte — c'est ainsi qu'un fichier de 20 s avait ete
        prefere a son jumeau de 70 s.
        """
        return (
            # amputee : le defaut le plus grave, il manque du contenu
            1 if m["duree"] < 0.6 * plus_longue else 0,
            # plus d'erreurs de decodage que ses concurrentes
            1 if m["erreurs"] > erreurs_min else 0,
            # ecretee des l'enregistrement
            1 if (m["pic"] > -0.1 or m["plat"] > 1.0) else 0,
            # a defaut de defaut, la plus propre
            -m["snr"],
        )

    def pourquoi(m: dict, g: dict) -> str:
        if m["duree"] < 0.6 * plus_longue:
            return f"tronqué ({m['duree']:.0f} s contre {plus_longue:.0f} s)"
        if m["erreurs"] > erreurs_min:
            return (f"flux abîmé ({m['erreurs']} erreurs de décodage "
                    f"contre {erreurs_min})")
        if m["pic"] > -0.1 or m["plat"] > 1.0:
            return f"saturé (crête {m['pic']:.1f} dB)"
        return (f"bruit de fond plus élevé (rapport {m['snr']:.0f} dB "
                f"contre {g['snr']:.0f})")

    gagnant = min(lisibles, key=lambda c: defauts(lisibles[c]))
    g = lisibles[gagnant]
    perdants = []
    for c in chemins:
        if c == gagnant:
            continue
        raison = pourquoi(lisibles[c], g) if c in lisibles else "illisible"
        perdants.append((c, f"{raison} — retenu : {os.path.basename(gagnant)}"))
    return gagnant, perdants


def preparer_lot(src_dir: str, dst_dir: str, langue: str = "") -> tuple[list, list]:
    """Apparie les sources a leurs noms de sortie. N'encode rien.

    Retourne (a_faire, ecartes). `a_faire` est une liste de couples
    (chemin source, chemin destination) ; `ecartes` liste les fichiers
    qu'aucune regle sure ne sait classer, avec le motif.
    """
    fichiers = sorted(f for f in os.listdir(src_dir)
                      if os.path.splitext(f)[1].lower() in EXT_AUDIO
                      and not f.startswith("._"))
    candidats: dict[int, list] = {}
    ecartes = []
    for f in fichiers:
        n = numero_de(f, langue)
        if n is None:
            ecartes.append((f, "nom ambigu ou hors 1-%d" % MAX_QUESTION))
        else:
            candidats.setdefault(n, []).append(f)

    # Plusieurs prises d'une meme question — « 16.m4a » et « 16 BIS.m4a », ou
    # le meme numero en .mp3 et en .aac. On mesure et on garde la plus propre
    # plutot que de laisser l'ordre alphabetique decider, ce qu'il faisait
    # jusqu'ici sans que rien ne le signale.
    par_numero: dict[int, str] = {}
    for n, lot in candidats.items():
        if len(lot) == 1:
            par_numero[n] = lot[0]
            continue
        gagnant, perdants = choisir_meilleur(
            [os.path.join(src_dir, f) for f in lot])
        par_numero[n] = os.path.basename(gagnant)
        ecartes.extend((os.path.basename(c), motif) for c, motif in perdants)

    a_faire = [(os.path.join(src_dir, f),
                os.path.join(dst_dir, f"{PREFIXE_SORTIE}{n}.m4a"))
               for n, f in sorted(par_numero.items())]
    return a_faire, ecartes


def _traiter_tache(tache: tuple) -> dict:
    """Un fichier, dans son propre repertoire temporaire (isolation entre
    processus). Toujours retourner, jamais lever : le pool doit continuer."""
    src, dst, profil, df, pauses_courtes, seuil_pause = tache
    debut = time.time()
    try:
        with tempfile.TemporaryDirectory(prefix="traiter_") as tmpd:
            m = traiter_un(src, dst, profil, df, tmpd, pauses_courtes,
                           seuil_pause)
        m.update(fichier=os.path.basename(src), erreur=None)
    except Exception as exc:                                    # noqa: BLE001
        # un fichier de sortie a moitie ecrit ferait croire a une reussite
        # lors de la reprise : on l'efface.
        if os.path.exists(dst):
            try:
                os.remove(dst)
            except OSError:
                pass
        m = {"fichier": os.path.basename(src), "erreur": str(exc)[:200]}
    m["sortie"] = os.path.basename(dst)
    m["secondes"] = round(time.time() - debut, 1)
    return m


# --------------------------------------------------------------------------

def choisir_temoins(racine: str) -> list:
    """Selectionne les fichiers les plus extremes a partir de l'audit de niveaux."""
    import csv
    chemin = os.path.join(racine, "Traitement", "00_inventaire", "audit_silence.csv")
    if not os.path.exists(chemin):
        sys.exit(f"audit de niveaux introuvable : {chemin}\n"
                 "Lancer d'abord : python3 detect_silence.py")
    lignes = [r for r in csv.DictReader(open(chemin, encoding="utf-8"))
              if r["mean_dB"]]
    choix = []
    for langue, _, motif in TEMOINS:
        lot = [r for r in lignes if r["langue"] == langue]
        if not lot:
            continue
        # le plus fort pour Goun, le plus faible sinon
        cle = (max if langue == "Goun" else min)
        r = cle(lot, key=lambda x: float(x["mean_dB"]))
        choix.append((langue, r["fichier"], motif, float(r["mean_dB"])))
    return choix


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--demo", action="store_true",
                    help="compare avant/apres sur quelques fichiers types")
    ap.add_argument("--langue", help="traiter une langue entiere")
    ap.add_argument("--profil", choices=list(PROFILS), default=PROFIL_DEFAUT,
                    help="en --demo, les trois profils sont produits")
    ap.add_argument("--racine", default=RACINE_DEFAUT)
    ap.add_argument("--source",
                    help="dossier des audios renommés, si ce n'est pas "
                         "Originaux/<langue> (celui-ci n'est jamais modifié)")
    ap.add_argument("--procs", type=int, default=max(1, os.cpu_count() - 2),
                    help="fichiers traités en parallèle (défaut : cœurs - 2)")
    ap.add_argument("--limite", type=int, default=0,
                    help="s'arrêter après N fichiers, pour un essai")
    ap.add_argument("--verifier", action="store_true",
                    help="montrer l'appariement nom -> q-N sans rien encoder")
    ap.add_argument("--pauses-courtes", action="store_true",
                    help="raccourcir les pauses internes trop longues "
                         "(-21 %% de durée et de poids au seuil de 0,35 s)")
    ap.add_argument("--seuil-pause", type=float, default=0.35,
                    metavar="SECONDES",
                    help="durée à laquelle les pauses sont ramenées "
                         "(défaut 0,35 ; plus haut = rythme plus préservé)")
    ap.add_argument("--sans-denoise", action="store_true",
                    help="sauter DeepFilterNet (pour tester le reste)")
    args = ap.parse_args()

    # Sans --langue, on traite tout ce qu'on trouve a cote. C'est le mode
    # « je depose mes dossiers et je lance » : rien a taper, rien a retenir.
    langues = ([args.langue] if args.langue
               else [] if args.demo else langues_presentes(args.racine))
    if not args.demo and not langues:
        ap.error(f"aucun dossier de langue trouvé sous {args.racine} — "
                 "déposer un dossier par langue à côté du script, "
                 "ou préciser --langue et --source")

    if args.verifier:
        code = 0
        for i, langue in enumerate(langues):
            if i:
                print()
            code |= verifier(args.racine, langue, args.source)
        return code

    df = None if args.sans_denoise else deep_filter_dispo()
    if not df and not args.sans_denoise:
        print("!! deep-filter introuvable : traitement SANS débruitage.\n"
              "   Pour l'installer :\n"
              "   mkdir -p ~/.local/bin && curl -sL https://github.com/Rikorose/"
              "DeepFilterNet/releases/latest/download/"
              "deep-filter-x86_64-unknown-linux-musl -o ~/.local/bin/deep-filter"
              " && chmod +x ~/.local/bin/deep-filter\n")

    p = PROFILS[args.profil]
    print(f"profil : {p['libelle']} | débruitage : "
          f"{'oui' if df else 'NON'} | pauses courtes : "
          f"{f'{args.seuil_pause} s' if args.pauses_courtes else 'non'} | "
          f"cible {LUFS_CIBLE} LUFS / {TRUE_PEAK} dBTP")
    if len(langues) > 1:
        print(f"langues trouvées : {', '.join(langues)}")
    print()

    if args.demo:
        return demo(args.racine, args.profil, df)

    code = 0
    for langue in langues:
        if len(langues) > 1:
            print(f"=============== {langue} ===============")
        code |= traiter_langue(args.racine, langue, args.profil, df,
                               args.procs, args.source, args.limite,
                               args.pauses_courtes, args.seuil_pause)
    return code


def demo(racine: str, profil: str, df: str | None) -> int:
    """Produit avant/apres cote a cote pour ecoute humaine."""
    sortie = os.path.join(racine, "Traitement", "demo_ecoute")
    os.makedirs(sortie, exist_ok=True)
    temoins = choisir_temoins(racine)

    print(f"{len(temoins)} fichiers témoins -> {sortie}\n")
    with tempfile.TemporaryDirectory(prefix="traiter_") as tmpd:
        for langue, fichier, motif, niveau in temoins:
            src = os.path.join(racine, "Originaux", langue, fichier)
            racine_nom = f"{langue}_{os.path.splitext(fichier)[0]}"[:60]
            # copie de l'original pour comparaison directe
            avant_copie = os.path.join(sortie, f"{racine_nom}_AVANT{os.path.splitext(fichier)[1]}")
            shutil.copy2(src, avant_copie)
            dst = os.path.join(sortie, f"{racine_nom}_APRES_{profil}.m4a")

            print(f"  {langue:9s} {fichier[:38]:38s} ({motif})")
            # les trois profils, pour que Martin les departage a l'oreille
            for prof in PROFILS:
                dst = os.path.join(sortie, f"{racine_nom}_APRES_{prof}.m4a")
                try:
                    m = traiter_un(src, dst, prof, df, tmpd)
                except Exception as exc:                    # noqa: BLE001
                    print(f"     {prof}: ECHEC — {exc}")
                    continue
                print(f"     {prof:5s} volume {m['avant_lufs']:6.1f} -> "
                      f"{m['apres_lufs']:5.1f} LUFS | crête {m['avant_tp']:5.1f} -> "
                      f"{m['apres_tp']:5.1f} dBTP | {os.path.getsize(src)/1024:5.0f} "
                      f"-> {m['octets']/1024:4.0f} Ko")
            print()

    print(f"À écouter dans : {sortie}")
    print("Comparer chaque _AVANT avec son _APRES.")
    return 0


def dossier_source(racine: str, langue: str, source: str | None) -> str | None:
    """Ou sont les audios de cette langue ?

    On regarde, dans l'ordre : ce qui est demande explicitement, la structure
    du projet, puis un simple sous-dossier a cote. Le dernier cas est celui de
    la seconde machine : « Dendi/ » pose a cote de traiter.py suffit.
    """
    for candidat in (source,
                     os.path.join(racine, "Originaux", langue),
                     os.path.join(racine, langue)):
        if candidat and os.path.isdir(candidat):
            return candidat
    return None


def langues_presentes(racine: str) -> list:
    """Les sous-dossiers qui contiennent vraiment des audios.

    Un dossier qui n'en range que dans ses propres sous-dossiers (« sans_noms »
    et ses langues en attente) n'est pas une langue : l'inclure ferait croire
    a un corpus vide.
    """
    bases = [os.path.join(racine, "Originaux"), racine]
    trouvees = {}
    for base in bases:
        if not os.path.isdir(base):
            continue
        for nom in sorted(os.listdir(base)):
            d = os.path.join(base, nom)
            if not os.path.isdir(d) or nom in ("Traitement", "bin", "lib",
                                               "Originaux") or nom in trouvees:
                continue
            if any(os.path.splitext(f)[1].lower() in EXT_AUDIO
                   for f in os.listdir(d)):
                trouvees[nom] = d
    return sorted(trouvees)


def verifier(racine: str, langue: str, source: str | None) -> int:
    """Montre ce que le traitement produirait, sans encoder une seule seconde.

    A lancer avant toute passe sur un corpus qu'on n'a pas encore vu : une
    convention de nommage imprevue se rattrape en une minute ici, contre trois
    heures de calcul jetees autrement.
    """
    src_dir = dossier_source(racine, langue, source)
    if not src_dir:
        sys.exit(f"aucun dossier trouvé pour « {langue} » sous {racine}")
    a_faire, ecartes = preparer_lot(src_dir, "", langue)
    produits = {os.path.basename(d) for _, d in a_faire}
    manquants = [n for n in range(1, MAX_QUESTION + 1)
                 if f"{PREFIXE_SORTIE}{n}.m4a" not in produits]

    # « retenu : X » signe un doublon tranche par la mesure : ce n'est pas un
    # probleme mais une decision. Le melanger aux noms incompris ferait crier
    # au loup sur un corpus parfaitement sain.
    doublons = [(f, m) for f, m in ecartes if "retenu :" in m]
    incompris = [(f, m) for f, m in ecartes if "retenu :" not in m]

    print(f"source : {src_dir}")
    print(f"  {len(a_faire)} audios seraient produits")
    print(f"  {len(doublons)} prises écartées au profit d'une meilleure")
    print(f"  {len(incompris)} fichiers dont le nom n'est pas compris")
    print(f"  {len(manquants)} numéros absents sur {MAX_QUESTION}")

    if a_faire:
        print("\n  exemples d'appariement :")
        # le debut et la fin de la liste, sans repetition sur les petits lots
        montres = a_faire[:4] + a_faire[-2:] if len(a_faire) > 6 else a_faire
        for s, d in montres:
            print(f"    {os.path.basename(s):38s} -> {os.path.basename(d)}")
    if doublons:
        print(f"\n  doublons tranchés (les {min(6, len(doublons))} premiers) :")
        for f, motif in doublons[:6]:
            print(f"    {f:30s} {motif}")
    if incompris:
        print(f"\n  noms non compris (les {min(6, len(incompris))} premiers) :")
        for f, motif in incompris[:6]:
            print(f"    {f:38s} {motif}")
    if manquants:
        apercu = manquants[:20]
        suite = " …" if len(manquants) > 20 else ""
        print(f"\n  numéros absents : {apercu}{suite}")

    if incompris:
        print(f"\n  ⚠ {len(incompris)} noms ne sont pas compris. S'ils suivent "
              "une convention, la faire ajouter avant de lancer la passe.")
    else:
        print("\n  appariement sain — la passe peut être lancée.")
    return 0


def traiter_langue(racine: str, langue: str, profil: str, df: str | None,
                   procs: int = 1, source: str | None = None,
                   limite: int = 0, pauses_courtes: bool = False,
                   seuil_pause: float = 0.35) -> int:
    """Traite une langue entiere vers q-1.m4a … q-930.m4a.

    La source n'est jamais modifiee. Deux journaux sont ecrits a cote des
    sorties : la correspondance nom d'origine -> q-N (le renommage reste donc
    reversible) et la liste des fichiers ecartes (a rendre aux relecteurs).
    """
    src_dir = dossier_source(racine, langue, source)
    if not src_dir:
        sys.exit(f"aucun dossier trouvé pour « {langue} » sous {racine}")
    dst_dir = os.path.join(racine, "Traitement", "05_final", langue)
    os.makedirs(dst_dir, exist_ok=True)

    a_faire, ecartes = preparer_lot(src_dir, dst_dir, langue)
    total_apparies = len(a_faire)
    # un numero est absent s'il n'est ni deja produit ni au programme
    attendus = {os.path.basename(d) for _, d in a_faire}
    manquants = [n for n in range(1, MAX_QUESTION + 1)
                 if f"{PREFIXE_SORTIE}{n}.m4a" not in attendus
                 and not os.path.exists(
                     os.path.join(dst_dir, f"{PREFIXE_SORTIE}{n}.m4a"))]

    if ecartes:
        chemin = os.path.join(dst_dir, "_ecartes.csv")
        with open(chemin, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["fichier", "motif"])
            w.writerows(ecartes)
        print(f"  {len(ecartes)} fichiers écartés -> {chemin}")

    a_faire = [t for t in a_faire if not os.path.exists(t[1])]  # reprise
    passes = total_apparies - len(a_faire)
    if limite:
        a_faire = a_faire[:limite]

    print(f"{langue} : {total_apparies} appariés, {passes} déjà faits, "
          f"{len(a_faire)} à traiter, {len(manquants)} numéros absents "
          f"sur {MAX_QUESTION}")
    if not a_faire:
        return 0

    taches = [(s, d, profil, df, pauses_courtes, seuil_pause)
              for s, d in a_faire]
    t0 = time.time()
    resultats = []
    faits = erreurs = 0
    with multiprocessing.Pool(procs) as pool:
        for r in pool.imap_unordered(_traiter_tache, taches):
            resultats.append(r)
            if r.get("erreur"):
                erreurs += 1
                print(f"  ECHEC {r['fichier']} : {r['erreur']}", flush=True)
            else:
                faits += 1
            n = len(resultats)
            if n % 25 == 0 or n == len(taches):
                ecoule = time.time() - t0
                reste = (len(taches) - n) * ecoule / n
                print(f"  {n}/{len(taches)} — {faits} ok, {erreurs} échecs, "
                      f"~{reste/60:.0f} min restantes", flush=True)

    _journal_correspondance(dst_dir, a_faire, resultats)
    _resume(langue, dst_dir, resultats, time.time() - t0)
    return 1 if erreurs else 0


def _journal_correspondance(dst_dir: str, a_faire: list, resultats: list):
    """Nom d'origine -> q-N, avec les mesures. C'est la piece qui rend le
    renommage reversible : sans elle, on ne saurait plus d'ou vient q-417."""
    par_sortie = {os.path.basename(d): os.path.basename(s) for s, d in a_faire}
    chemin = os.path.join(dst_dir, "_correspondance.csv")
    existe = os.path.exists(chemin)
    with open(chemin, "a", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        if not existe:
            w.writerow(["origine", "sortie", "duree_avant", "duree_apres",
                        "lufs_avant", "lufs_apres", "crete_apres_dbtp",
                        "octets", "secondes", "erreur"])
        for r in sorted(resultats, key=lambda x: x["sortie"]):
            w.writerow([par_sortie.get(r["sortie"], r["fichier"]), r["sortie"],
                        r.get("avant_duree", ""), r.get("apres_duree", ""),
                        r.get("avant_lufs", ""), r.get("apres_lufs", ""),
                        r.get("apres_tp", ""), r.get("octets", ""),
                        r["secondes"], r.get("erreur") or ""])


def _resume(langue: str, dst_dir: str, resultats: list, ecoule: float):
    ok = [r for r in resultats if not r.get("erreur")]
    print(f"\n{langue} : {len(ok)} traités, {len(resultats)-len(ok)} échecs "
          f"en {ecoule/60:.0f} min")
    if not ok:
        return
    octets = sum(r["octets"] for r in ok)
    lufs = sorted(r["apres_lufs"] for r in ok)
    cretes = [r["apres_tp"] for r in ok]
    print(f"  poids   : {octets/1024/1024:.1f} Mo pour {len(ok)} fichiers "
          f"({octets/len(ok)/1024:.0f} Ko en moyenne)")
    print(f"  volume  : médiane {lufs[len(lufs)//2]:.1f} LUFS, "
          f"étendue {lufs[0]:.1f} … {lufs[-1]:.1f}")
    print(f"  crête   : maximum {max(cretes):.1f} dBTP (plafond {TRUE_PEAK})")
    duree_avant = sum(r.get("avant_duree", 0) for r in ok)
    duree_apres = sum(r.get("apres_duree", 0) for r in ok)
    if duree_avant:
        print(f"  durée   : {duree_avant/60:.0f} min -> {duree_apres/60:.0f} min "
              f"({100*(1-duree_apres/duree_avant):.0f} % de silence retiré)")

    # controle d'integrite : un fichier vide ou tronque se voit a sa duree,
    # pas a son codec. C'est le seul defaut que la machine sait attraper seule.
    vides = [r for r in ok if r.get("apres_duree", 0) < 1.0]
    if vides:
        print(f"  !! {len(vides)} fichiers VIDES ou quasi vides — "
              + ", ".join(r["sortie"] for r in vides[:8]))
    ecourtes = [r for r in ok
                if r.get("avant_duree") and r.get("apres_duree", 0)
                < 0.5 * r["avant_duree"]]
    if ecourtes:
        print(f"  !! {len(ecourtes)} fichiers ont perdu plus de la moitié de "
              f"leur durée — " + ", ".join(r["sortie"] for r in ecourtes[:8]))
    hors = [r for r in ok if abs(r["apres_lufs"] - LUFS_CIBLE) > 1.0]
    if hors:
        print(f"  !! {len(hors)} fichiers à plus de 1 LU de la cible — "
              f"à vérifier : "
              + ", ".join(r["sortie"] for r in hors[:6]))
    print(f"-> {dst_dir}")


if __name__ == "__main__":
    sys.exit(main())
