"""Detection des fichiers vides/silencieux (LECTURE SEULE) — brief §6.

ffmpeg -af volumedetect sur chaque fichier : un max_volume proche de -91 dB
signale un fichier de zeros. Complete audit_integrite.py qui ne testait que
codec + duree.
"""
import csv, os, re, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

RACINE = os.environ.get(
    "PERMIS_AUDIO_ROOT",
    "/home/martin-js/Martin_JS/Permis-BJ/Assets/Audios")
ROOT = os.path.join(RACINE, "Originaux")
SORTIE = os.path.join(RACINE, "Traitement", "00_inventaire")
os.makedirs(SORTIE, exist_ok=True)
OUT = os.path.join(SORTIE, "audit_silence.csv")
AUDIO = (".aac", ".m4a", ".mp3", ".opus", ".wav", ".ogg")

RE_MAX = re.compile(r"max_volume:\s*(-?\d+(?:\.\d+)?)\s*dB")
RE_MEAN = re.compile(r"mean_volume:\s*(-?\d+(?:\.\d+)?)\s*dB")

# En-tetes fixes du CSV (utilises meme si aucun fichier n a ete mesure, cas
# "items" vide, pour ne jamais deduire les colonnes de rows[0]).
FIELDNAMES = ["langue", "fichier", "max_dB", "mean_dB", "verdict"]


def collect():
    items = []
    for lang in sorted(os.listdir(ROOT)):
        p = os.path.join(ROOT, lang)
        if not os.path.isdir(p):
            continue
        for dirpath, _, filenames in os.walk(p):
            if "__MACOSX" in os.path.relpath(dirpath, p):
                continue
            for f in sorted(filenames):
                if f.startswith("._") or os.path.splitext(f)[1].lower() not in AUDIO:
                    continue
                items.append((lang, f, os.path.join(dirpath, f)))
    return items


def measure(item):
    lang, name, full = item
    row = {"langue": lang, "fichier": name, "max_dB": "", "mean_dB": "", "verdict": ""}
    try:
        r = subprocess.run(
            ["ffmpeg", "-hide_banner", "-nostdin", "-i", full,
             "-af", "volumedetect", "-f", "null", "-"],
            capture_output=True, text=True, timeout=180)
        err = r.stderr
    except Exception as e:
        row["verdict"] = f"erreur:{type(e).__name__}"
        return row

    mx, mn = RE_MAX.search(err), RE_MEAN.search(err)
    if not mx:
        row["verdict"] = "mesure_impossible"
        return row
    mxv = float(mx.group(1))
    row["max_dB"] = mxv
    if mn:
        row["mean_dB"] = float(mn.group(1))

    if mxv <= -90.0:
        row["verdict"] = "VIDE"
    elif mxv <= -40.0:
        row["verdict"] = "quasi_muet"
    elif mxv <= -20.0:
        row["verdict"] = "tres_faible"
    elif mxv >= -0.1:
        row["verdict"] = "sature"
    else:
        row["verdict"] = "ok"
    return row


def main():
    items = collect()
    print(f"{len(items)} fichiers a mesurer...", flush=True)
    if not items:
        # Aucun fichier trouve (RACINE vide ou mal configuree) : ecrire un
        # CSV avec ses seuls en-tetes plutot que planter sur rows[0].
        with open(OUT, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=FIELDNAMES)
            w.writeheader()
        print(f"Aucun fichier audio trouve sous {ROOT} -> {OUT} (en-tetes seuls)")
        return
    rows = []
    with ThreadPoolExecutor(max_workers=8) as ex:
        for i, row in enumerate(ex.map(measure, items), 1):
            rows.append(row)
            if i % 500 == 0:
                print(f"  {i}/{len(items)}", flush=True)
    with open(OUT, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDNAMES)
        w.writeheader()
        w.writerows(rows)
    from collections import Counter
    print(f"\nTermine -> {OUT}")
    for k, v in Counter(r["verdict"] for r in rows).most_common():
        print(f"   {v:5d}  {k}")
    for r in rows:
        if r["verdict"] in ("VIDE", "quasi_muet", "mesure_impossible") or \
           str(r["verdict"]).startswith("erreur"):
            print(f"   !! {r['langue']:9s} {r['fichier']:45s} max={r['max_dB']} -> {r['verdict']}")


if __name__ == "__main__":
    sys.exit(main())
