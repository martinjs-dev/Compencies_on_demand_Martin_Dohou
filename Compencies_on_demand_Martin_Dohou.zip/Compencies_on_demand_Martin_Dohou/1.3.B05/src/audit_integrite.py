"""Audit d'integrite (LECTURE SEULE) du corpus Originaux.

Pour chaque fichier audio : codec reel (ffprobe), duree, taille, canaux,
sample rate. Sortie CSV dans le scratchpad. N'ecrit RIEN dans Originaux.
"""
import csv, json, os, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

RACINE = os.environ.get(
    "PERMIS_AUDIO_ROOT",
    "/home/martin-js/Martin_JS/Permis-BJ/Assets/Audios")
ROOT = os.path.join(RACINE, "Originaux")
SORTIE = os.path.join(RACINE, "Traitement", "00_inventaire")
os.makedirs(SORTIE, exist_ok=True)
OUT = os.path.join(SORTIE, "audit_integrite.csv")
AUDIO = (".aac", ".m4a", ".mp3", ".opus", ".wav", ".ogg")


def collect():
    items = []
    for lang in sorted(os.listdir(ROOT)):
        p = os.path.join(ROOT, lang)
        if not os.path.isdir(p):
            continue
        for dirpath, _, filenames in os.walk(p):
            rel = os.path.relpath(dirpath, p)
            if "__MACOSX" in rel:
                continue
            for f in sorted(filenames):
                if f.startswith("._"):
                    continue
                full = os.path.join(dirpath, f)
                ext = os.path.splitext(f)[1].lower()
                items.append((lang, rel if rel != "." else "", f, full, ext))
    return items


def probe(item):
    lang, sub, name, full, ext = item
    row = {
        "langue": lang, "sous_dossier": sub, "fichier": name, "ext": ext,
        "taille_octets": "", "codec": "", "format": "", "duree_s": "",
        "canaux": "", "sample_rate": "", "bitrate": "", "anomalie": "",
    }
    try:
        row["taille_octets"] = os.path.getsize(full)
    except OSError as e:
        row["anomalie"] = f"stat_error:{e}"
        return row

    if ext not in AUDIO:
        row["anomalie"] = "non_audio"
        return row

    try:
        r = subprocess.run(
            ["ffprobe", "-v", "error", "-print_format", "json",
             "-show_format", "-show_streams", full],
            capture_output=True, text=True, timeout=60)
        if r.returncode != 0:
            row["anomalie"] = "ffprobe_fail"
            return row
        d = json.loads(r.stdout or "{}")
    except Exception as e:
        row["anomalie"] = f"probe_exc:{type(e).__name__}"
        return row

    fmt = d.get("format", {})
    row["format"] = fmt.get("format_name", "")
    row["bitrate"] = fmt.get("bit_rate", "")
    streams = [s for s in d.get("streams", []) if s.get("codec_type") == "audio"]
    if not streams:
        row["anomalie"] = "aucun_flux_audio"
        return row
    s = streams[0]
    row["codec"] = s.get("codec_name", "")
    row["canaux"] = s.get("channels", "")
    row["sample_rate"] = s.get("sample_rate", "")
    dur = fmt.get("duration") or s.get("duration") or ""
    try:
        dur = float(dur)
        row["duree_s"] = round(dur, 2)
    except (TypeError, ValueError):
        dur = None
        row["anomalie"] = "duree_illisible"

    # coherence extension <-> codec reel
    attendu = {".aac": {"aac"}, ".m4a": {"aac", "alac"}, ".mp3": {"mp3"},
               ".opus": {"opus"}, ".wav": {"pcm_s16le", "pcm_s24le", "pcm_f32le"},
               ".ogg": {"vorbis", "opus"}}
    exp = attendu.get(ext, set())
    if exp and row["codec"] and row["codec"] not in exp:
        row["anomalie"] = (row["anomalie"] + ";" if row["anomalie"] else "") + \
            f"codec_incoherent:{row['codec']}"
    if dur is not None:
        if dur <= 0.05:
            row["anomalie"] = (row["anomalie"] + ";" if row["anomalie"] else "") + "duree_nulle"
        elif dur < 2.0:
            row["anomalie"] = (row["anomalie"] + ";" if row["anomalie"] else "") + "duree_tres_courte"
        elif dur > 180:
            row["anomalie"] = (row["anomalie"] + ";" if row["anomalie"] else "") + "duree_aberrante"
    if len(streams) > 1:
        row["anomalie"] = (row["anomalie"] + ";" if row["anomalie"] else "") + "multi_flux"
    return row


def main():
    items = collect()
    print(f"{len(items)} fichiers a sonder...", flush=True)
    rows = []
    with ThreadPoolExecutor(max_workers=8) as ex:
        for i, row in enumerate(ex.map(probe, items), 1):
            rows.append(row)
            if i % 500 == 0:
                print(f"  {i}/{len(items)}", flush=True)
    with open(OUT, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    anos = [r for r in rows if r["anomalie"]]
    print(f"\nTermine. {len(rows)} lignes -> {OUT}")
    print(f"ANOMALIES: {len(anos)}")
    from collections import Counter
    for k, v in Counter(a["anomalie"] for a in anos).most_common():
        print(f"   {v:5d}  {k}")


if __name__ == "__main__":
    sys.exit(main())
