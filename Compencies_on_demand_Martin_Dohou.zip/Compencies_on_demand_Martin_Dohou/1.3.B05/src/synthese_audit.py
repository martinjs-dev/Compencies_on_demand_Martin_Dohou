import csv, os, statistics
from collections import Counter, defaultdict

HERE = "/home/martin-js/Martin_JS/Permis-BJ/Assets/Audios/Traitement/00_inventaire"
rows = list(csv.DictReader(open(os.path.join(HERE, "audit_integrite.csv"), encoding="utf-8")))

print(f"TOTAL lignes: {len(rows)}\n")

par_langue = defaultdict(list)
for r in rows:
    par_langue[r["langue"]].append(r)

tot_dur = tot_oct = 0
for lang in sorted(par_langue):
    rs = par_langue[lang]
    durs = [float(r["duree_s"]) for r in rs if r["duree_s"]]
    octs = [int(r["taille_octets"]) for r in rs if r["taille_octets"]]
    codecs = Counter(r["codec"] for r in rs if r["codec"])
    srs = Counter(r["sample_rate"] for r in rs if r["sample_rate"])
    chs = Counter(r["canaux"] for r in rs if r["canaux"])
    tot_dur += sum(durs)
    tot_oct += sum(octs)
    print(f"### {lang}  ({len(rs)} fichiers)")
    if durs:
        print(f"    duree : min {min(durs):.1f}s | med {statistics.median(durs):.1f}s | "
              f"moy {statistics.mean(durs):.1f}s | max {max(durs):.1f}s | total {sum(durs)/3600:.2f} h")
    print(f"    taille: {sum(octs)/1e6:.0f} Mo | med {statistics.median(octs)/1024:.0f} Ko")
    print(f"    codec : {dict(codecs)}")
    print(f"    freq  : {dict(srs)} | canaux: {dict(chs)}")
    # les 3 plus courts et 3 plus longs
    ok = [r for r in rs if r["duree_s"]]
    ok.sort(key=lambda r: float(r["duree_s"]))
    print("    + courts:", [(r["fichier"], r["duree_s"]) for r in ok[:3]])
    print("    + longs :", [(r["fichier"], r["duree_s"]) for r in ok[-3:]])
    print()

print(f"CORPUS: {tot_dur/3600:.1f} heures d'audio | {tot_oct/1e9:.2f} Go")
print(f"Estimation WAV 16bit/48k mono: {tot_dur*48000*2/1e9:.1f} Go par etage")
print(f"Estimation WAV 16bit/16k mono: {tot_dur*16000*2/1e9:.1f} Go par etage")

print("\n=== ANOMALIES ===")
for r in rows:
    if r["anomalie"]:
        print(f"  {r['langue']:9s} {r['fichier']:50s} {r['ext']:6s} "
              f"dur={r['duree_s']:>7} codec={r['codec']:8s} -> {r['anomalie']}")
