// ==============
// MockExamQrPayload - Modèle + codec du payload QR v3/v4/v5/v6 (examens blancs)
// ==============
//
// Miroir Dart de `MockExamQrExportDto` / `MockExamQrService` côté backend
// (`apps/api/src/modules/mock-exams/app/services/mock-exam-qr.service.ts`).
//
// v3 - format compact signé directement par le serveur (~350 octets) :
// `{ v, code, mode, dur, lang, n, q?, c?, exp, sig? }`. `mode 0` =
// SAME_FOR_ALL, `mode 1` = RANDOM_SHARED (les deux portent `q` = numéros
// exacts du tirage) ; `mode 2` = RANDOM_PER_CANDIDATE (porte `c` = critères
// de tirage local, jamais `q`).
//
// v4 - examen créé hors-ligne par le moniteur (ADR-013 Phase 2) : le QR est
// signé par la clé d'appareil du moniteur (`sig`), accompagnée d'un
// certificat serveur (`cert`) qui atteste que cette clé d'appareil est
// légitime. Mêmes champs `mode/dur/lang/n/q?/c?/exp` que v3, mais :
// - `code` est remplacé par `lid` (`clientLocalId`, UUID) - clé de jointure
//   offline, PAS un `sessionCode` `EB-XXXX` (l'examen n'existe pas encore
//   côté serveur au moment du scan).
// - `oc: 1` marque l'origine "offline-created".
// - `cert: { did, dpk, uid, sid?, nb, na, cv, certSignature }` - voir
//   [MockExamQrCertificate].
// - `sig` en v4 est la signature de l'APPAREIL (pas du serveur comme en v3).
//
// v5 - v3 enrichie d'une référence d'épreuve (`p`, ADR-051) : MÊMES champs
// que v3 (`code/mode/dur/lang/n/q?/c?/exp/sig?`), PLUS `p` optionnel -
// `{ sc, num, sid?, uid? }`, portée + numéro de l'épreuve source quand la
// session a été lancée depuis une épreuve enregistrée (ADR-050). `q` reste
// TOUJOURS présent et TOUJOURS la source de vérité de la composition jouée
// (ADR-051 SS9, « les numéros font foi ») - `p` n'est qu'un COMPLÉMENT de
// traçabilité/étiquetage, jamais un remplacement, jamais recomposé depuis.
// Un `p` absent, malformé ou de portée inconnue dégrade silencieusement en
// [MockExamQrPayload.paperRef] `null` - le payload v5 reste parfaitement
// jouable sur `q` seul, exactement comme un v3.
//
// v6 - la v5 dont les numéros sont RETENUS jusqu'au lancement : mêmes champs
// que v5 (`code/mode/dur/lang/n/exp/sig?`), mais `q` est ABSENT et `p`
// (référence d'épreuve) devient OBLIGATOIRE. La composition n'est plus lue sur
// le QR : elle est retrouvée LOCALEMENT depuis `p` et le stock d'épreuves
// (`mock_exam_qr_paper_ref_resolver.dart`). Un v6 sans `p` ne désigne aucune
// composition et est donc inexploitable : le parsing le refuse.
//
// ⚠️ En v6, [MockExamQrPayload.questionNumbers] vaut `null`, et ce n'est PAS
// une dégradation : c'est le contrat de la version. Tout appelant qui lit
// `questionNumbers` doit, quand il vaut `null` sur un v6, passer par la
// résolution depuis [MockExamQrPayload.paperRef] - jamais conclure que le
// payload est incomplet.
//
// Champs transverses (v3/v4/v5/v6, tous OPTIONNELS - un backend antérieur ne
// les émet pas et cela reste parfaitement légal) : `kid` (identifiant de clé
// de signature, pour résoudre la bonne clé publique après une rotation),
// `mid`/`sid` (moniteur et école organisateurs) et `org` (libellé
// d'affichage de l'organisateur).
//
// Chaîne de confiance v4 (vérifiée hors-ligne par `mock_exam_qr_verifier.dart`) :
// cert signé par la clé publique SERVEUR (déjà cachée en Isar) → `dpk`
// (clé publique d'appareil) authentifiée → payload signé par `dpk`.
//
// Ce fichier ne fait AUCUN accès réseau/Isar - uniquement du parsing et de la
// sérialisation JSON canonique pures, testables en isolation. La vérification
// de signature Ed25519 est dans `mock_exam_qr_verifier.dart` (dépendance
// `package:cryptography` + cache Isar de la clé publique). La résolution
// locale d'une référence d'épreuve (`p`) contre le stock Isar vit à part,
// dans `mock_exam_qr_paper_ref_resolver.dart` - ce fichier-ci reste sans
// dépendance Isar.

import 'dart:convert';

/// Mode de distribution des questions - index stable, voir
/// `DISTRIBUTION_MODE_INDEX` côté backend (jamais réordonné : un ajout futur
/// de valeur ne doit jamais décaler les index déjà en circulation sur des QR
/// déjà imprimés/affichés).
enum MockExamQrDistributionMode {
  sameForAll(0),
  randomShared(1),
  randomPerCandidate(2);

  const MockExamQrDistributionMode(this.wireIndex);

  /// Index numérique tel qu'encodé sur le fil (`mode` du payload QR) - à ne
  /// pas confondre avec `Enum.index` (ordre de déclaration Dart, non stable
  /// contractuellement).
  final int wireIndex;

  static MockExamQrDistributionMode? fromIndex(int? index) {
    for (final m in MockExamQrDistributionMode.values) {
      if (m.wireIndex == index) return m;
    }
    return null;
  }
}

/// Critères de tirage local (`c`) - présents uniquement en
/// `randomPerCandidate`. [categories] vide = toutes catégories éligibles.
/// `themeIds` vide = tous les thèmes éligibles.
///
/// SUS-367 bis : le contrat serveur porte désormais `cats` (la liste COMPLÈTE
/// des catégories du tirage) à côté de `cat` (déprécié, première valeur
/// seulement). Ne lire que `cat` faisait composer deux candidats de la même
/// salle sur des périmètres DIFFÉRENTS en `randomPerCandidate` selon que le
/// tirage se faisait en local ou côté serveur. La lecture de `cats` est
/// strictement ADDITIVE : elle n'entre dans AUCUNE des fonctions de
/// canonicalisation (`unsignedJson`), donc aucune signature Ed25519 ni aucun
/// vecteur golden n'est affecté.
class MockExamQrCriteria {
  const MockExamQrCriteria({
    String? category,
    List<String> categories = const <String>[],
    required this.themeIds,
    required this.count,
  }) : _category = category,
       _categories = categories;

  final String? _category;
  final List<String> _categories;
  final List<String> themeIds;
  final int count;

  /// Périmètre COMPLET du tirage - jamais nul, vide = aucun filtre catégorie.
  ///
  /// Se dérive de `cats` quand le QR le porte, et retombe sur la seule `cat`
  /// d'un QR émis par une version antérieure (encadrant pas encore mis à
  /// jour) : dans les deux cas la valeur est une LISTE, ce que
  /// `questionMatchesCriteria` attend déjà (règle d'INTERSECTION, une seule
  /// catégorie commune suffit).
  List<String> get categories {
    if (_categories.isNotEmpty) return _categories;
    final legacy = _category?.trim();
    if (legacy == null || legacy.isEmpty) return const <String>[];
    return <String>[legacy];
  }

  /// Première catégorie du périmètre - CONSERVÉE parce que d'autres lecteurs
  /// et les tests golden l'utilisent. Dépréciée au sens du contrat serveur :
  /// pour filtrer, c'est [categories] qu'il faut lire, jamais elle.
  String? get category => categories.isEmpty ? null : categories.first;

  factory MockExamQrCriteria.fromJson(Map<String, dynamic> json) {
    final th = json['th'];
    return MockExamQrCriteria(
      categories: _stringList(json['cats']),
      category: (json['cat'] as String?)?.trim().isNotEmpty == true
          ? json['cat'] as String
          : null,
      themeIds: th is List
          ? th.map((e) => e.toString()).toList()
          : const <String>[],
      count: _asInt(json['n']) ?? 0,
    );
  }
}

/// Liste de chaînes non vides, dans l'ordre reçu (aucun tri, aucune
/// déduplication : l'ordre du serveur est celui de l'écran de composition).
List<String> _stringList(dynamic value) {
  if (value is! List) return const <String>[];
  final out = <String>[];
  for (final e in value) {
    if (e == null) continue;
    final s = e.toString().trim();
    if (s.isNotEmpty) out.add(s);
  }
  return out;
}

/// Certificat d'appareil (`cert`, QR v4 uniquement) - atteste que la clé
/// publique d'appareil [devicePublicKeyBase64Url] appartient légitimement au
/// moniteur [userId] (et à l'école [schoolId] le cas échéant), pour la
/// fenêtre de validité [notBeforeEpochSeconds]..[notAfterEpochSeconds].
/// Émis et signé par le serveur ([certSignature]) lors d'une connexion en
/// ligne préalable du moniteur - vérifiable ensuite hors-ligne avec la clé
/// publique serveur déjà cachée en Isar (voir `MockExamQrVerifier`).
///
/// [raw] conserve la structure JSON décodée telle quelle (`certSignature`
/// incluse) - même rôle que [MockExamQrPayload.raw] : source de vérité pour
/// reconstruire la sérialisation canonique exactement signée par le serveur,
/// résiliente à un futur champ additionnel non modélisé ici.
class MockExamQrCertificate {
  const MockExamQrCertificate({
    required this.deviceId,
    required this.devicePublicKeyBase64Url,
    required this.userId,
    required this.schoolId,
    required this.notBeforeEpochSeconds,
    required this.notAfterEpochSeconds,
    required this.certVersion,
    required this.certSignature,
    required this.raw,
  });

  /// `did` - identifiant de l'appareil moniteur ayant généré la paire de
  /// clés locale.
  final String deviceId;

  /// `dpk` - clé publique Ed25519 **brute** (32 octets) de l'appareil,
  /// encodée en base64url SANS padding. Décoder avec
  /// `decodeBase64UrlPadded` (`mock_exam_qr_verifier.dart`) - CE N'EST PAS
  /// un PEM/SPKI (à la différence de la clé publique serveur).
  final String devicePublicKeyBase64Url;

  /// `uid` - identifiant du moniteur titulaire du certificat.
  final String userId;

  /// `sid` - identifiant de l'école, `null` si le moniteur n'est rattaché à
  /// aucune école (le champ est alors ABSENT du JSON source, jamais `null`
  /// explicite - voir `canonicalJsonStringify`/omission de clé).
  final String? schoolId;

  /// `nb` (not-before) - epoch secondes, début de la fenêtre de validité du
  /// certificat.
  final int notBeforeEpochSeconds;

  /// `na` (not-after) - epoch secondes, fin de la fenêtre de validité.
  final int notAfterEpochSeconds;

  /// `cv` - version du schéma de certificat (évolutivité future).
  final int certVersion;

  /// Signature Ed25519 détachée (base64url) du serveur sur
  /// [unsignedJson] (ce certificat SANS `certSignature`).
  final String certSignature;

  /// Structure JSON brute décodée du certificat (avec `certSignature`).
  final Map<String, dynamic> raw;

  /// Certificat sans `certSignature` - c'est exactement ce que le serveur a
  /// signé. Utilisé à la fois pour la vérification (`mock_exam_qr_verifier.dart`)
  /// et pour la construction côté "builder" (émission du certificat côté
  /// backend / signature côté moniteur hors-ligne, Phase 1b) : les deux
  /// DOIVENT sérialiser exactement ce Map via [canonicalJsonStringify].
  Map<String, dynamic> get unsignedJson =>
      Map<String, dynamic>.from(raw)..remove('certSignature');
}

/// Portées connues d'une référence d'épreuve (`p.sc`) - miroir de
/// `EXAM_PAPER_SCOPES` côté backend (`exam-paper.dto.ts`) et des constantes
/// `kExamPaperScope*` d'`exam_paper_offline_store.dart`. Dupliqué ici en
/// littéraux plutôt qu'importé, pour que ce fichier reste sans dépendance
/// Isar (voir en-tête) - les deux jeux de constantes DOIVENT rester en
/// synchronisation manuelle si une portée est ajoutée un jour côté serveur.
const Set<String> _kMockExamQrPaperScopes = {'PLATFORM', 'SCHOOL', 'MONITOR'};

/// Référence d'épreuve source (`p`, QR v5 uniquement, ADR-051) - portée +
/// numéro, miroir de `MockExamQrPaperRefDto` côté backend. Un numéro
/// d'épreuve n'est unique que PAR PORTÉE : [schoolId]/[monitorUserId] lèvent
/// l'ambiguïté pour les portées personnelles (`SCHOOL`/`MONITOR`), `null`
/// pour `PLATFORM` qui n'appartient à personne. STRICTEMENT informatif côté
/// mobile - ne participe JAMAIS à la composition jouée (voir doctrine
/// « les numéros font foi » en en-tête de fichier).
class MockExamQrPaperRef {
  const MockExamQrPaperRef({
    required this.scope,
    required this.number,
    this.schoolId,
    this.monitorUserId,
  });

  /// `sc` - `'PLATFORM'` | `'SCHOOL'` | `'MONITOR'`. `String` simple, jamais
  /// un `enum` Dart : une portée future inconnue dégrade déjà en `null` au
  /// parsing (voir [_tryParsePaperRef]), pas de valeur qui lèverait ici.
  final String scope;

  /// `num` - numéro tel que cité à l'oral par l'encadrant (« lance l'épreuve
  /// 12 »). Unique PAR PORTÉE seulement - voir [scope]/[schoolId]/[monitorUserId].
  final int number;

  /// `sid` - identifiant de l'auto-école, présent UNIQUEMENT si
  /// [scope] == `'SCHOOL'`.
  final String? schoolId;

  /// `uid` - identifiant du moniteur indépendant, présent UNIQUEMENT si
  /// [scope] == `'MONITOR'`.
  final String? monitorUserId;
}

/// Payload QR v3, v4, v5 OU v6 décodé (voir en-tête de fichier). [raw] conserve la
/// structure JSON décodée telle quelle (clés incluses `sig`) - nécessaire
/// pour reconstruire la sérialisation canonique lors de la vérification de
/// signature (`mock_exam_qr_verifier.dart`), qui doit resigner exactement les
/// mêmes champs que ceux effectivement reçus, pas une reconstruction depuis
/// les champs typés (résilience à un futur champ additionnel non modélisé
/// ici encore).
class MockExamQrPayload {
  const MockExamQrPayload({
    required this.version,
    required this.sessionCode,
    this.clientLocalId,
    this.offlineCreated = false,
    required this.mode,
    required this.durationSeconds,
    required this.language,
    required this.questionCount,
    required this.questionNumbers,
    required this.criteria,
    required this.expiresAtEpochSeconds,
    this.sessionDeadlineEpochSeconds,
    this.scheduledAtEpochSeconds,
    this.sessionTitle,
    required this.signature,
    this.cert,
    this.paperRef,
    this.keyId,
    this.monitorId,
    this.schoolId,
    this.organizerName,
    this.isSimulation = false,
    required this.raw,
  });

  final int version;

  /// Composition d'ENTRAÎNEMENT que le candidat a déclenchée lui-même
  /// (« Simuler », menu de l'onglet Examens blancs) - il n'y a ni séance, ni
  /// encadrant, ni serveur derrière elle.
  ///
  /// ⛔ N'est JAMAIS lu d'un JSON, et ne doit jamais l'être : il est posé par
  /// [buildMockExamSimulationPayload] et par personne d'autre. Un QR qui se
  /// déclarerait simulation ferait taire d'un coup l'inscription, l'envoi des
  /// réponses et la soumission d'une VRAIE épreuve - la copie serait composée
  /// puis perdue en silence.
  ///
  /// Ce que le drapeau éteint, et pourquoi (voir `ExamOfflineSource`) : les
  /// trois mises en file (inscription, réponses, soumission). Une simulation
  /// n'a aucune session à rejoindre : ces mutations partiraient au serveur au
  /// prochain réseau pour se faire rejeter une à une.
  final bool isSimulation;

  /// `code` (v3 uniquement) - code de session `EB-XXXX` déjà existant côté
  /// serveur. **Vide (`''`) en v4** (l'examen n'existe pas encore côté
  /// serveur au moment du scan - voir [clientLocalId]). Volontairement gardé
  /// non-nullable (au lieu de `String?`) pour ne pas casser la signature des
  /// call-sites v3 existants (`quiz_list_page.dart`, `attempt_source.dart`,
  /// qui passent ce champ directement à des paramètres `String`) - tout code
  /// qui consomme un payload potentiellement v4 DOIT d'abord tester
  /// [clientLocalId] `!= null` (ou `version == 4`) avant de se rabattre sur
  /// [sessionCode].
  final String sessionCode;

  /// `lid` (v4 uniquement) - `clientLocalId` (UUID), clé de jointure
  /// offline. `null` en v3. C'est l'identifiant à utiliser en v4 partout où
  /// v3 utiliserait [sessionCode] (l'examen n'a pas encore de `sessionCode`
  /// serveur tant qu'il n'a pas été synchronisé).
  final String? clientLocalId;

  /// `oc` (v4 uniquement, `true` si `oc == 1`) - marqueur "créé hors-ligne".
  /// Toujours `false` en v3.
  final bool offlineCreated;

  final MockExamQrDistributionMode mode;
  final int durationSeconds;
  final String language;
  final int questionCount;

  /// Numéros exacts du tirage - présent uniquement en
  /// `sameForAll`/`randomShared`, et JAMAIS en v6 (les numéros y sont retenus
  /// jusqu'au lancement, la composition se retrouve localement depuis
  /// [paperRef] - voir en-tête de fichier).
  final List<int>? questionNumbers;

  /// Critères de tirage local - présent uniquement en `randomPerCandidate`.
  final MockExamQrCriteria? criteria;

  final int expiresAtEpochSeconds;

  /// `t` - titre de la séance, tel que l'encadrant l'a nommée. `null` quand
  /// elle n'en a pas, et sur tout QR émis avant le 2026-09-06.
  ///
  /// ⛔ C'est la SEULE source du nom de l'épreuve pour un candidat qui compose
  /// hors ligne : ni l'API des questions ni le cadrage local ne le portent, et
  /// l'écran de résultat n'affichait donc que « Examen blanc », le libellé
  /// générique (retour Martin, 2026-09-06).
  final String? sessionTitle;

  /// `end` - ÉCHÉANCE de la séance (epoch secondes), c'est-à-dire l'instant où
  /// la composition s'arrête pour tout le monde (`launchedAt + dur` côté
  /// serveur). `null` quand la session n'a pas de durée, et sur tout QR émis
  /// avant le 2026-09-06.
  ///
  /// ⛔ À ne pas confondre avec [expiresAtEpochSeconds], qui borne la durée de
  /// vie du QR lui-même. C'est CE champ qui permet de décompter hors ligne le
  /// temps RESTANT plutôt que de repartir du délai plein : scanner dix minutes
  /// après le lancement d'une séance de trente minutes doit laisser vingt
  /// minutes de composition, pas trente - sans quoi le retardataire compose
  /// plus longtemps que ses camarades, et voit sa note plus tard (retour
  /// Martin, 2026-09-06).
  final int? sessionDeadlineEpochSeconds;

  /// `sch` - HEURE PRÉVUE de la séance (epoch secondes), c'est-à-dire
  /// l'instant où la composition doit OUVRIR. `null` quand la séance n'est pas
  /// programmée, et sur tout QR émis avant le 2026-09-07.
  ///
  /// ⛔ C'est le SEUL repère d'un candidat hors ligne, et son absence est
  /// signifiante : le QR ne peut pas porter le statut de la séance (il est
  /// imprimé avant le top départ et scanné pendant, son statut serait donc
  /// toujours périmé). Une heure prévue encore à venir dit « pas encore » ;
  /// pas d'heure du tout dit « composable dès le scan », jamais « inconnu »
  /// (retour Martin, 2026-09-07).
  ///
  /// ⛔ À ne pas confondre avec [sessionDeadlineEpochSeconds], qui dit quand la
  /// composition S'ARRÊTE - les confondre ferait attendre la fin de l'épreuve
  /// pour la commencer.
  final int? scheduledAtEpochSeconds;

  /// Signature Ed25519 détachée (base64url) du champ `sig`.
  /// - v3 : signature SERVEUR - absente si le backend n'a pas de clé de
  ///   signature configurée (dégradation best-effort, voir
  ///   `mock_exam_qr_verifier.dart`).
  /// - v4 : signature APPAREIL (moniteur) - toujours présente (requise au
  ///   parsing, voir `tryParseMockExamQrPayload`).
  final String? signature;

  /// `cert` (v4 uniquement) - certificat d'appareil signé par le serveur,
  /// voir [MockExamQrCertificate]. `null` en v3.
  final MockExamQrCertificate? cert;

  /// `p` (v5 et v6) - référence de l'épreuve source, voir
  /// [MockExamQrPaperRef]. OBLIGATOIRE en v6 (un v6 sans `p` exploitable est
  /// refusé au parsing : sans numéros sur le QR, il ne désigne aucune
  /// composition). `null` en v3/v4, ET `null` en v5 si `p` est
  /// absent/malformé/de portée inconnue (dégradation silencieuse au parsing,
  /// voir [_tryParsePaperRef]) - un `paperRef` `null` ne signifie JAMAIS que
  /// le payload est invalide, `q`/[questionNumbers] restant intact dans tous
  /// les cas. STRICTEMENT informatif : jamais utilisé pour composer
  /// l'examen (voir doctrine « les numéros font foi » en en-tête de fichier).
  final MockExamQrPaperRef? paperRef;

  /// `kid` (optionnel, toutes versions) - identifiant de la clé de signature
  /// employée. Sert UNIQUEMENT à résoudre la bonne clé publique de
  /// vérification après une rotation de clé côté serveur ; il ne dit rien de
  /// la validité de la signature elle-même. `null` sur un payload émis par un
  /// backend antérieur à ce champ, ce qui reste parfaitement légal (le
  /// vérificateur retombe alors sur la clé courante).
  final String? keyId;

  /// `mid` (optionnel, toutes versions) - identifiant du moniteur
  /// organisateur.
  ///
  /// ⚠️ Sert au client à dire TOUT DE SUITE qu'il n'est rattaché ni à ce
  /// moniteur ni à cette [schoolId] ; il ne prouve JAMAIS l'inverse. Seul le
  /// serveur fait autorité sur le rattachement : une correspondance locale
  /// n'est pas une autorisation.
  final String? monitorId;

  /// `sid` (optionnel, toutes versions) - identifiant de l'auto-école
  /// organisatrice. Mêmes réserves que [monitorId].
  ///
  /// À ne pas confondre avec le `sid` du sous-objet `cert` (école du
  /// certificat d'appareil, v4) ni avec celui du sous-objet `p` (portée d'une
  /// référence d'épreuve).
  final String? schoolId;

  /// `org` (optionnel, toutes versions) - libellé d'affichage de
  /// l'organisateur, tel que le candidat doit le lire avant de composer
  /// (« au nom de qui cette épreuve est lancée »). Purement informatif :
  /// jamais un identifiant, jamais une preuve.
  final String? organizerName;

  /// Structure JSON brute décodée (avec `sig`) - source de vérité pour
  /// resigner/revérifier (canonicalisation).
  final Map<String, dynamic> raw;

  bool get isExpired =>
      DateTime.now().toUtc().millisecondsSinceEpoch / 1000 >
      expiresAtEpochSeconds;

  /// Payload sans `sig` - c'est exactement ce que le backend a signé
  /// (`UnsignedMockExamQrPayload`).
  ///
  /// ⚠️ Dérivé de [raw] moins `sig`, JAMAIS reconstruit depuis les champs
  /// typés : c'est cette propriété qui rend l'ajout de champs côté serveur
  /// (`kid`, `mid`, `sid`, `org`, et tout champ futur) totalement transparent
  /// pour la vérification de signature. La modéliser autrement casserait
  /// silencieusement TOUTES les signatures au premier champ non modélisé ici.
  Map<String, dynamic> get unsignedJson =>
      Map<String, dynamic>.from(raw)..remove('sig');
}

/// Chaîne `trim()`ée, ou `null` si absente/vide/d'un autre type. Les champs
/// optionnels transverses (`kid`/`mid`/`sid`/`org`) passent tous par ici : une
/// chaîne vide vaut une absence, et leur absence ne doit JAMAIS faire échouer
/// un parsing.
String? _asTrimmedString(dynamic v) {
  if (v is! String) return null;
  final t = v.trim();
  return t.isEmpty ? null : t;
}

int? _asInt(dynamic v) {
  if (v is int) return v;
  if (v is num) return v.toInt();
  if (v is String) return int.tryParse(v.trim());
  return null;
}

/// Champs communs à v3 et v4 (`mode/dur/lang/n/q?/c?/exp`) - factorisé pour
/// éviter la duplication entre `_tryParseV3`/`_tryParseV4`. Retourne `null`
/// dès qu'un champ requis manque ou est incohérent (mêmes règles qu'avant
/// l'introduction de v4 : voir les commentaires historiques ci-dessous).
class _CommonQrFields {
  const _CommonQrFields({
    required this.mode,
    required this.durationSeconds,
    required this.language,
    required this.questionCount,
    required this.expiresAtEpochSeconds,
    required this.sessionDeadlineEpochSeconds,
    required this.scheduledAtEpochSeconds,
    required this.sessionTitle,
    required this.questionNumbers,
    required this.criteria,
  });

  final MockExamQrDistributionMode mode;
  final int durationSeconds;
  final String language;
  final int questionCount;
  final int expiresAtEpochSeconds;

  /// `end` - échéance ABSOLUE de la séance (`launchedAt + dur`).
  final int? sessionDeadlineEpochSeconds;

  /// `sch` - heure PRÉVUE d'ouverture de la séance.
  final int? scheduledAtEpochSeconds;

  /// `t` - titre de la séance.
  final String? sessionTitle;
  final List<int>? questionNumbers;
  final MockExamQrCriteria? criteria;
}

/// [requireDraw] vaut `true` partout sauf en v6. À `true`, le tirage est
/// EXIGÉ : `c` en `randomPerCandidate`, `q` (de longueur exactement `n`) dans
/// les deux autres modes - un QR corrompu qui les perd est proprement rejeté,
/// et ce comportement ne doit JAMAIS fuir vers v3/v4/v5. À `false` (v6
/// uniquement), les numéros sont retenus jusqu'au lancement : `questionNumbers`
/// vaut `null` et le contrôle de longueur est sauté, `c` restant lu en
/// best-effort quand il est présent.
_CommonQrFields? _tryParseCommonFields(
  Map<String, dynamic> json, {
  bool requireDraw = true,
}) {
  final mode = MockExamQrDistributionMode.fromIndex(_asInt(json['mode']));
  if (mode == null) return null;

  final dur = _asInt(json['dur']);
  final n = _asInt(json['n']);
  final exp = _asInt(json['exp']);
  if (dur == null || n == null || exp == null) return null;
  // Garde-fou robustesse : rejette les valeurs numeriques incoherentes (QR
  // corrompu ou forge), d'autant plus important en mode degrade (sig absente).
  if (dur <= 0 || n <= 0 || exp <= 0) return null;

  // `end` - échéance ABSOLUE de la séance, ajoutée le 2026-09-06. ABSENTE des
  // QR déjà en circulation et des sessions sans durée : lecture DÉFENSIVE, son
  // absence ramène au comportement historique (délai plein depuis le scan).
  // Une valeur non positive est traitée comme absente, jamais comme une
  // échéance déjà passée.
  final end = _asInt(json['end']);
  final sessionDeadline = (end != null && end > 0) ? end : null;

  // `sch` - heure PRÉVUE d'ouverture, ajoutée le 2026-09-07. ABSENTE des QR
  // déjà en circulation et des séances non programmées : lecture DÉFENSIVE,
  // son absence ramène au comportement historique (composable dès le scan).
  // Une valeur non positive est traitée comme absente, jamais comme une heure
  // déjà passée.
  final sch = _asInt(json['sch']);
  final scheduledAt = (sch != null && sch > 0) ? sch : null;

  // `t` - titre de la séance, ajouté le 2026-09-06. Absent des QR déjà en
  // circulation et des séances sans titre : lecture DÉFENSIVE, son absence
  // ramène au libellé générique « Examen blanc ».
  final title = _asTrimmedString(json['t']);

  final lang = (json['lang'] as String?)?.trim();

  List<int>? questionNumbers;
  MockExamQrCriteria? criteria;
  if (!requireDraw) {
    // v6 : la composition se retrouve localement depuis `p`, pas depuis le QR.
    // `questionNumbers` reste `null` - c'est le contrat, pas une dégradation.
    final c = json['c'];
    if (c is Map) {
      criteria = MockExamQrCriteria.fromJson(Map<String, dynamic>.from(c));
    }
  } else if (mode == MockExamQrDistributionMode.randomPerCandidate) {
    final c = json['c'];
    if (c is! Map) return null;
    criteria = MockExamQrCriteria.fromJson(Map<String, dynamic>.from(c));
  } else {
    final q = json['q'];
    if (q is! List) return null;
    final numbers = <int>[];
    for (final e in q) {
      final v = _asInt(e);
      if (v == null) return null;
      numbers.add(v);
    }
    // Modes a questions fixes : le nombre de numeros doit correspondre a `n`
    // (un QR ou q.length != n est incoherent/corrompu). Couvre aussi le cas vide.
    if (numbers.length != n) return null;
    questionNumbers = numbers;
  }

  return _CommonQrFields(
    mode: mode,
    durationSeconds: dur,
    language: (lang?.isNotEmpty ?? false) ? lang! : 'fr',
    questionCount: n,
    expiresAtEpochSeconds: exp,
    sessionDeadlineEpochSeconds: sessionDeadline,
    scheduledAtEpochSeconds: scheduledAt,
    sessionTitle: title,
    questionNumbers: questionNumbers,
    criteria: criteria,
  );
}

/// Décode le sous-objet `cert` (v4 uniquement) - voir [MockExamQrCertificate].
/// Retourne `null` si [value] n'est pas un objet ou s'il manque un champ
/// requis (`sid` seul est optionnel - absent, jamais `null`).
MockExamQrCertificate? _tryParseCert(dynamic value) {
  if (value is! Map) return null;
  final json = Map<String, dynamic>.from(value);

  final did = (json['did'] as String?)?.trim();
  final dpk = (json['dpk'] as String?)?.trim();
  final uid = (json['uid'] as String?)?.trim();
  final sid = (json['sid'] as String?)?.trim();
  final nb = _asInt(json['nb']);
  final na = _asInt(json['na']);
  final cv = _asInt(json['cv']);
  final certSignature = (json['certSignature'] as String?)?.trim();

  if (did == null || did.isEmpty) return null;
  if (dpk == null || dpk.isEmpty) return null;
  if (uid == null || uid.isEmpty) return null;
  if (nb == null || na == null || cv == null) return null;
  if (certSignature == null || certSignature.isEmpty) return null;

  return MockExamQrCertificate(
    deviceId: did,
    devicePublicKeyBase64Url: dpk,
    userId: uid,
    schoolId: (sid?.isNotEmpty ?? false) ? sid : null,
    notBeforeEpochSeconds: nb,
    notAfterEpochSeconds: na,
    certVersion: cv,
    certSignature: certSignature,
    raw: json,
  );
}

/// Décode le sous-objet `p` (v5 uniquement) - référence d'épreuve, voir
/// [MockExamQrPaperRef]. Retourne `null` (JAMAIS de throw) dès que [value]
/// n'est pas exploitable : absent, pas un objet, portée hors de
/// [_kMockExamQrPaperScopes], numéro absent/non-positif, ou portée
/// `SCHOOL`/`MONITOR` sans l'identifiant qui la désambiguïse. Un `p`
/// dégradé ne fait JAMAIS échouer le parsing du payload v5 tout entier -
/// c'est `_tryParseV5` qui décide de continuer sans référence d'épreuve
/// (voir sa doc), exactement comme un v3 sans `sig`.
MockExamQrPaperRef? _tryParsePaperRef(dynamic value) {
  if (value is! Map) return null;
  final json = Map<String, dynamic>.from(value);

  final scope = (json['sc'] as String?)?.trim();
  if (scope == null || !_kMockExamQrPaperScopes.contains(scope)) return null;

  final number = _asInt(json['num']);
  if (number == null || number <= 0) return null;

  final schoolId = (json['sid'] as String?)?.trim();
  final monitorUserId = (json['uid'] as String?)?.trim();

  if (scope == 'SCHOOL' && (schoolId == null || schoolId.isEmpty)) {
    return null;
  }
  if (scope == 'MONITOR' && (monitorUserId == null || monitorUserId.isEmpty)) {
    return null;
  }

  return MockExamQrPaperRef(
    scope: scope,
    number: number,
    schoolId: (schoolId?.isNotEmpty ?? false) ? schoolId : null,
    monitorUserId: (monitorUserId?.isNotEmpty ?? false) ? monitorUserId : null,
  );
}

/// v3 - signature SERVEUR directe, `code` = session déjà existante.
MockExamQrPayload? _tryParseV3(Map<String, dynamic> json) {
  final code = (json['code'] as String?)?.trim();
  if (code == null || code.isEmpty) return null;

  final common = _tryParseCommonFields(json);
  if (common == null) return null;

  final sig = (json['sig'] as String?)?.trim();

  return MockExamQrPayload(
    version: 3,
    sessionCode: code,
    mode: common.mode,
    durationSeconds: common.durationSeconds,
    language: common.language,
    questionCount: common.questionCount,
    questionNumbers: common.questionNumbers,
    criteria: common.criteria,
    expiresAtEpochSeconds: common.expiresAtEpochSeconds,
    sessionDeadlineEpochSeconds: common.sessionDeadlineEpochSeconds,
    scheduledAtEpochSeconds: common.scheduledAtEpochSeconds,
    sessionTitle: common.sessionTitle,
    signature: (sig?.isNotEmpty ?? false) ? sig : null,
    keyId: _asTrimmedString(json['kid']),
    monitorId: _asTrimmedString(json['mid']),
    schoolId: _asTrimmedString(json['sid']),
    organizerName: _asTrimmedString(json['org']),
    raw: json,
  );
}

/// v5 - v3 enrichie d'une référence d'épreuve optionnelle (`p`, ADR-051).
/// Mêmes règles de parsing que v3 pour tous les champs communs - `q` reste
/// OBLIGATOIRE et fait foi (`_tryParseCommonFields`, hérité tel quel). `p`
/// est décodé en best-effort via [_tryParsePaperRef] : un `p` invalide
/// dégrade [MockExamQrPayload.paperRef] à `null` SANS jamais faire échouer
/// le parsing de tout le payload (voir en-tête de fichier).
MockExamQrPayload? _tryParseV5(Map<String, dynamic> json) {
  final code = (json['code'] as String?)?.trim();
  if (code == null || code.isEmpty) return null;

  final common = _tryParseCommonFields(json);
  if (common == null) return null;

  final sig = (json['sig'] as String?)?.trim();

  return MockExamQrPayload(
    version: 5,
    sessionCode: code,
    mode: common.mode,
    durationSeconds: common.durationSeconds,
    language: common.language,
    questionCount: common.questionCount,
    questionNumbers: common.questionNumbers,
    criteria: common.criteria,
    expiresAtEpochSeconds: common.expiresAtEpochSeconds,
    sessionDeadlineEpochSeconds: common.sessionDeadlineEpochSeconds,
    scheduledAtEpochSeconds: common.scheduledAtEpochSeconds,
    sessionTitle: common.sessionTitle,
    signature: (sig?.isNotEmpty ?? false) ? sig : null,
    paperRef: _tryParsePaperRef(json['p']),
    keyId: _asTrimmedString(json['kid']),
    monitorId: _asTrimmedString(json['mid']),
    schoolId: _asTrimmedString(json['sid']),
    organizerName: _asTrimmedString(json['org']),
    raw: json,
  );
}

/// v6 - v5 dont les NUMÉROS SONT RETENUS jusqu'au lancement (voir en-tête de
/// fichier). Calquée sur [_tryParseV5], à deux différences près :
/// - `q` n'est plus lu (`requireDraw: false`), donc
///   [MockExamQrPayload.questionNumbers] vaut `null` - c'est le contrat de la
///   version, jamais un payload incomplet ;
/// - `p` devient OBLIGATOIRE : un v6 sans référence d'épreuve exploitable ne
///   désigne aucune composition (rien sur le QR, rien à résoudre en local), il
///   est donc refusé plutôt que dégradé.
MockExamQrPayload? _tryParseV6(Map<String, dynamic> json) {
  final code = (json['code'] as String?)?.trim();
  if (code == null || code.isEmpty) return null;

  final common = _tryParseCommonFields(json, requireDraw: false);
  if (common == null) return null;

  final paperRef = _tryParsePaperRef(json['p']);
  if (paperRef == null) return null;

  final sig = (json['sig'] as String?)?.trim();

  return MockExamQrPayload(
    version: 6,
    sessionCode: code,
    mode: common.mode,
    durationSeconds: common.durationSeconds,
    language: common.language,
    questionCount: common.questionCount,
    questionNumbers: common.questionNumbers,
    criteria: common.criteria,
    expiresAtEpochSeconds: common.expiresAtEpochSeconds,
    sessionDeadlineEpochSeconds: common.sessionDeadlineEpochSeconds,
    scheduledAtEpochSeconds: common.scheduledAtEpochSeconds,
    sessionTitle: common.sessionTitle,
    signature: (sig?.isNotEmpty ?? false) ? sig : null,
    paperRef: paperRef,
    keyId: _asTrimmedString(json['kid']),
    monitorId: _asTrimmedString(json['mid']),
    schoolId: _asTrimmedString(json['sid']),
    organizerName: _asTrimmedString(json['org']),
    raw: json,
  );
}

/// v4 - examen créé hors-ligne (ADR-013 Phase 2) : `lid` remplace `code`,
/// `cert` + `sig` (signature APPAREIL, requise) portent la chaîne de
/// confiance vérifiée par `mock_exam_qr_verifier.dart`.
MockExamQrPayload? _tryParseV4(Map<String, dynamic> json) {
  final lid = (json['lid'] as String?)?.trim();
  if (lid == null || lid.isEmpty) return null;

  // `oc` doit valoir exactement 1 (marqueur offline-created) - toute autre
  // valeur est un QR incohérent/forgé.
  if (_asInt(json['oc']) != 1) return null;

  final common = _tryParseCommonFields(json);
  if (common == null) return null;

  final cert = _tryParseCert(json['cert']);
  if (cert == null) return null;

  // Contrairement à v3, `sig` est OBLIGATOIRE en v4 : sans elle il n'y a
  // aucune chaîne de confiance possible (pas de mode dégradé v4, voir
  // `MockExamQrVerificationResult.isAcceptable`).
  final sig = (json['sig'] as String?)?.trim();
  if (sig == null || sig.isEmpty) return null;

  return MockExamQrPayload(
    version: 4,
    // Absent en v4 - voir la doc du champ sur MockExamQrPayload.sessionCode.
    sessionCode: '',
    clientLocalId: lid,
    offlineCreated: true,
    mode: common.mode,
    durationSeconds: common.durationSeconds,
    language: common.language,
    questionCount: common.questionCount,
    questionNumbers: common.questionNumbers,
    criteria: common.criteria,
    expiresAtEpochSeconds: common.expiresAtEpochSeconds,
    sessionDeadlineEpochSeconds: common.sessionDeadlineEpochSeconds,
    scheduledAtEpochSeconds: common.scheduledAtEpochSeconds,
    sessionTitle: common.sessionTitle,
    signature: sig,
    cert: cert,
    keyId: _asTrimmedString(json['kid']),
    monitorId: _asTrimmedString(json['mid']),
    schoolId: _asTrimmedString(json['sid']),
    organizerName: _asTrimmedString(json['org']),
    raw: json,
  );
}

/// Tente de décoder [raw] (contenu brut scanné/saisi) en payload QR v3, v4,
/// v5 ou v6.
///
/// Retourne `null` si [raw] n'est pas un JSON d'objet, ou s'il manque un
/// champ requis, ou si `v` n'est ni 3 ni 4 ni 5 ni 6, ou si `mode` est hors
/// table -
/// dans tous ces cas l'appelant doit retomber sur l'interprétation « code de
/// session brut » (comportement historique, voir
/// `WhiteExamStartPage`/scanner). Ne lance JAMAIS d'exception : un QR
/// corrompu/inattendu doit dégrader, pas planter. Toute AUTRE version que
/// 3/4/5/6 (y compris une version future encore inconnue) suit le même repli -
/// c'est le même mécanisme de discrimination qui a déjà séparé v3 de v4
/// avant l'introduction de v5 (voir en-tête de `mock-exam-qr.service.ts`
/// côté backend).
MockExamQrPayload? tryParseMockExamQrPayload(String raw) {
  final trimmed = raw.trim();
  if (trimmed.isEmpty || trimmed[0] != '{') {
    // Repli rapide avant même de tenter un jsonDecode coûteux : un code de
    // session brut (EB-XXXX) ou tout autre contenu non-JSON n'a jamais cette
    // forme.
    return null;
  }
  Map<String, dynamic> json;
  try {
    final decoded = jsonDecode(trimmed);
    if (decoded is! Map) return null;
    json = Map<String, dynamic>.from(decoded);
  } catch (_) {
    return null;
  }

  final version = _asInt(json['v']);
  if (version == 3) return _tryParseV3(json);
  if (version == 4) return _tryParseV4(json);
  if (version == 5) return _tryParseV5(json);
  if (version == 6) return _tryParseV6(json);
  return null;
}

/// Sérialisation JSON canonique (clés triées récursivement, sans espaces) -
/// PORT EXACT de `canonicalJsonStringify` côté backend
/// (`mock-exam-qr.service.ts`). Doit produire un octet-à-octet identique pour
/// que la vérification Ed25519 (signature calculée côté serveur sur cette
/// même sérialisation) soit possible. Toute divergence ici (tri, séparateurs,
/// échappement de chaîne) casse silencieusement TOUTES les signatures.
///
/// NB : contrairement à la version JS, un `Map` Dart issu de `jsonDecode` ne
/// peut jamais contenir de valeur "undefined" (seulement une clé absente ou
/// `null` explicite) - le filtre `!== undefined` du code JS n'a donc pas
/// d'équivalent nécessaire ici : toute clé présente dans le Map est incluse.
String canonicalJsonStringify(dynamic value) {
  if (value == null) return 'null';
  if (value is num || value is bool) return jsonEncode(value);
  if (value is String) return jsonEncode(value);
  if (value is List) {
    return '[${value.map(canonicalJsonStringify).join(',')}]';
  }
  if (value is Map) {
    final keys = value.keys.map((k) => k.toString()).toList()..sort();
    final entries = keys.map(
      (k) => '${jsonEncode(k)}:${canonicalJsonStringify(value[k])}',
    );
    return '{${entries.join(',')}}';
  }
  throw ArgumentError(
    'canonicalJsonStringify: type non sérialisable (${value.runtimeType})',
  );
}

/// Reconstruit la chaîne canonique EXACTE que le PAYLOAD complet (v3 côté
/// serveur, v4 côté appareil) doit signer/vérifier : [payloadJson] SANS la
/// clé `sig`, sérialisé via [canonicalJsonStringify].
///
/// Réutilisable aussi bien côté "builder" (émission du QR v4 par l'appareil
/// moniteur hors-ligne, Phase 1b - autre lot) que côté vérification (ce
/// fichier / `mock_exam_qr_verifier.dart`) - les deux DOIVENT produire un
/// octet-à-octet identique, faute de quoi la signature ne matchera jamais.
/// Équivalent de `MockExamQrPayload.unsignedJson` mais opérant directement
/// sur un `Map` brut (utile avant même la construction d'une instance
/// [MockExamQrPayload], typiquement côté builder).
String canonicalUnsignedPayloadJson(Map<String, dynamic> payloadJson) {
  final copy = Map<String, dynamic>.from(payloadJson)..remove('sig');
  return canonicalJsonStringify(copy);
}

/// Reconstruit la chaîne canonique EXACTE que le CERTIFICAT (`cert`, v4
/// uniquement) doit signer/vérifier : [certJson] SANS la clé `certSignature`,
/// sérialisé via [canonicalJsonStringify].
///
/// Réutilisable côté "builder" (émission du certificat par le serveur lors
/// d'une connexion en ligne préalable du moniteur, Phase 0/1b - autres lots)
/// comme côté vérification (`mock_exam_qr_verifier.dart`) - même contrat que
/// [canonicalUnsignedPayloadJson]. Équivalent de
/// `MockExamQrCertificate.unsignedJson` mais opérant directement sur un `Map`
/// brut.
String canonicalUnsignedCertJson(Map<String, dynamic> certJson) {
  final copy = Map<String, dynamic>.from(certJson)..remove('certSignature');
  return canonicalJsonStringify(copy);
}
