// =============================================================================
// MockExamDeviceService - Emission de certificats d'emission (mini-PKI,
// ADR-013, amendee ADR-051 SS11)
// =============================================================================
//
// Emet un certificat signe par la cle serveur DEJA existante des QR examens
// blancs (MOCK_EXAM_QR_SIGNING_PRIVATE_KEY, cf. MockExamQrService.signValue) -
// AUCUN nouveau secret introduit. Ce certificat permet a un candidat hors-ligne
// de verifier qu'un QR v4 (signe localement par l'emetteur) provient bien d'un
// emetteur legitime. Deux chemins d'emission, MEME format de certificat :
//  - `enrollDevice` : la paire de cles est generee SUR l'appareil mobile
//    (flutter_secure_storage), seule la cle publique est envoyee ici.
//  - `issueWebToken` : la paire de cles est generee PAR CE SERVICE pour le
//    portail web (pas d'enrolement d'appareil, pas de cle generee dans le
//    navigateur) - la cle privee est rendue une seule fois, jamais persistee.
//
// Invariant central (cf. ADR-013) : la crypto d'emetteur n'est JAMAIS la
// racine d'autorite serveur. Elle ne fait qu'ajouter un signal anti-nuisance
// UX pour le candidat hors-ligne. La securite reelle repose sur la
// revalidation serveur au moment du flush (JWT moniteur, cf.
// MockExamService.createSession).
//
// ADR-051 SS11 (2026-09-02) : plus d'expiration courte (cf.
// PERMANENT_NOT_AFTER_SECONDS ci-dessous) - la REVOCATION (DevicesService,
// au geste "supprimer un appareil") remplace l'expiration comme mecanisme de
// securite, pour tenir la promesse d'un hors-ligne qui dure des annees.
//
// Lot K (C-K10) : cette revocation n'avait AUCUNE portee hors ligne. Elle
// existait en base, aucun canal ne la portait au candidat, et un appareil
// encadrant vole continuait de fabriquer des QR v4 acceptes hors ligne avec un
// certificat valable jusqu'en 2999. `getRevocationBundle()` ferme cet ecart en
// diffusant la liste SIGNEE des empreintes revoquees sur la route publique des
// cles. La duree de validite permanente, elle, n'est PAS touchee : l'arbitrage
// d'ADR-051 SS11 tient (un poste d'auto-ecole n'est parfois connecte qu'une
// seule fois, une expiration courte desactiverait exactement la fonction pour
// laquelle il est enrole).
// =============================================================================

import {
  BadRequestException,
  Injectable,
  Logger,
  ServiceUnavailableException,
} from '@nestjs/common';
import { createHash, createPublicKey, generateKeyPairSync } from 'crypto';
import { PrismaService } from '@app/database';
import { Prisma } from '@app/prisma';
import { MonitorDevicePlatform } from '../../../../../../../prisma/generated/enums';
import { ERRORS } from '../../../../common/constants/app.constants';
import { DiscordAlertService } from '../../../../common/alerts/discord-alert.service';
import { MockExamQrService } from './mock-exam-qr.service';
import type { EnrollDeviceDto } from '../dto/enroll-device.dto';
import type { DeviceCertificateDto } from '../dto/device-certificate.dto';
import type { WebIssuanceTokenDto } from '../dto/web-issuance-token.dto';

// ---------------------------------------------------------------------------
// Constantes
// ---------------------------------------------------------------------------

/** Version courante du schema de certificat (`cv`). */
const CERT_VERSION = 1;

/**
 * Fin de validite retenue pour TOUT certificat emis desormais (ADR-051 SS11,
 * 2026-09-02) : une date TRES LOINTAINE plutot que l'absence de borne haute.
 *
 * Contexte : les ordinateurs des auto-ecoles ne sont parfois connectes qu'une
 * seule fois (installation), jamais plus pendant des annees - une expiration
 * courte (14 jours a l'origine) desactivait alors la creation hors-ligne
 * d'examen blanc, exactement la fonction pour laquelle l'appareil est enrole.
 * La REVOCATION explicite (`revokedAt`, cf. DevicesService) remplace donc
 * l'expiration comme mecanisme de securite (voir aussi ADR-013, alternative
 * CRL/OCSP ecartee a l'epoque faute de levier de revocation reel - ce levier
 * existe desormais).
 *
 * Pourquoi une date lointaine plutot qu'un `na` absent/nul : `na` fait partie
 * du PAYLOAD SIGNE, et le verificateur mobile DEJA INSTALLE compare
 * `now <= na` en dur (cf. ADR-013 SS3). Omettre le champ ou le rendre nul
 * changerait la FORME du contrat alors que `cv` resterait a 1 - un
 * verificateur deja en circulation ne sait pas traiter une valeur absente
 * pour un champ qu'il attend numerique, et rien ne permet de le mettre a jour
 * retroactivement. Une date lointaine reste un NOMBRE ordinaire : tout
 * verificateur existant, ancien ou nouveau, l'accepte sans modification.
 *
 * Valeur : 2999-12-31 (epoch secondes ~ 32 503 679 999). Tres en dessous de
 * `Number.MAX_SAFE_INTEGER` (2^53) et d'un entier 64 bits (Dart `int`), donc
 * sans risque de depassement cote mobile ni cote serveur. Volontairement PAS
 * `Number.MAX_SAFE_INTEGER` lui-meme : une date lisible et plausible reste
 * plus sure a manipuler (soustractions de duree, formatage) qu'une valeur
 * choisie pour son extremum technique.
 *
 * Compatibilite avec les certificats DEJA emis (fenetre de 14 jours) : cette
 * constante ne s'applique qu'aux certificats emis A PARTIR de ce lot. Un
 * certificat deja distribue est un artefact SIGNE, donc immuable - impossible
 * de reecrire son `na` sans casser sa signature. Ces certificats restent
 * gouvernes par leur ancienne fenetre jusqu'au prochain (re)enrolement en
 * ligne, qui est un upsert sur (userId, deviceId) : il leur substitue alors un
 * certificat neuf, avec cette fenetre permanente.
 */
const PERMANENT_NOT_AFTER_SECONDS = Math.floor(
  new Date('2999-12-31T23:59:59.000Z').getTime() / 1000,
);

/**
 * Nombre maximal d'appareils ACTIFS (non revoques) par moniteur. Au-dela, le
 * plus ancien est revoque (FIFO) pour faire de la place au nouvel enrolement -
 * jamais de rejet de l'enrolement en cours (cf. ADR-013 - parametres retenus,
 * plage 3-5, borne haute retenue ici).
 */
const MAX_ACTIVE_DEVICES_PER_MONITOR = 5;

/** Seuil + fenetre d'alerte best-effort sur un pic anormal d'enrolements par un meme moniteur. */
const ENROLLMENT_SPIKE_THRESHOLD = 8;
const ENROLLMENT_SPIKE_WINDOW_MS = 60 * 60 * 1000;

/**
 * Duree de vie du cache memoire de la liste de revocation. La route qui la
 * sert est PUBLIQUE et appelee par tout le parc a chaque rafraichissement de
 * cle : une minute suffit a absorber les rafales sans jamais retarder
 * serieusement la prise en compte d'une revocation.
 */
const REVOCATION_BUNDLE_CACHE_MS = 60 * 1000;

/**
 * Seuil d'alerte sur la TAILLE de la liste de revocation. Au-dela, la reponse
 * d'une route publique devient lourde pour un reseau lent et il faudra la
 * paginer ou la basculer sur une route authentifiee. Poser le seuil maintenant
 * plutot que decouvrir le probleme en production.
 */
const REVOCATION_BUNDLE_SIZE_ALERT_THRESHOLD = 2000;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/**
 * Payload EXACT signe pour le certificat d'appareil - fige octet pour octet.
 * `canonicalJsonStringify` (MockExamQrService) trie les cles recursivement a
 * la signature : l'ORDRE de declaration ci-dessous n'a donc pas d'importance
 * pour la signature elle-meme, mais ce JEU de cles DOIT rester exactement
 * celui-ci (cf. ADR-013). `sid` et `kid` sont omis (jamais serialises a
 * `null`) si absents.
 *
 * AJOUT DE `kid` (lot K, C-L15) - pourquoi c'est sur alors que le jeu de cles
 * est declare fige : les DEUX implementations de verification reconstruisent
 * le message a partir du JSON RECU moins la signature (backend :
 * `canonicalJsonStringify` sur l'objet lu ; mobile :
 * `MockExamQrCertificate.unsignedJson`, derive de `raw` moins `certSignature`,
 * avec un commentaire qui invoque explicitement la resilience a un futur champ
 * additionnel non modelise), jamais depuis une liste de champs codee en dur.
 * Un champ ajoute AVANT la signature traverse donc la chaine sans casser un
 * seul verificateur deja deploye. ⛔ Ne jamais remplacer cette reconstruction
 * par une serialisation depuis les champs types : ce serait retirer la
 * propriete qui rend cet ajout possible.
 */
export interface MonitorDeviceCertPayload {
  did: string;
  dpk: string;
  uid: string;
  sid?: string;
  /**
   * Identifiant de la cle serveur qui a signe ce certificat. Permet a un
   * candidat hors ligne de resoudre la bonne cle publique apres une rotation.
   * Omis quand la signature n'est pas configuree.
   */
  kid?: string;
  nb: number;
  na: number;
  cv: number;
}

@Injectable()
export class MockExamDeviceService {
  private readonly logger = new Logger(MockExamDeviceService.name);

  /**
   * Cache memoire court de la liste de revocation (cf.
   * REVOCATION_BUNDLE_CACHE_MS) : la route qui la sert est publique et
   * sollicitee par tout le parc.
   */
  private revocationBundleCache: {
    bundle: {
      issuedAt: number;
      deviceIdHashes: string[];
      signature: string | null;
    };
    expiresAt: number;
  } | null = null;

  constructor(
    private readonly db: PrismaService,
    private readonly mockExamQrService: MockExamQrService,
    private readonly discordAlertService: DiscordAlertService,
  ) {}

  // ---------------------------------------------------------------------------
  // enrollDevice - Emet (ou renouvelle) le certificat d'un appareil moniteur
  // ---------------------------------------------------------------------------

  async enrollDevice(
    monitorId: string,
    schoolId: string | null,
    dto: EnrollDeviceDto,
  ): Promise<DeviceCertificateDto> {
    return this.issueCertificate(
      monitorId,
      schoolId,
      dto.deviceId,
      dto.publicKey,
      MonitorDevicePlatform.MOBILE,
    );
  }

  // ---------------------------------------------------------------------------
  // issueWebToken - Jeton d'emission pour le portail web (ADR-051 SS11, Volet 3)
  // ---------------------------------------------------------------------------
  //
  // Meme mini-PKI, meme format de certificat que enrollDevice(), mais la paire
  // de cles Ed25519 est generee ICI, par le serveur, au lieu d'etre generee
  // dans le navigateur : le portail web n'a ni l'infrastructure ni l'intention
  // de gerer une cle localement (pas de WebCrypto a securiser, pas d'ecran
  // d'enrolement). La cle PRIVEE n'est jamais persistee cote serveur - elle
  // n'existe que le temps de cet appel, et n'est renvoyee qu'UNE SEULE FOIS
  // dans la reponse (cf. WebIssuanceTokenDto). Seule la cle PUBLIQUE rejoint
  // `monitor_devices`, exactement comme pour un appareil mobile enrole.
  //
  // `browserDeviceId` est `Device.id` du navigateur courant (`user.deviceId`,
  // porte par le JWT) - jamais un identifiant fourni par le client. Reutiliser
  // cette valeur comme `deviceId` rend l'emission IDEMPOTENTE par session
  // navigateur (meme mecanisme de rotation que l'upsert mobile : rappeler
  // cette route depuis le meme navigateur remplace la cle et reemet un
  // certificat, au lieu d'empiler des lignes orphelines) et fournit, sans
  // colonne supplementaire, le lien de revocation "au meme geste" que le
  // Volet 2 : `DevicesService.deleteDevice` revoque toute ligne
  // `MonitorDevice` dont `deviceId` egale soit `Device.clientDeviceId`
  // (mobile), soit `Device.id` lui-meme (web).
  async issueWebToken(
    monitorId: string,
    schoolId: string | null,
    browserDeviceId: string,
  ): Promise<WebIssuanceTokenDto> {
    // Verifie AVANT de generer la paire de cles (redondant avec la meme
    // verification dans issueCertificate) : inutile de payer le cout d'une
    // generation Ed25519 si la signature serveur n'est de toute facon pas
    // configuree.
    if (!this.mockExamQrService.isSigningConfigured()) {
      throw new ServiceUnavailableException(
        ERRORS.DEVICE_CERT_SIGNING_UNAVAILABLE,
      );
    }

    const { publicKey, privateKey } = generateKeyPairSync('ed25519');
    const publicKeyPem = publicKey
      .export({ type: 'spki', format: 'pem' })
      .toString();
    const privateKeyPem = privateKey
      .export({ type: 'pkcs8', format: 'pem' })
      .toString();

    const certificate = await this.issueCertificate(
      monitorId,
      schoolId,
      browserDeviceId,
      publicKeyPem,
      MonitorDevicePlatform.WEB,
    );

    this.logger.log(
      `[MockExamDevice] Jeton d'émission web émis - moniteur=${monitorId} device=${browserDeviceId}`,
    );

    return { ...certificate, privateKey: privateKeyPem };
  }

  // ---------------------------------------------------------------------------
  // getRevocationBundle - Liste de revocation signee (C-K10)
  // ---------------------------------------------------------------------------

  /**
   * Liste SIGNEE des appareils encadrant revoques, servie par la route publique
   * GET /mock-exams/qr-public-key.
   *
   * AVANT : `revokedAt` existait en base, `enforceDeviceQuota` et
   * `DevicesService.deleteDevice` savaient revoquer, mais AUCUN canal ne
   * portait cette revocation jusqu'au candidat. Un appareil encadrant vole et
   * debride fabriquait donc indefiniment des QR v4 acceptes hors ligne en
   * `deviceVerified` : son certificat, valable jusqu'en 2999, restait
   * parfaitement valide aux yeux d'un verificateur qui n'avait aucun moyen
   * d'apprendre la revocation. Voler un poste d'auto-ecole donnait un pouvoir
   * de convocation permanent.
   * APRES : le candidat teste `sha256(cert.did)` contre cette liste et refuse
   * le QR.
   *
   * ⛔ PORTEE REELLE, a laisser ecrite : le dispositif ne protege que les
   * candidats qui se sont SYNCHRONISES DEPUIS la revocation, et eux seuls. Un
   * appareil candidat qui ne se synchronise jamais reste expose. C'est la
   * limite inherente au hors ligne, pas un defaut de cette implementation.
   *
   * Deux garde-fous :
   *   - JAMAIS les identifiants d'appareil en clair, uniquement leurs
   *     empreintes SHA-256 : la route est publique, elle ne doit pas devenir un
   *     annuaire enumerable des appareils du parc ;
   *   - la liste est SIGNEE avec la cle serveur : sans signature, un
   *     intermediaire servirait une liste VIDE et neutraliserait entierement la
   *     revocation. `signature` vaut `null` quand la signature n'est pas
   *     configuree (dev) - un client ne doit alors accorder aucune confiance a
   *     la liste.
   *
   * Sortie DETERMINISTE (empreintes triees) : deux appels successifs sans
   * changement en base produisent la meme valeur signee, ce qui rend la
   * signature comparable et le cache legitime.
   */
  async getRevocationBundle(): Promise<{
    issuedAt: number;
    deviceIdHashes: string[];
    signature: string | null;
  }> {
    const cached = this.revocationBundleCache;
    if (cached && Date.now() < cached.expiresAt) return cached.bundle;

    const revoked = await this.db.monitorDevice.findMany({
      where: { revokedAt: { not: null } },
      select: { deviceId: true },
    });

    const deviceIdHashes = revoked
      .map((device) =>
        createHash('sha256').update(device.deviceId).digest('hex'),
      )
      .sort();

    const issuedAt = Math.floor(Date.now() / 1000);
    const signature = this.mockExamQrService.signValue({
      issuedAt,
      deviceIdHashes,
    });

    if (deviceIdHashes.length >= REVOCATION_BUNDLE_SIZE_ALERT_THRESHOLD) {
      void this.discordAlertService.sendAlertThrottled(
        'mock-exam-revocation-bundle-size',
        {
          severity: 'warning',
          title: 'Liste de révocation des appareils trop volumineuse',
          description: `La liste servie par la route publique GET /mock-exams/qr-public-key contient ${deviceIdHashes.length} empreintes. Au-delà de ce seuil, la réponse devient lourde pour un réseau lent : prévoir une pagination ou une route authentifiée.`,
          context: { empreintes: deviceIdHashes.length },
          timestamp: new Date(),
        },
        60 * 60 * 1000,
      );
    }

    const bundle = { issuedAt, deviceIdHashes, signature };
    this.revocationBundleCache = {
      bundle,
      expiresAt: Date.now() + REVOCATION_BUNDLE_CACHE_MS,
    };
    return bundle;
  }

  // ---------------------------------------------------------------------------
  // Prive
  // ---------------------------------------------------------------------------

  /**
   * Coeur partage entre `enrollDevice` (cle generee sur l'appareil mobile) et
   * `issueWebToken` (cle generee par le serveur) : construction du certificat,
   * signature, quota/rotation, persistance. Les deux n'y different que par la
   * PROVENANCE de `publicKeyPem` et par `platform`.
   */
  private async issueCertificate(
    monitorId: string,
    schoolId: string | null,
    deviceId: string,
    publicKeyPem: string,
    platform: MonitorDevicePlatform,
  ): Promise<DeviceCertificateDto> {
    if (!this.mockExamQrService.isSigningConfigured()) {
      throw new ServiceUnavailableException(
        ERRORS.DEVICE_CERT_SIGNING_UNAVAILABLE,
      );
    }

    const dpk = this.extractRawEd25519PublicKey(publicKeyPem);

    const nowSeconds = Math.floor(Date.now() / 1000);
    const notBefore = new Date(nowSeconds * 1000);
    const notAfter = new Date(PERMANENT_NOT_AFTER_SECONDS * 1000);

    // C-L15 : le `kid` entre dans la portion SIGNEE du certificat, avant
    // l'appel a signValue. Un intermediaire ne peut donc pas le reecrire pour
    // faire resoudre une autre cle publique au verificateur hors ligne.
    const kid = this.mockExamQrService.activeKeyId();

    const certPayload: MonitorDeviceCertPayload = {
      did: deviceId,
      dpk,
      uid: monitorId,
      ...(schoolId ? { sid: schoolId } : {}),
      ...(kid ? { kid } : {}),
      nb: nowSeconds,
      na: PERMANENT_NOT_AFTER_SECONDS,
      cv: CERT_VERSION,
    };

    // Defense en profondeur : isSigningConfigured() vient d'etre verifie, mais
    // on ne persiste jamais un certificat sans signature valide.
    const certSignature = this.mockExamQrService.signValue(certPayload);
    if (!certSignature) {
      throw new ServiceUnavailableException(
        ERRORS.DEVICE_CERT_SIGNING_UNAVAILABLE,
      );
    }

    await this.enforceDeviceQuota(monitorId, deviceId);

    await this.db.monitorDevice.upsert({
      where: {
        userId_deviceId: { userId: monitorId, deviceId },
      },
      create: {
        userId: monitorId,
        deviceId,
        platform,
        publicKey: publicKeyPem,
        certPayload: certPayload as unknown as Prisma.InputJsonValue,
        certSignature,
        notBefore,
        notAfter,
        lastSeenAt: new Date(),
      },
      update: {
        platform,
        publicKey: publicKeyPem,
        certPayload: certPayload as unknown as Prisma.InputJsonValue,
        certSignature,
        notBefore,
        notAfter,
        revokedAt: null, // le ré-enrolement/ré-emission reactive implicitement un appareil revoque
        lastSeenAt: new Date(),
      },
    });

    this.logger.log(
      `[MockExamDevice] Certificat émis - moniteur=${monitorId} appareil=${deviceId} plateforme=${platform}`,
    );

    void this.checkEnrollmentSpike(monitorId);

    return {
      did: certPayload.did,
      dpk: certPayload.dpk,
      uid: certPayload.uid,
      sid: certPayload.sid ?? null,
      // Recopie a l'identique : le client embarque ce champ tel quel dans ses
      // QR v4, il ne doit jamais le reconstruire.
      ...(certPayload.kid ? { kid: certPayload.kid } : {}),
      nb: certPayload.nb,
      na: certPayload.na,
      cv: certPayload.cv,
      certSignature,
      notAfter: notAfter.toISOString(),
    };
  }

  /**
   * Extrait la cle publique Ed25519 BRUTE (32 octets, base64url) depuis un PEM
   * SPKI. Utilise l'export JWK de Node (`format: 'jwk'`) plutot qu'un parsing
   * DER manuel : pour une cle OKP/Ed25519, `jwk.x` EST directement les 32
   * octets bruts en base64url - portable, sans hypothese fragile sur le
   * prefixe DER SPKI. Rejette toute cle non-Ed25519.
   */
  private extractRawEd25519PublicKey(publicKeyPem: string): string {
    let keyObject;
    try {
      keyObject = createPublicKey({ key: publicKeyPem, format: 'pem' });
    } catch {
      throw new BadRequestException(ERRORS.DEVICE_PUBLIC_KEY_INVALID);
    }

    if (keyObject.asymmetricKeyType !== 'ed25519') {
      throw new BadRequestException(ERRORS.DEVICE_PUBLIC_KEY_INVALID);
    }

    const jwk = keyObject.export({ format: 'jwk' }) as {
      kty?: string;
      crv?: string;
      x?: string;
    };

    if (jwk.kty !== 'OKP' || jwk.crv !== 'Ed25519' || !jwk.x) {
      throw new BadRequestException(ERRORS.DEVICE_PUBLIC_KEY_INVALID);
    }

    return jwk.x;
  }

  /**
   * Fait de la place si le moniteur a deja atteint le quota d'appareils actifs :
   * revoque (soft) le(s) plus ancien(s) actif(s) - FIFO par createdAt - pour
   * ramener le compte a MAX_ACTIVE_DEVICES_PER_MONITOR - 1 avant l'upsert. Le
   * ré-enrolement d'un appareil deja connu (meme deviceId) est un upsert, pas
   * une nouvelle entree : il ne consomme jamais le quota.
   */
  private async enforceDeviceQuota(
    monitorId: string,
    deviceId: string,
  ): Promise<void> {
    const existing = await this.db.monitorDevice.findUnique({
      where: { userId_deviceId: { userId: monitorId, deviceId } },
      select: { id: true },
    });
    if (existing) return; // rotation d'un appareil deja enrole - pas une nouvelle entree

    const activeDevices = await this.db.monitorDevice.findMany({
      where: { userId: monitorId, revokedAt: null },
      orderBy: { createdAt: 'asc' },
      select: { id: true },
    });

    if (activeDevices.length < MAX_ACTIVE_DEVICES_PER_MONITOR) return;

    const toRevoke = activeDevices.slice(
      0,
      activeDevices.length - MAX_ACTIVE_DEVICES_PER_MONITOR + 1,
    );

    await this.db.monitorDevice.updateMany({
      where: { id: { in: toRevoke.map((d) => d.id) } },
      data: { revokedAt: new Date() },
    });

    this.logger.warn(
      `[MockExamDevice] Quota d'appareils atteint (moniteur=${monitorId}) - ${toRevoke.length} appareil(s) révoque(s) (FIFO).`,
    );

    void this.discordAlertService.sendAlertThrottled(
      `mock-exam-device-quota-${monitorId}`,
      {
        severity: 'security',
        title: "Quota d'appareils moniteur atteint",
        description: `Le moniteur a atteint le quota de ${MAX_ACTIVE_DEVICES_PER_MONITOR} appareils actifs - rotation FIFO appliquée (aucune erreur HTTP renvoyée, révocation silencieuse du plus ancien appareil).`,
        context: {
          moniteurId: monitorId,
          appareilsRevoques: toRevoke.length,
        },
        timestamp: new Date(),
      },
      10 * 60 * 1000,
    );
  }

  /**
   * Alerte best-effort (throttlee) sur un pic anormal d'enrolements/ré-enrolements
   * d'appareils pour un meme moniteur sur une fenetre d'une heure - signal
   * potentiel d'abus. Ne bloque jamais l'enrolement en cours (fire-and-forget).
   */
  private async checkEnrollmentSpike(monitorId: string): Promise<void> {
    try {
      const since = new Date(Date.now() - ENROLLMENT_SPIKE_WINDOW_MS);
      const count = await this.db.monitorDevice.count({
        where: { userId: monitorId, updatedAt: { gte: since } },
      });
      if (count < ENROLLMENT_SPIKE_THRESHOLD) return;

      await this.discordAlertService.sendAlertThrottled(
        `mock-exam-device-spike-${monitorId}`,
        {
          severity: 'security',
          title: "Pic d'enrôlements d'appareils moniteur",
          description: `${count} enrôlements/ré-enrôlements en moins d'une heure pour un même moniteur.`,
          context: { moniteurId: monitorId, count },
          timestamp: new Date(),
        },
        30 * 60 * 1000,
      );
    } catch (err: unknown) {
      this.logger.warn(
        `[MockExamDevice] checkEnrollmentSpike echoue (best-effort). Cause : ${err instanceof Error ? err.message : String(err)}`,
      );
    }
  }
}
