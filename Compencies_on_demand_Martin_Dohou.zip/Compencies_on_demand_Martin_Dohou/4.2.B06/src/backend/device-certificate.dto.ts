// =============================================================================
// DeviceCertificateDto - Certificat d'appareil moniteur (mini-PKI, ADR-013)
// =============================================================================
//
// Champs `did`/`dpk`/`uid`/`sid`/`kid`/`nb`/`na`/`cv` = EXACTEMENT le certificat
// signe (`cert`), a plat pour simplifier la consommation cote mobile. La
// signature (`certSignature`) porte sur la serialisation JSON canonique (cles
// triees recursivement, cf. `canonicalJsonStringify` dans MockExamQrService) de
// l'objet `{ did, dpk, uid, sid?, kid?, nb, na, cv }` UNIQUEMENT - ne jamais
// inclure `certSignature` ni `notAfter` dans la valeur signee/verifiee. `sid`
// et `kid` sont omis de la serialisation si absents (jamais serialises a
// `null`).
// =============================================================================

import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class DeviceCertificateDto {
  @ApiProperty({
    description:
      "Identifiant de l'appareil (reprend EnrollDeviceDto.deviceId).",
    example: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
  })
  did!: string;

  @ApiProperty({
    description:
      "Clé publique brute Ed25519 de l'appareil (32 octets), encodée en base64url (sans padding).",
    example: 'x-CZQ7XYv9mFL0iL9NCLIOWwPs7n4BbBiXh13QJFStI',
  })
  dpk!: string;

  @ApiProperty({
    description: "Identifiant du moniteur propriétaire de l'appareil.",
    example: '01973b1e-7c3a-7f2e-9b1a-2f6b8e4d5c3a',
  })
  uid!: string;

  @ApiPropertyOptional({
    type: String,
    nullable: true,
    description:
      "Identifiant de l'école du moniteur au moment de l'enrôlement (informatif uniquement), ou `null` si contexte indépendant.",
    example: null,
  })
  sid!: string | null;

  @ApiPropertyOptional({
    type: String,
    example: 'a1b2c3d4e5f60718',
    description:
      "Identifiant de la clé SERVEUR qui a signé ce certificat. Absent (jamais null) quand la signature n'est pas configurée. Le client DOIT le recopier tel quel dans le certificat qu'il embarque dans ses QR v4, sans jamais le reconstruire : c'est lui qui permettra à un candidat de résoudre la bonne clé publique après une rotation de la clé serveur. AVANT ce champ, une rotation rendait invérifiables tous les certificats déjà émis - valables jusqu'en 2999 - ce qui interdisait de fait la rotation et laissait une clé compromise en service.",
  })
  kid?: string;

  @ApiProperty({
    description: 'Début de validité du certificat (epoch secondes).',
    example: 1751600000,
  })
  nb!: number;

  @ApiProperty({
    description:
      "Fin de validité du certificat (epoch secondes). Depuis ADR-051 SS11 (2026-09-02), les certificats émis portent une date très lointaine (2999) plutôt qu'une fenêtre courte : la REVOCATION (suppression de l'appareil depuis /devices) remplace l'expiration comme mécanisme de sécurité. Un certificat émis avant ce changement peut encore porter une fenêtre de 14 jours - il redevient permanent au prochain (ré)enrolement/(ré)émission en ligne.",
    example: 32503679999,
  })
  na!: number;

  @ApiProperty({
    description:
      'Version du schema de certificat (fige à 1). Un futur changement de forme incrémentera cette valeur.',
    example: 1,
  })
  cv!: number;

  @ApiProperty({
    description:
      'Signature détachée Ed25519 (base64url, sans padding) du certificat, produite par la clé serveur MOCK_EXAM_QR_SIGNING_PRIVATE_KEY (même clé et même mécanisme que la signature des QR examens blancs v3).',
    example: 'dGhpcyBpcyBhIGZha2Ugc2lnbmF0dXJlIGV4YW1wbGU',
  })
  certSignature!: string;

  @ApiProperty({
    type: String,
    description:
      'Fin de validité du certificat, au format ISO 8601 (redondant avec `na`, pour affichage/planification du ré-enrôlement côté mobile).',
    example: '2026-07-18T10:00:00.000Z',
  })
  notAfter!: string;
}
