// =============================================================================
// Golden vectors QR - Interoperabilite cryptographique cross-stack (backend)
// =============================================================================
//
// Verrouille l'interoperabilite crypto backend <-> mobile (finding MEDIUM #2 de
// la revue croisee ADR-013) via un fichier de vecteurs DETERMINISTES partage,
// OCTET POUR OCTET identique, avec le repo mobile
// (`pbj-mobile/test/features/exams/data/qr_golden_vectors.json`).
//
// Ce spec asserte que le port BACKEND (la vraie `canonicalJsonStringify` de
// production + Ed25519 via `crypto`) reproduit EXACTEMENT les valeurs figees.
// Le test mobile jumeau (`qr_golden_vectors_test.dart`) asserte la meme chose
// pour le port Dart. Si les deux passent, les deux ports produisent le meme
// canonical + la meme signature pour la meme entree : preuve d'interop.
//
// Toute modification de la serialisation canonique OU de l'encodage Ed25519
// d'un cote casse la CI de ce cote (le vecteur ne bouge pas).
//
// NB : les graines du fichier sont des graines de TEST figees (jamais des cles
// de production).

import { readFileSync } from 'fs';
import { join } from 'path';
import { createPrivateKey, createPublicKey, type KeyObject } from 'crypto';
import { Test, TestingModule } from '@nestjs/testing';
import {
  MockExamQrService,
  canonicalJsonStringify,
} from './mock-exam-qr.service';
import { AppConfigService } from '../../../../config/config.service';
import { DiscordAlertService } from '../../../../common/alerts/discord-alert.service';
import { ReadinessRegistry } from '../../../../common/alerts/readiness.registry';

// ---------------------------------------------------------------------------
// Chargement du fichier de vecteurs figes (partage byte-identique avec mobile)
// ---------------------------------------------------------------------------

interface GoldenVectors {
  algorithm: string;
  canonical: { input: unknown; expected: string };
  ed25519: {
    serverSeedHex: string;
    publicKeyBase64Url: string;
    publicKeySpkiPem: string;
    messageObject: Record<string, unknown>;
    canonicalMessage: string;
    signature: string;
  };
  certChainV4: {
    serverSeedHex: string;
    serverPublicKeySpkiPem: string;
    deviceSeedHex: string;
    devicePublicKeyBase64Url: string;
    unsignedCert: Record<string, unknown>;
    certSignature: string;
    unsignedPayloadV4: Record<string, unknown>;
    deviceSignature: string;
    signedPayloadV4Raw: string;
  };
  payloadV5: {
    serverSeedHex: string;
    serverPublicKeySpkiPem: string;
    unsignedPayloadV5: Record<string, unknown>;
    canonicalMessageV5: string;
    signature: string;
    signedPayloadV5Raw: string;
  };
  payloadV6: {
    serverSeedHex: string;
    serverPublicKeySpkiPem: string;
    unsignedPayloadV6: Record<string, unknown>;
    canonicalMessageV6: string;
    signature: string;
    signedPayloadV6Raw: string;
  };
  certChainV4Kid: {
    serverSeedHex: string;
    serverPublicKeySpkiPem: string;
    deviceSeedHex: string;
    devicePublicKeyBase64Url: string;
    unsignedCert: Record<string, unknown>;
    certSignature: string;
    unsignedPayloadV4: Record<string, unknown>;
    deviceSignature: string;
    signedPayloadV4Raw: string;
  };
}

const vectors: GoldenVectors = JSON.parse(
  readFileSync(
    join(__dirname, '..', '..', '__fixtures__', 'qr-golden-vectors.json'),
    'utf8',
  ),
) as GoldenVectors;

// ---------------------------------------------------------------------------
// Helpers - reconstruction d'une cle privee Ed25519 depuis une graine de test
// ---------------------------------------------------------------------------

// Prefixe DER fixe d'une cle privee Ed25519 en PKCS8 (RFC 8410) + 32 octets de
// graine brute = DER PKCS8 valide.
const ED25519_PKCS8_DER_PREFIX = Buffer.from(
  '302e020100300506032b657004220420',
  'hex',
);

function privateKeyFromSeedHex(seedHex: string): KeyObject {
  const seed = Buffer.from(seedHex, 'hex');
  const der = Buffer.concat([ED25519_PKCS8_DER_PREFIX, seed]);
  return createPrivateKey({ key: der, format: 'der', type: 'pkcs8' });
}

function pkcs8PemFromSeedHex(seedHex: string): string {
  return privateKeyFromSeedHex(seedHex)
    .export({ type: 'pkcs8', format: 'pem' })
    .toString();
}

function rawPublicKeyBase64Url(privateKey: KeyObject): string {
  const jwk = createPublicKey(privateKey).export({ format: 'jwk' });
  return jwk.x as string; // deja base64url sans padding
}

function spkiPem(privateKey: KeyObject): string {
  return createPublicKey(privateKey)
    .export({ type: 'spki', format: 'pem' })
    .toString()
    .trim();
}

// ---------------------------------------------------------------------------
// Fabrique de service chargee avec une graine de test donnee
// ---------------------------------------------------------------------------

const mockDiscordAlertService = {
  sendAlertThrottled: jest.fn().mockResolvedValue(undefined),
};
const mockReadinessRegistry = { report: jest.fn() };

async function buildServiceWithSeed(
  seedHex: string,
): Promise<{ module: TestingModule; service: MockExamQrService }> {
  const module = await Test.createTestingModule({
    providers: [
      MockExamQrService,
      {
        provide: AppConfigService,
        useValue: { mockExamQr: { privateKey: pkcs8PemFromSeedHex(seedHex) } },
      },
      { provide: DiscordAlertService, useValue: mockDiscordAlertService },
      { provide: ReadinessRegistry, useValue: mockReadinessRegistry },
    ],
  }).compile();
  const service = module.get<MockExamQrService>(MockExamQrService);
  service.onModuleInit();
  return { module, service };
}

describe('QR golden vectors (interop crypto cross-stack)', () => {
  afterEach(() => jest.clearAllMocks());

  // -------------------------------------------------------------------------
  // 1. Serialisation canonique - VRAIE fonction de production
  // -------------------------------------------------------------------------

  describe('canonicalJsonStringify (production)', () => {
    it('reproduit exactement la chaîne canonique figée (tri récursif, UTF-8, null conserve)', () => {
      expect(canonicalJsonStringify(vectors.canonical.input)).toBe(
        vectors.canonical.expected,
      );
    });

    it('canonicalMessage du vecteur Ed25519 correspond à la fonction de production', () => {
      expect(canonicalJsonStringify(vectors.ed25519.messageObject)).toBe(
        vectors.ed25519.canonicalMessage,
      );
    });
  });

  // -------------------------------------------------------------------------
  // 2. Ed25519 - derivation de cle + signature figee
  // -------------------------------------------------------------------------

  describe('Ed25519 (graine serveur figée)', () => {
    let module: TestingModule;
    let service: MockExamQrService;

    beforeEach(async () => {
      ({ module, service } = await buildServiceWithSeed(
        vectors.ed25519.serverSeedHex,
      ));
    });

    afterEach(async () => {
      if (module) await module.close();
    });

    it('derive la clé publique brute (base64url) attendue depuis la graine', () => {
      const priv = privateKeyFromSeedHex(vectors.ed25519.serverSeedHex);
      expect(rawPublicKeyBase64Url(priv)).toBe(
        vectors.ed25519.publicKeyBase64Url,
      );
    });

    it('derive le PEM SPKI attendu depuis la graine (et via le service)', () => {
      const priv = privateKeyFromSeedHex(vectors.ed25519.serverSeedHex);
      expect(spkiPem(priv)).toBe(vectors.ed25519.publicKeySpkiPem);
      expect(service.getPublicKeyInfo().publicKey?.trim()).toBe(
        vectors.ed25519.publicKeySpkiPem,
      );
    });

    it('signValue(messageObject) reproduit la signature figée (base64url sans padding)', () => {
      expect(service.signValue(vectors.ed25519.messageObject)).toBe(
        vectors.ed25519.signature,
      );
    });

    it('verify() accepte le couple (messageObject, signature figée)', () => {
      expect(
        service.verify(
          vectors.ed25519.messageObject as unknown as Parameters<
            typeof service.verify
          >[0],
          vectors.ed25519.signature,
        ),
      ).toBe(true);
    });
  });

  // -------------------------------------------------------------------------
  // 3. Chaine v4 - cert signe (serveur) + payload signe (appareil)
  // -------------------------------------------------------------------------

  describe('certChainV4 (cert serveur + payload appareil)', () => {
    let serverModule: TestingModule;
    let deviceModule: TestingModule;
    let serverService: MockExamQrService;
    let deviceService: MockExamQrService;

    beforeEach(async () => {
      ({ module: serverModule, service: serverService } =
        await buildServiceWithSeed(vectors.certChainV4.serverSeedHex));
      ({ module: deviceModule, service: deviceService } =
        await buildServiceWithSeed(vectors.certChainV4.deviceSeedHex));
    });

    afterEach(async () => {
      if (serverModule) await serverModule.close();
      if (deviceModule) await deviceModule.close();
    });

    it('la clé serveur signe le certificat -> certSignature figée', () => {
      expect(serverService.signValue(vectors.certChainV4.unsignedCert)).toBe(
        vectors.certChainV4.certSignature,
      );
    });

    it('la clé serveur vérifie sa propre signature de certificat', () => {
      expect(
        serverService.verify(
          vectors.certChainV4.unsignedCert as unknown as Parameters<
            typeof serverService.verify
          >[0],
          vectors.certChainV4.certSignature,
        ),
      ).toBe(true);
    });

    it('la clé appareil signe le payload v4 (cert inclus) -> deviceSignature figée', () => {
      expect(
        deviceService.signValue(vectors.certChainV4.unsignedPayloadV4),
      ).toBe(vectors.certChainV4.deviceSignature);
    });

    it('la clé appareil vérifie sa propre signature de payload', () => {
      expect(
        deviceService.verify(
          vectors.certChainV4.unsignedPayloadV4 as unknown as Parameters<
            typeof deviceService.verify
          >[0],
          vectors.certChainV4.deviceSignature,
        ),
      ).toBe(true);
    });

    it('devicePublicKeyBase64Url du cert correspond bien à la graine appareil', () => {
      const devicePriv = privateKeyFromSeedHex(
        vectors.certChainV4.deviceSeedHex,
      );
      expect(rawPublicKeyBase64Url(devicePriv)).toBe(
        vectors.certChainV4.devicePublicKeyBase64Url,
      );
      expect(vectors.certChainV4.unsignedCert.dpk).toBe(
        vectors.certChainV4.devicePublicKeyBase64Url,
      );
    });

    it('signedPayloadV4Raw contient exactement la signature appareil figée', () => {
      const parsed = JSON.parse(vectors.certChainV4.signedPayloadV4Raw) as {
        sig: string;
        cert: { certSignature: string };
      };
      expect(parsed.sig).toBe(vectors.certChainV4.deviceSignature);
      expect(parsed.cert.certSignature).toBe(vectors.certChainV4.certSignature);
    });
  });
  // -------------------------------------------------------------------------
  // 4. Payload v5 - signe par la cle SERVEUR, objet imbrique `p` + `kid`
  // -------------------------------------------------------------------------

  describe('payloadV5 (reference d epreuve imbriquee + kid)', () => {
    let module: TestingModule;
    let service: MockExamQrService;

    beforeEach(async () => {
      ({ module, service } = await buildServiceWithSeed(
        vectors.payloadV5.serverSeedHex,
      ));
    });

    afterEach(async () => {
      if (module) await module.close();
    });

    it('canonicalJsonStringify(unsignedPayloadV5) reproduit canonicalMessageV5 octet pour octet', () => {
      expect(canonicalJsonStringify(vectors.payloadV5.unsignedPayloadV5)).toBe(
        vectors.payloadV5.canonicalMessageV5,
      );
    });

    it('verify() accepte le couple (unsignedPayloadV5, signature figee)', () => {
      expect(
        service.verify(
          vectors.payloadV5.unsignedPayloadV5 as unknown as Parameters<
            typeof service.verify
          >[0],
          vectors.payloadV5.signature,
        ),
      ).toBe(true);
    });

    it('signValue(unsignedPayloadV5) reproduit la signature figee', () => {
      expect(service.signValue(vectors.payloadV5.unsignedPayloadV5)).toBe(
        vectors.payloadV5.signature,
      );
    });

    it('signedPayloadV5Raw porte exactement la signature figee', () => {
      const parsed = JSON.parse(vectors.payloadV5.signedPayloadV5Raw) as {
        sig: string;
      };
      expect(parsed.sig).toBe(vectors.payloadV5.signature);
    });
  });

  // -------------------------------------------------------------------------
  // 5. Payload v6 - tirage RETENU avant le lancement, donc AUCUNE cle `q`
  // -------------------------------------------------------------------------

  describe('payloadV6 (tirage retenu : aucun numero de question)', () => {
    let module: TestingModule;
    let service: MockExamQrService;

    beforeEach(async () => {
      ({ module, service } = await buildServiceWithSeed(
        vectors.payloadV6.serverSeedHex,
      ));
    });

    afterEach(async () => {
      if (module) await module.close();
    });

    it('le vecteur ne porte AUCUNE cle `q` - ni dans l objet, ni dans le canonique, ni dans le brut signe', () => {
      // Assertion explicite : sans elle, le vecteur pourrait deriver
      // silencieusement vers un v6 qui reintroduit le tirage, et la retenue
      // ne serait plus verrouillee par rien.
      expect(
        Object.prototype.hasOwnProperty.call(
          vectors.payloadV6.unsignedPayloadV6,
          'q',
        ),
      ).toBe(false);
      expect(vectors.payloadV6.canonicalMessageV6).not.toContain('"q"');
      expect(vectors.payloadV6.signedPayloadV6Raw).not.toContain('"q"');
    });

    it('canonicalJsonStringify(unsignedPayloadV6) reproduit canonicalMessageV6 octet pour octet', () => {
      expect(canonicalJsonStringify(vectors.payloadV6.unsignedPayloadV6)).toBe(
        vectors.payloadV6.canonicalMessageV6,
      );
    });

    it('verify() accepte le couple (unsignedPayloadV6, signature figee)', () => {
      expect(
        service.verify(
          vectors.payloadV6.unsignedPayloadV6 as unknown as Parameters<
            typeof service.verify
          >[0],
          vectors.payloadV6.signature,
        ),
      ).toBe(true);
    });

    it('signValue(unsignedPayloadV6) reproduit la signature figee', () => {
      expect(service.signValue(vectors.payloadV6.unsignedPayloadV6)).toBe(
        vectors.payloadV6.signature,
      );
    });
  });

  // -------------------------------------------------------------------------
  // 6. Chaine v4 avec `kid` dans le certificat
  // -------------------------------------------------------------------------

  describe('certChainV4Kid (certificat portant un identifiant de cle)', () => {
    let serverModule: TestingModule;
    let deviceModule: TestingModule;
    let serverService: MockExamQrService;
    let deviceService: MockExamQrService;

    beforeEach(async () => {
      ({ module: serverModule, service: serverService } =
        await buildServiceWithSeed(vectors.certChainV4Kid.serverSeedHex));
      ({ module: deviceModule, service: deviceService } =
        await buildServiceWithSeed(vectors.certChainV4Kid.deviceSeedHex));
    });

    afterEach(async () => {
      if (serverModule) await serverModule.close();
      if (deviceModule) await deviceModule.close();
    });

    it('le certificat porte bien un `kid`, et il est distinct du certificat sans kid', () => {
      expect(typeof vectors.certChainV4Kid.unsignedCert.kid).toBe('string');
      // Le champ neuf change la chaine canonique, donc la signature : les deux
      // vecteurs doivent diverger, sinon le `kid` ne serait pas couvert par la
      // signature du serveur.
      expect(vectors.certChainV4Kid.certSignature).not.toBe(
        vectors.certChainV4.certSignature,
      );
    });

    it('le certificat portant `kid` se verifie toujours avec la cle serveur', () => {
      expect(
        serverService.verify(
          vectors.certChainV4Kid.unsignedCert as unknown as Parameters<
            typeof serverService.verify
          >[0],
          vectors.certChainV4Kid.certSignature,
        ),
      ).toBe(true);
      expect(serverService.signValue(vectors.certChainV4Kid.unsignedCert)).toBe(
        vectors.certChainV4Kid.certSignature,
      );
    });

    it('la signature d appareil du payload reste valide', () => {
      expect(
        deviceService.verify(
          vectors.certChainV4Kid.unsignedPayloadV4 as unknown as Parameters<
            typeof deviceService.verify
          >[0],
          vectors.certChainV4Kid.deviceSignature,
        ),
      ).toBe(true);
      expect(
        deviceService.signValue(vectors.certChainV4Kid.unsignedPayloadV4),
      ).toBe(vectors.certChainV4Kid.deviceSignature);
    });

    it('signedPayloadV4Raw porte le cert avec `kid` et la signature appareil figee', () => {
      const parsed = JSON.parse(vectors.certChainV4Kid.signedPayloadV4Raw) as {
        sig: string;
        cert: { certSignature: string; kid?: string };
      };
      expect(parsed.sig).toBe(vectors.certChainV4Kid.deviceSignature);
      expect(parsed.cert.certSignature).toBe(
        vectors.certChainV4Kid.certSignature,
      );
      expect(parsed.cert.kid).toBe(vectors.certChainV4Kid.unsignedCert.kid);
    });
  });
});
