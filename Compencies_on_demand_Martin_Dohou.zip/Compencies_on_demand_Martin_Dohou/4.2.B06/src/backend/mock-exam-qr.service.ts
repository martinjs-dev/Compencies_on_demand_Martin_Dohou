// =============================================================================
// MockExamQrService - Construction et signature du payload QR compact (v3/v5)
// =============================================================================
//
// Construit le payload QR compact des examens blancs (~350 octets, cf. plan
// B3 "examens blancs") et le signe en Ed25519 (signature detachee). La cle
// privee est chargee depuis MOCK_EXAM_QR_SIGNING_PRIVATE_KEY (PEM PKCS8, cf.
// config/pem-key.util.ts pour la normalisation). La cle publique associee est
// DERIVEE automatiquement de la cle privee au demarrage - propriete
// mathematique d'Ed25519, la cle publique est toujours calculable depuis la
// graine privee - et exposee via GET /mock-exams/qr-public-key pour que
// l'application mobile puisse verifier une signature entierement hors-ligne.
//
// Degradation best-effort (cf. decision produit) : si la cle n'est pas
// configuree (dev), le service logue un avertissement au demarrage et
// exportSignedPayload() renvoie le payload SANS le champ `sig` plutot que de
// lever une exception - l'export QR reste utilisable sans cle provisionnee.
// Si la cle EST presente mais illisible (PEM corrompu), c'est traite comme un
// incident production (log error + alerte Discord throttled), toujours sans
// jamais faire planter l'export.
//
// -----------------------------------------------------------------------------
// v5 - reference d'epreuve (`p`), analyse de compatibilite AVANT toute chose
// -----------------------------------------------------------------------------
//
// Besoin produit : permettre au payload de designer une epreuve enregistree
// par son numero et sa portee (« lance l'epreuve 12 »), en plus des deux
// formes existantes (`q` = numeros exacts, `c` = criteres de tirage local),
// qui ne disparaissent JAMAIS.
//
// Le format en circulation (cote mobile, `mock_exam_qr_payload.dart`) whitelist
// deja EXPLICITEMENT les versions qu'il sait lire :
//   final version = _asInt(json['v']);
//   if (version == 3) return _tryParseV3(json);
//   if (version == 4) return _tryParseV4(json);
//   return null;   // <- toute AUTRE version, y compris 5, sort ICI
// Un `null` renvoye par `tryParseMockExamQrPayload` fait retomber l'appelant
// (`quiz_list_page.dart::_scanAndJoinMockExam`) sur l'interpretation "code de
// session brut" : le contenu scanne (un JSON `{...}`) ne matche jamais le
// format `EB-XXXX`, et l'utilisateur voit un message d'erreur clair ("QR ou
// code non reconnu"). AUCUN plantage, AUCUNE composition silencieuse avec un
// contenu partiellement compris - c'est EXACTEMENT le mecanisme deja eprouve
// qui separe v3 (signature serveur) de v4 (signature appareil, ADR-013) : un
// ancien parc qui ne connaissait que v3 rejette deja v4 proprement de la
// meme facon, en production, depuis ADR-013.
//
// D'ou la decision : la reference d'epreuve EST un nouveau numero de version
// (5), et non un champ ajoute silencieusement sur un payload `v:3` existant.
// Deux raisons, l'une suffirait mais les deux comptent :
//   1. Un champ ajoute sans bump de version serait avale sans broncher par un
//      ancien client (`Map` Dart, cles inconnues simplement ignorees) - cette
//      "acceptation silencieuse d'un contenu qu'il ne comprend pas" est
//      exactement ce qui est proscrit, meme si elle serait ici inoffensive
//      (voir raison 2). Le bump rend le contrat explicite et verifiable
//      independamment de la tolerance incidente de chaque version cliente.
//   2. `q` (numeros exacts) reste TOUJOURS present et TOUJOURS la source de
//      verite quand `p` est aussi present - jamais remplace. C'est la MEME
//      doctrine que la reconciliation hors-ligne d'ADR-051 SS9 ("les numeros
//      font foi") : une epreuve peut etre recomposee entre l'emission du QR
//      et sa lecture, et faire dependre la composition JOUEE d'une relecture
//      locale de l'epreuve reintroduirait exactement le piege que SS9 ferme
//      deja a la creation de la session. `p` est donc un COMPLEMENT (label
//      humain, futur raccourci de resolution locale une fois le cache
//      d'epreuves mobile eprouve) et non un remplacement - la securite ne
//      repose PAS sur le bump de version pour ce point precis, elle est
//      garantie par construction (v5 = v3 + `p`, jamais v3 - `q` + `p`).
//
// Portee : une epreuve n'est identifiee de facon UNIQUE que par son numero ET
// sa portee (l'epreuve n°12 de la plateforme et l'epreuve n°12 d'une ecole
// sont deux objets distincts, cf. les trois index uniques PARTIELS poses sur
// `quizzes` par la migration `20260902150000_exam_papers`). `p.sc` porte la
// portee, `p.sid`/`p.uid` desambiguisent les portees SCHOOL/MONITOR - voir
// `resolvePaperRefField` pour la validation stricte (degrade proprement en
// v3, jamais de payload avec une portee incomplete/ambigue).
//
// Volet mobile HORS PERIMETRE ICI (lot separe) : ce fichier ne fait que
// PRODUIRE le payload v5 signe. La lecture (`_tryParseV5`), la resolution
// locale de l'epreuve depuis le cache, et l'ecran de saisie manuelle d'un
// numero restent a construire cote `pbj-mobile`, sur le meme squelette que
// `_tryParseV3`/`_tryParseV4` (`mock_exam_qr_payload.dart`).
//
// -----------------------------------------------------------------------------
// Lot K - durcissements, avec pour chacun l'ecart d'attaque referme
// -----------------------------------------------------------------------------
//
// 1. IDENTIFIANT DE CLE `kid` (C-L15).
//    AVANT : la cle serveur n'etait designee nulle part. Un exploitant qui
//    devait faire tourner la cle privee (fuite suspectee, changement
//    d'hebergeur) n'avait qu'une seule manoeuvre possible : remplacer la cle et
//    rendre INVERIFIABLES, d'un seul coup, tous les QR deja imprimes et tous
//    les certificats d'appareil deja emis (valables jusqu'en 2999). En
//    pratique, la rotation etait donc impossible, et une cle compromise restait
//    en service. Un attaquant en possession de cette cle signait indefiniment.
//    APRES : le payload et le certificat portent le `kid` de la cle qui les a
//    signes, le serveur accepte en VERIFICATION la cle active et les cles
//    retirees (`MOCK_EXAM_QR_RETIRED_PUBLIC_KEYS`). La cle compromise peut
//    donc etre retiree de la signature sans invalider le parc, et un attaquant
//    qui la detient ne peut plus produire d'artefact NEUF accepte des que
//    l'exploitant l'a sortie de la liste des cles de verification.
//    Le `kid` est DANS la portion signee : il ne peut pas etre substitue pour
//    faire pointer un verificateur vers une autre cle.
//
// 2. BORNAGE DE `exp` SUR L'ECHEANCE DE SEANCE (C-K8).
//    AVANT : tout QR valait 24 heures. Un QR photographie au fond de la salle,
//    ou repris sur une capture d'ecran partagee, restait utilisable une journee
//    entiere pour rejoindre une seance de quarante-cinq minutes - y compris
//    longtemps apres sa fin, depuis un appareil hors ligne.
//    APRES : `exp` est ramene a l'echeance reelle de la seance plus une heure
//    de grace. La fenetre d'exploitation d'un QR capte passe de 24 heures a la
//    duree de la seance.
//
// 3. RATTACHEMENT VERIFIABLE HORS LIGNE `mid`/`sid`/`org` (C-K5).
//    AVANT : un QR ne disait pas QUI organisait. Un tiers pouvait projeter un
//    QR quelconque et un candidat composait quarante-cinq minutes avant que le
//    serveur ne rejette la participation a la synchronisation
//    (MOCK_EXAM_NOT_LINKED). Le cout de la nuisance etait entierement paye par
//    le candidat.
//    APRES : le client compare, hors ligne et avant de composer, l'organisateur
//    annonce a ses propres rattachements. La nuisance est detectee au scan.
//    ⛔ Ces champs ne remplacent JAMAIS le controle serveur
//    `MOCK_EXAM_NOT_LINKED` de `MockExamService.joinSession`, qui reste seul a
//    faire autorite : ils sont dans un artefact que le porteur choisit de
//    presenter, donc ils informent, ils n'autorisent pas.
//
// 4. RETENUE DU TIRAGE AVANT LE LANCEMENT, payload v6 (C-K2).
//    AVANT : `q` (les numeros exacts du tirage) etait publie des la creation de
//    la session. Un QR affiche au tableau la veille livrait la composition de
//    l'epreuve a qui le photographiait, avec tout le temps de preparer les
//    reponses.
//    APRES (quand `withholdDrawBeforeLaunch` est actif) : tant que la session
//    n'est pas ACTIVE, le payload est une v6 SANS `q`, le client retrouvant le
//    tirage LOCALEMENT depuis son stock d'epreuves (ADR-050). Le tirage ne
//    quitte le serveur qu'au top depart.
//    ⛔ LIMITE ASSUMEE : la retenue n'est possible que pour une session adossee
//    a une EPREUVE ENREGISTREE, seul cas ou le client sait reconstituer le
//    tirage sans reseau. Pour une composition libre, `q` reste publie et un QR
//    projete avant le depart continue de reveler les numeros : risque residuel
//    CONNU, pas un oubli.
//
// 5. SIGNATURE OBLIGATOIRE EN PRODUCTION (C-K1).
//    AVANT : sans cle configuree, la production exportait des QR NON SIGNES,
//    silencieusement. N'importe qui pouvait alors fabriquer un QR de toutes
//    pieces, la verification hors ligne n'ayant plus rien a verifier.
//    APRES : `requireSignature()` refuse l'export en production. La degradation
//    reste entiere en developpement, ou elle est le comportement voulu.
// =============================================================================

import {
  Injectable,
  Logger,
  OnModuleInit,
  ServiceUnavailableException,
} from '@nestjs/common';
import {
  createHash,
  createPrivateKey,
  createPublicKey,
  sign as cryptoSign,
  verify as cryptoVerify,
  type KeyObject,
} from 'crypto';
import { AppConfigService } from '../../../../config/config.service';
import { ERRORS } from '../../../../common/constants/app.constants';
import { diagnosePemPrivateKey } from '../../../../config/pem-key.util';
import { DiscordAlertService } from '../../../../common/alerts/discord-alert.service';
import { ReadinessRegistry } from '../../../../common/alerts/readiness.registry';
import { DURATION_FALLBACK_SECONDS } from '../../../../common/exam-audio/exam-audio-duration.service';
import { DistributionMode } from '../../../../../../../prisma/generated/enums';
import type { PermitCategoryCode } from '../../../../../../../prisma/generated/enums';
import type {
  MockExamQrCriteriaDto,
  MockExamQrExportDto,
  MockExamQrPaperRefDto,
} from '../dto/mock-exam-response.dto';
import type {
  MockExamQrPublicKeyDto,
  MockExamQrPublicKeyEntryDto,
} from '../dto/mock-exam-qr-public-key.dto';
import {
  EXAM_PAPER_SCOPES,
  EXAM_PAPER_SCOPE_SCHOOL,
  EXAM_PAPER_SCOPE_MONITOR,
  type ExamPaperScope,
} from '../../../quiz/app/dto/exam-paper.dto';

// ---------------------------------------------------------------------------
// Constantes
// ---------------------------------------------------------------------------

/** Version historique du payload QR (compact + signe), forme par defaut. */
const QR_PAYLOAD_VERSION = 3;

/**
 * Version du payload QR enrichie d'une reference d'epreuve (`p`). Un
 * verificateur qui ne connait que la v3 rejette une v5 PROPREMENT (repli
 * "code de session brut"), sans jamais tenter de la parser partiellement -
 * c'est le meme mecanisme de discrimination qui separe deja v3 (signature
 * serveur) de v4 (signature appareil, ADR-013). Voir buildPayload() pour
 * l'analyse complete de compatibilite.
 */
const QR_PAYLOAD_VERSION_PAPER_REF = 5;

/**
 * Version du payload QR dont le tirage est RETENU (`q` absent) tant que la
 * session n'est pas lancee (C-K2). Meme mecanisme de discrimination que la v5 :
 * un verificateur qui ne connait pas la v6 la rejette PROPREMENT et fait
 * retomber son porteur sur la saisie du code de session, exactement comme un
 * parc v3 rejette deja une v4 en production depuis ADR-013. Aucune lecture
 * partielle, aucune composition silencieuse sur un contenu mal compris.
 *
 * ⛔⛔ NE PLUS ACTIVER `withholdDrawBeforeLaunch` DU TOUT (2026-09-06).
 *
 * La mise en garde d'origine disait « pas tant que le parc mobile ne sait pas
 * lire la v6 ». Elle est depassee, et dans le mauvais sens : la v6 remplace les
 * numeros par une REFERENCE d'epreuve, que le client resolvait contre son stock
 * local d'epreuves. Ce stock n'existe plus sur un appareil candidat - une
 * epreuve ne descend plus jamais vers lui (l'epreuve est l'outil de
 * l'encadrant, et le candidat ne doit ni la reconnaitre ni la reviser).
 *
 * Aucune version mobile, present ou futur, ne pourra donc resoudre une v6 : le
 * tirage retenu n'est plus rattrapable nulle part, et activer ce coupe-circuit
 * rendrait TOUT scan avant lancement incomposable hors ligne. Le drapeau reste
 * a faux par defaut ; la v6 est un cul-de-sac tant que rien ne redonne au
 * candidat de quoi resoudre une reference.
 */
const QR_PAYLOAD_VERSION_WITHHELD_DRAW = 6;

/** Algorithme de signature expose cote client (endpoint cle publique). */
const QR_SIGNATURE_ALGORITHM = 'Ed25519';

/** Langue de repli si aucun participant n'est encore inscrit au moment de l'export. */
const DEFAULT_QR_LANGUAGE = 'fr';

/**
 * Duree de validite du payload signe (24h). Genereuse pour couvrir
 * l'affichage du QR avant le jour J, la duree normale d'un examen blanc et la
 * composition hors-ligne d'un candidat qui ne synchronise que plus tard -
 * tout en bornant la duree de vie d'un artefact signe (un vieux QR ne doit
 * pas rester utilisable indefiniment). La validite de la SESSION elle-meme
 * (WAITING/ACTIVE/ENDED) est revalidee separement, en ligne, a la
 * synchronisation (cf. lot B4 - hors perimetre ici).
 */
const QR_PAYLOAD_VALIDITY_SECONDS = 24 * 60 * 60;

/**
 * Marge conservee APRES l'echeance de la seance (C-K8). Couvre le retardataire
 * qui scanne au moment ou le couperet tombe, la copie ramassee au temps ecoule
 * et la synchronisation differee d'un appareil hors ligne. Au-dela, le QR est
 * un artefact perime : le plafond de 24 h ne sert plus qu'aux seances sans
 * echeance connue.
 */
const QR_POST_DEADLINE_GRACE_SECONDS = 60 * 60;

/**
 * Plancher de validite d'un payload fraichement construit (C-K8). Sans lui, un
 * QR reaffiche a la toute fin d'une seance - ou d'une seance deja echue -
 * naitrait DEJA expire et serait rejete au scan, ce qui bloquerait un
 * retardataire parfaitement legitime. Le bornage de `exp` ne doit jamais
 * produire un artefact mort-ne.
 */
const QR_MIN_VALIDITY_SECONDS = 15 * 60;

/**
 * Correspondance stable mode <-> index numerique dans le payload compact.
 * Fige volontairement (jamais deduit de l'ordre de declaration de l'enum
 * Prisma cote DB) : l'application mobile code cette table en dur, un ajout
 * futur de valeur dans DistributionMode ne doit jamais decaler les index deja
 * en circulation.
 */
const DISTRIBUTION_MODE_INDEX: Record<DistributionMode, number> = {
  [DistributionMode.SAME_FOR_ALL]: 0,
  [DistributionMode.RANDOM_SHARED]: 1,
  [DistributionMode.RANDOM_PER_CANDIDATE]: 2,
};

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/**
 * Reference d'une epreuve source, telle que resolue par l'appelant depuis
 * `MockExam.sourceQuiz` (colonnes `paperScope`/`paperNumber`/`drivingSchoolId`/
 * `createdById` du `Quiz` source). Une epreuve n'est identifiee de facon
 * UNIQUE que par son numero ET sa portee (l'epreuve n°12 de la plateforme et
 * l'epreuve n°12 d'une ecole sont deux objets distincts) - `schoolId`/
 * `monitorUserId` levent cette ambiguite pour les portees personnelles,
 * miroir exact des index uniques partiels poses en base
 * (`quizzes_paper_platform_number_key`/`_school_number_key`/`_monitor_number_key`).
 */
export interface MockExamQrPaperRef {
  scope: ExamPaperScope;
  number: number;
  /** Requis (et utilise) uniquement si `scope = 'SCHOOL'`. */
  schoolId?: string | null;
  /** Requis (et utilise) uniquement si `scope = 'MONITOR'`. */
  monitorUserId?: string | null;
}

/** Donnees necessaires a la construction du payload, deja chargees par l'appelant (pas d'acces BDD ici). */
export interface MockExamQrPayloadInput {
  sessionCode: string;
  /**
   * Identifiant du moniteur organisateur (`mid`). Permet au client de dire
   * HORS LIGNE, avant de composer, qu'il n'est rattache ni a ce moniteur ni a
   * son ecole (C-K5). Informe, n'autorise pas.
   */
  monitorId: string;
  /**
   * Identifiant de l'ecole organisatrice (`sid`), `null` pour un moniteur
   * independant. Meme role que `monitorId`.
   */
  schoolId: string | null;
  /**
   * Nom affichable de l'organisateur (`org`) : l'ECOLE quand il y en a une, le
   * moniteur quand il exerce en independant. Meme regle que
   * `MyParticipationResultDto.organizerName`.
   */
  organizerName: string;
  /**
   * Titre de la seance (`t`), tel que l'encadrant l'a nommee - `null` quand
   * elle n'en a pas. C'est la seule source du nom de l'epreuve pour un
   * candidat qui compose HORS LIGNE.
   */
  sessionTitle: string | null;
  /**
   * Echeance reelle de la seance en epoch secondes (`launchedAt +
   * durationSeconds`, ou la date programmee a defaut), ou `null` quand aucune
   * echeance n'est connue (session pas encore lancee et sans duree). Sert
   * uniquement a BORNER `exp` (C-K8) : `null` retombe exactement sur le
   * comportement historique, le plafond de 24 h.
   */
  sessionDeadlineEpochSeconds: number | null;
  /**
   * Heure PREVUE de la seance en epoch secondes (`MockExam.scheduledAt`), ou
   * `null` quand elle n'est pas programmee. Transporte tel quel dans `sch`.
   *
   * A ne pas confondre avec `sessionDeadlineEpochSeconds`, qui borne la FIN.
   * Celui-ci dit quand la composition OUVRE, et c'est le seul repere d'un
   * candidat hors ligne : le QR ne peut pas porter le statut de la session
   * (il est imprime avant le top depart et scanne pendant), si bien qu'un
   * scan hors ligne ouvrait la composition d'une seance pas encore commencee
   * (retour Martin, 2026-09-07).
   */
  scheduledAtEpochSeconds: number | null;
  /**
   * Quand vrai, le tirage (`q`) n'est PAS publie et le payload bascule en v6
   * (C-K2). Calcule par `MockExamService.exportQr` a partir du statut de la
   * session et du reglage `withholdDrawBeforeLaunch`, et de rien d'autre.
   * Sans effet si la session n'est pas adossee a une epreuve enregistree : le
   * client n'aurait alors aucun moyen de reconstituer le tirage hors ligne.
   */
  withholdQuestionNumbers: boolean;
  distributionMode: DistributionMode;
  /** Delai global de la session en secondes. `null` retombe sur DURATION_FALLBACK_SECONDS. */
  durationSeconds: number | null;
  questionCount: number;
  /**
   * C-A13 - Toutes les categories du tirage, dans l'ordre choisi. `cat`
   * (deprecie) est derive de la premiere.
   *
   * C'est cette LISTE qui pilote reellement le tirage en ligne
   * (`MockExam.permitCategories`) et la revalidation hors ligne
   * (`assertQuestionInParticipantDraw`, `resolveOfflineQuestionIds`). Le
   * transport QR portait le champ singulier DEPRECIE : deux candidats de la
   * meme salle composaient sur des perimetres differents selon qu'ils etaient
   * en ligne ou non.
   */
  permitCategories: PermitCategoryCode[];
  themeIds: string[];
  /**
   * Numeros exacts du tirage (Question.number). Uniquement necessaire pour
   * SAME_FOR_ALL/RANDOM_SHARED - ignore pour RANDOM_PER_CANDIDATE. Restent
   * TOUJOURS presents et TOUJOURS la source de verite meme quand `paperRef`
   * est fourni (cf. paperRef ci-dessous) - jamais remplaces.
   */
  questionNumbers: number[];
  /** languageCode courant de chaque participant inscrit, pour le champ `lang` (indicatif). */
  participantLanguageCodes: string[];
  /**
   * Reference optionnelle de l'epreuve source (ADR-050/051), quand la
   * session a ete lancee depuis une epreuve enregistree plutot qu'une
   * composition libre. Fait basculer le payload en v5 (`p`) - EN PLUS de
   * `questionNumbers`/`q`, jamais a sa place (cf. doctrine "les numeros font
   * foi", ADR-051 SS9). `null`/absent = payload v3 inchange. Ignoree
   * (retombe en v3, avec un log) si `distributionMode` est
   * RANDOM_PER_CANDIDATE (une source figee y est de toute facon interdite en
   * amont, cf. mock-exam.service.ts) ou si la portee est incoherente
   * (SCHOOL sans schoolId, MONITOR sans monitorUserId) - defense en
   * profondeur, ce cas ne devrait jamais survenir en pratique (donnees
   * garanties coherentes par la contrainte CHECK posee en base sur `Quiz`).
   */
  paperRef?: MockExamQrPaperRef | null;
}

/** Payload avant signature (tous les champs de MockExamQrExportDto sauf `sig`). */
export type UnsignedMockExamQrPayload = Omit<MockExamQrExportDto, 'sig'>;

// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------

@Injectable()
export class MockExamQrService implements OnModuleInit {
  private readonly logger = new Logger(MockExamQrService.name);
  private privateKey: KeyObject | null = null;
  private publicKey: KeyObject | null = null;
  private publicKeyPem: string | null = null;

  /** Identifiant de la cle qui SIGNE actuellement, `null` sans cle chargee. */
  private privateKeyId: string | null = null;

  /**
   * Toutes les cles acceptees en VERIFICATION, indexees par `kid` : la cle
   * active et les cles retirees. Une cle retiree ne signe plus jamais, mais
   * continue de valider ce qu'elle a signe - c'est ce qui rend la rotation
   * possible sans invalider le parc (C-L15).
   */
  private readonly verificationKeys = new Map<string, KeyObject>();

  /** Catalogue servi tel quel par `getPublicKeyInfo()`, cle active en premier. */
  private keyCatalog: MockExamQrPublicKeyEntryDto[] = [];

  constructor(
    private readonly configService: AppConfigService,
    private readonly discordAlertService: DiscordAlertService,
    private readonly readiness: ReadinessRegistry,
  ) {}

  onModuleInit(): void {
    const { privateKey } = this.configService.mockExamQr;

    // Reinitialisation explicite : onModuleInit peut etre rejoue (tests,
    // rechargement de module) et le catalogue de cles ne doit jamais accumuler
    // des entrees d'une configuration precedente.
    this.verificationKeys.clear();
    this.keyCatalog = [];
    this.privateKeyId = null;

    if (!privateKey) {
      this.logger.warn(
        '[MockExamQr] MOCK_EXAM_QR_SIGNING_PRIVATE_KEY non définie - les QR ' +
          'examens blancs seront exportés SANS signature (dégradation best-effort, attendu en dev).',
      );
      this.readiness.report('QR examens blancs', 'disabled');
      return;
    }

    try {
      const privateKeyObject = createPrivateKey({
        key: privateKey,
        format: 'pem',
      });
      // La cle publique Ed25519 est toujours derivable de la cle privee -
      // aucune variable d'env separee n'est necessaire pour la publier.
      const publicKeyObject = createPublicKey(privateKeyObject);

      this.privateKey = privateKeyObject;
      this.publicKey = publicKeyObject;
      this.publicKeyPem = publicKeyObject
        .export({ type: 'spki', format: 'pem' })
        .toString();

      // Identifiant DERIVE de la cle publique elle-meme : il ne peut jamais se
      // desynchroniser de la cle qu'il designe, et aucune variable
      // d'environnement supplementaire n'est a provisionner lors d'une
      // rotation.
      this.privateKeyId = computeKeyId(publicKeyObject);
      this.verificationKeys.set(this.privateKeyId, publicKeyObject);
      this.keyCatalog = [
        {
          kid: this.privateKeyId,
          publicKey: this.publicKeyPem,
          status: 'ACTIVE',
        },
      ];

      this.loadRetiredPublicKeys();

      this.logger.debug(
        '[MockExamQr] Clé de signature Ed25519 chargée - QR examens blancs signes.',
      );
      this.readiness.report('QR examens blancs', 'ok');
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      // Indice actionnable sur la forme de la cle (jamais son contenu), meme
      // diagnostic que FCM/Apple (guillemets, PEM tronque, saut de ligne perdu...).
      const hint = diagnosePemPrivateKey(privateKey);
      this.logger.error(
        `[MockExamQr] Échec chargement MOCK_EXAM_QR_SIGNING_PRIVATE_KEY - QR exportes sans signature. ${reason}` +
          (hint ? ` | Indice: ${hint}` : ''),
        err instanceof Error ? err.stack : undefined,
      );
      this.privateKey = null;
      this.publicKey = null;
      this.publicKeyPem = null;
      this.privateKeyId = null;
      this.verificationKeys.clear();
      this.keyCatalog = [];
      this.readiness.report(
        'QR examens blancs',
        'degraded',
        hint ?? reason.slice(0, 120),
      );
      // Cle presente mais invalide = incident actionnable (contrairement a
      // l'absence pure, attendue en dev) : alerter, sinon la degradation
      // silencieuse d'une fonctionnalite de securite passe inapercue.
      void this.discordAlertService.sendAlertThrottled('mock-exam-qr-init', {
        severity: 'error',
        title: 'Clé de signature QR examens blancs invalide',
        description:
          'MOCK_EXAM_QR_SIGNING_PRIVATE_KEY est présente mais illisible ' +
          '(PEM mal formé). Les QR examens blancs seront exportés sans ' +
          'signature tant que ce n est pas corrigé.',
        context: hint ? { erreur: reason, indice: hint } : { erreur: reason },
        timestamp: new Date(),
      });
    }
  }

  /**
   * Charge les cles publiques RETIREES (`MOCK_EXAM_QR_RETIRED_PUBLIC_KEYS`) :
   * elles ne signent plus rien, mais restent acceptees en verification. Sans
   * elles, une rotation de cle serait une panne TOTALE de la verification hors
   * ligne sur tout le parc, ce qui revient a interdire la rotation - et donc a
   * laisser une cle compromise en service (C-L15).
   *
   * Une entree illisible est signalee par son INDEX, jamais par son contenu
   * (une cle publique n'est pas un secret, mais un journal n'a aucune raison
   * de recopier du materiel cryptographique), et n'interrompt jamais le
   * chargement des suivantes.
   */
  private loadRetiredPublicKeys(): void {
    const retired = this.configService.mockExamQr.retiredPublicKeys ?? [];

    retired.forEach((pem, index) => {
      if (!pem) return;
      try {
        const keyObject = createPublicKey({ key: pem, format: 'pem' });
        const kid = computeKeyId(keyObject);
        if (this.verificationKeys.has(kid)) {
          // Meme cle declaree active ET retiree : la version active gagne, la
          // liste n'a pas a la dupliquer.
          return;
        }
        this.verificationKeys.set(kid, keyObject);
        this.keyCatalog.push({
          kid,
          publicKey: keyObject
            .export({ type: 'spki', format: 'pem' })
            .toString(),
          status: 'RETIRED',
        });
      } catch (err) {
        this.logger.warn(
          `[MockExamQr] Clé publique retirée n°${index + 1} illisible - ignorée. ` +
            `Cause : ${err instanceof Error ? err.message : String(err)}`,
        );
      }
    });
  }

  /** La cle de signature est-elle chargee et operationnelle ? */
  isSigningConfigured(): boolean {
    return this.privateKey !== null;
  }

  /**
   * Identifiant de la cle qui signe actuellement, ou `null` si la signature
   * n'est pas configuree. Recopie tel quel dans le payload QR (`kid`) et dans
   * le certificat d'appareil (`MockExamDeviceService.issueCertificate`).
   */
  activeKeyId(): string | null {
    return this.privateKeyId;
  }

  /**
   * Refuse un export QR en PRODUCTION quand aucune cle de signature n'est
   * chargee (C-K1).
   *
   * AVANT : la degradation best-effort s'appliquait partout, sans distinction
   * d'environnement. Une production demarree sans
   * MOCK_EXAM_QR_SIGNING_PRIVATE_KEY exportait des QR non signes, sans que
   * personne ne le voie : n'importe qui pouvait alors fabriquer un QR de
   * toutes pieces, puisque le verificateur hors ligne n'avait plus rien a
   * verifier.
   * APRES : l'export echoue franchement en production. La degradation reste
   * entiere en developpement et en test, ou elle est le comportement voulu.
   *
   * Volontairement NON appelee depuis `exportSignedPayload` (fonction pure de
   * construction, utilisee aussi par les tests et les outils) : c'est
   * `MockExamService.exportQr` qui l'appelle, au bord de l'application.
   */
  requireSignature(): void {
    if (this.privateKey) return;
    if (!this.configService.isProduction()) return;
    throw new ServiceUnavailableException(
      ERRORS.MOCK_EXAM_QR_SIGNING_UNAVAILABLE,
    );
  }

  // ---------------------------------------------------------------------------
  // Construction du payload (pure, synchrone, sans acces reseau/BDD)
  // ---------------------------------------------------------------------------

  /**
   * Construit le payload QR compact (sans signature) depuis des donnees deja
   * chargees par l'appelant (MockExamService.exportQr). Fonction pure,
   * testable en isolation.
   *
   * Forme v3 (defaut) : `{ v:3, code, mode, dur, lang, n, q|c, exp }`.
   * Forme v5 (epreuve source) : memes champs QUE v3 PLUS `p` (reference
   * d'epreuve) - jamais `q` retire, jamais `c` ajoute a la place de `q`.
   * Bascule en v5 uniquement si `input.paperRef` est fourni, coherent
   * (`resolvePaperRefField` valide la portee), et le mode n'est pas
   * RANDOM_PER_CANDIDATE (une source figee y est de toute facon interdite en
   * amont - defense en profondeur, jamais atteint en pratique).
   */
  buildPayload(input: MockExamQrPayloadInput): UnsignedMockExamQrPayload {
    const base: UnsignedMockExamQrPayload = {
      v: QR_PAYLOAD_VERSION,
      code: input.sessionCode,
      // C-K5 - rattachement verifiable hors ligne. `sid` est OMIS (jamais
      // serialise a `null`) pour un moniteur independant : canonicalJsonStringify
      // ignore les cles `undefined`, la chaine signee reste donc identique a
      // celle d'avant pour tout champ absent.
      mid: input.monitorId,
      ...(input.schoolId ? { sid: input.schoolId } : {}),
      org: input.organizerName,
      // Titre de la seance - omis (jamais `null`) quand elle n'en a pas, comme
      // `sid` : `canonicalJsonStringify` ignore les cles `undefined`, la chaine
      // signee reste donc identique a celle d'avant pour une session sans
      // titre. Sans ce champ, un candidat hors ligne n'avait que le libelle
      // generique « Examen blanc » sur son ecran de resultat (retour Martin,
      // 2026-09-06).
      ...(input.sessionTitle?.trim() ? { t: input.sessionTitle.trim() } : {}),
      mode: DISTRIBUTION_MODE_INDEX[input.distributionMode],
      dur: input.durationSeconds ?? DURATION_FALLBACK_SECONDS,
      lang: this.resolveLanguage(input.participantLanguageCodes),
      n: input.questionCount,
      // ECHEANCE de la seance - a ne pas confondre avec `exp`, qui borne la
      // duree de vie du QR. Omis (jamais `null`) quand la session n'a pas de
      // duree : `canonicalJsonStringify` ignore les cles `undefined`, la
      // chaine signee reste donc identique a celle d'avant pour ces sessions.
      //
      // Pourquoi ce champ (retour Martin, 2026-09-06) : hors ligne, le mobile
      // n'avait que `dur` et repartait du delai PLEIN a partir du scan. Un
      // candidat qui scanne dix minutes apres le lancement d'une seance de
      // trente minutes composait donc trente minutes, et sa note se revelait
      // dix minutes apres celle des autres. Avec l'echeance absolue, il lui
      // reste vingt minutes, decomptees par son propre telephone.
      ...(input.sessionDeadlineEpochSeconds != null
        ? { end: input.sessionDeadlineEpochSeconds }
        : {}),
      // HEURE PREVUE de la seance - meme regle d'omission que `end` et `t` :
      // absent (jamais `null`) quand la seance n'est pas programmee, donc
      // chaine signee identique a celle d'avant ce champ pour ces seances.
      //
      // Pourquoi ce champ (retour Martin, 2026-09-07) : hors ligne, le mobile
      // n'avait AUCUN moyen de savoir si la seance avait commence - le QR est
      // imprime avant le top depart et scanne pendant, son statut serait donc
      // toujours perime. Un candidat qui scannait la veille pouvait composer
      // sur-le-champ. Avec l'heure prevue, son telephone sait l'attendre tout
      // seul ; une seance SANS heure prevue reste composable des le scan.
      ...(input.scheduledAtEpochSeconds != null
        ? { sch: input.scheduledAtEpochSeconds }
        : {}),
      exp: this.resolveExpiration(input.sessionDeadlineEpochSeconds),
      // C-L15 - `kid` entre DANS la portion signee : un intermediaire ne peut
      // pas le reecrire pour faire resoudre une autre cle publique au
      // verificateur. `undefined` quand aucune cle n'est configuree, donc
      // absent de la serialisation canonique : un backend sans cle produit
      // exactement le meme payload qu'avant ce lot, octet pour octet.
      kid: this.privateKeyId ?? undefined,
    };

    if (input.distributionMode === DistributionMode.RANDOM_PER_CANDIDATE) {
      // C-A13 - `cats` porte TOUTES les categories du tirage, `cat` reste la
      // premiere pour le parc deja deploye qui ne lit que ce champ (cas
      // majoritaire : une seule categorie, ou le comportement est identique a
      // l'octet pres).
      //
      // ⛔ AUCUN bump de version de payload pour cet ajout, et c'est
      // verifiable, pas une supposition : cote mobile,
      // `MockExamQrPayload.unsignedJson`
      // (pbj-mobile/lib/features/exams/data/mock_exam_qr_payload.dart, l.316 et
      // suivantes) est derive de `raw` MOINS `sig`, jamais reconstruit depuis
      // les champs types - le commentaire du fichier le dit explicitement
      // (« c'est cette propriete qui rend l'ajout de champs cote serveur
      // totalement transparent pour la verification de signature »). Un champ
      // ajoute a la portion signee ne casse donc aucune signature deja
      // deployee. Ne pas rouvrir la question a chaque lecture.
      const criteria: MockExamQrCriteriaDto = {
        cat: input.permitCategories[0] ?? null,
        cats: input.permitCategories,
        th: input.themeIds,
        n: input.questionCount,
      };
      return { ...base, c: criteria };
    }

    const withNumbers: UnsignedMockExamQrPayload = {
      ...base,
      q: input.questionNumbers,
    };

    const paperRefField = this.resolvePaperRefField(
      input.paperRef,
      input.distributionMode,
    );
    if (!paperRefField) return withNumbers;

    // C-K2 - retenue du tirage avant le lancement. La v6 est la v5 SANS `q` :
    // le client retrouve le tirage LOCALEMENT depuis son stock d'epreuves
    // (ADR-050), le serveur ne publie plus les numeros dans un artefact
    // affiche au tableau la veille. Retenue impossible sans reference
    // d'epreuve : la garde `paperRefField` ci-dessus l'assure.
    if (input.withholdQuestionNumbers) {
      return {
        ...base,
        v: QR_PAYLOAD_VERSION_WITHHELD_DRAW,
        p: paperRefField,
      };
    }

    return {
      ...withNumbers,
      v: QR_PAYLOAD_VERSION_PAPER_REF,
      p: paperRefField,
    };
  }

  /**
   * Borne l'expiration du payload (C-K8).
   *
   * AVANT : `exp` valait invariablement 24 h. Un QR photographie dans la salle
   * restait utilisable une journee entiere pour rejoindre depuis un appareil
   * hors ligne une seance qui durait quarante-cinq minutes, et longtemps apres
   * sa fin.
   * APRES : l'echeance de la seance plus une heure de grace fait plafond. La
   * fenetre d'exploitation d'un QR capte tombe a la duree de la seance.
   *
   * Le plafond historique de 24 h est conserve pour les seances SANS echeance
   * connue (`null`), ou le comportement reste strictement celui d'avant. Le
   * plancher de quinze minutes garantit qu'un QR fraichement construit n'est
   * jamais deja expire a l'affichage, ce qui rejetterait au scan un
   * retardataire legitime.
   */
  private resolveExpiration(
    sessionDeadlineEpochSeconds: number | null,
  ): number {
    const now = Math.floor(Date.now() / 1000);
    const ceiling = now + QR_PAYLOAD_VALIDITY_SECONDS;
    const bounded =
      sessionDeadlineEpochSeconds != null
        ? Math.min(
            ceiling,
            sessionDeadlineEpochSeconds + QR_POST_DEADLINE_GRACE_SECONDS,
          )
        : ceiling;
    return Math.max(bounded, now + QR_MIN_VALIDITY_SECONDS);
  }

  /**
   * Valide et met en forme la reference d'epreuve pour le payload (`p`).
   * Renvoie `null` (jamais de throw - degrade silencieusement en v3, avec un
   * log) si :
   *   - aucune reference n'est fournie ;
   *   - le mode est RANDOM_PER_CANDIDATE (incompatible avec toute source figee) ;
   *   - la portee n'est pas l'une des trois valeurs connues ;
   *   - la portee est SCHOOL sans `schoolId`, ou MONITOR sans `monitorUserId`
   *     (portee manquante/ambigue - une epreuve n'est identifiee de facon
   *     unique que par son numero ET sa portee, cf. doc du type
   *     MockExamQrPaperRef).
   * Ce degrade ne devrait jamais survenir en pratique : les colonnes source
   * (`Quiz.paperScope`/`drivingSchoolId`/`createdById`) sont garanties
   * coherentes par la contrainte CHECK posee en base - mais un payload QR est
   * un artefact public, jamais construit sans cette derniere verification.
   */
  private resolvePaperRefField(
    ref: MockExamQrPaperRef | null | undefined,
    distributionMode: DistributionMode,
  ): MockExamQrPaperRefDto | null {
    if (!ref) return null;

    if (distributionMode === DistributionMode.RANDOM_PER_CANDIDATE) {
      this.logger.warn(
        '[MockExamQr] paperRef fourni avec RANDOM_PER_CANDIDATE - ignore (combinaison normalement bloquée en amont).',
      );
      return null;
    }

    if (!EXAM_PAPER_SCOPES.includes(ref.scope)) {
      this.logger.warn(
        `[MockExamQr] paperRef.scope inconnu ("${String(ref.scope)}") - ignore.`,
      );
      return null;
    }

    if (ref.scope === EXAM_PAPER_SCOPE_SCHOOL) {
      if (!ref.schoolId) {
        this.logger.warn(
          `[MockExamQr] paperRef portée SCHOOL sans schoolId (épreuve n°${ref.number}) - portée ambiguë, ignore.`,
        );
        return null;
      }
      return { sc: ref.scope, num: ref.number, sid: ref.schoolId };
    }

    if (ref.scope === EXAM_PAPER_SCOPE_MONITOR) {
      if (!ref.monitorUserId) {
        this.logger.warn(
          `[MockExamQr] paperRef portée MONITOR sans monitorUserId (épreuve n°${ref.number}) - portée ambiguë, ignore.`,
        );
        return null;
      }
      return { sc: ref.scope, num: ref.number, uid: ref.monitorUserId };
    }

    // PLATFORM : le numero seul suffit (unique globalement pour cette portee).
    return { sc: ref.scope, num: ref.number };
  }

  /**
   * Construit puis signe le payload. Renvoie le payload SANS `sig` si la cle
   * de signature n'est pas configuree (degradation best-effort, cf. en-tete
   * de la classe) - ne leve jamais d'exception.
   */
  exportSignedPayload(input: MockExamQrPayloadInput): MockExamQrExportDto {
    const payload = this.buildPayload(input);
    const signature = this.sign(payload);
    return signature ? { ...payload, sig: signature } : payload;
  }

  // ---------------------------------------------------------------------------
  // Signature / verification Ed25519
  // ---------------------------------------------------------------------------

  /**
   * Signe une serialisation JSON canonique (cles triees recursivement) du
   * payload. Renvoie `null` si aucune cle de signature n'est configuree.
   */
  sign(payload: UnsignedMockExamQrPayload): string | null {
    return this.signValue(payload);
  }

  /**
   * Variante generique de `sign()` - meme cle, meme serialisation canonique -
   * reutilisee par le certificat d'appareil (ADR-013, mini-PKI) qui n'a pas la
   * forme d'un payload QR. `sign()` delegue a cette methode ; a conserver
   * strictement identique pour ne jamais diverger entre QR et certificats.
   */
  signValue(value: unknown): string | null {
    if (!this.privateKey) return null;
    const canonical = canonicalJsonStringify(value);
    // Pour Ed25519/Ed448, l'algorithme de hachage prealable doit rester
    // `null` : EdDSA hache en interne, cf. doc Node crypto.sign().
    const signature = cryptoSign(
      null,
      Buffer.from(canonical, 'utf8'),
      this.privateKey,
    );
    return signature.toString('base64url');
  }

  /**
   * Verifie une signature detachee contre le payload (sans `sig`). Reference
   * pour l'implementation mobile (verification hors-ligne) et pour les tests
   * de ce service. Renvoie `false` (jamais de throw) si aucune cle publique
   * n'est chargee ou si la signature est mal formee.
   */
  verify(
    payload: UnsignedMockExamQrPayload,
    signature: string,
    kid?: string,
  ): boolean {
    // Resolution par `kid` : c'est ce qui permet de continuer a valider un
    // artefact signe par une cle desormais RETIREE, donc de faire tourner la
    // cle de signature sans invalider les QR imprimes ni les certificats
    // d'appareil emis (C-L15). Sans `kid` (artefact anterieur a ce lot), repli
    // sur la cle active, comportement d'avant.
    const key = kid ? this.verificationKeys.get(kid) : this.publicKey;
    if (!key) return false;
    try {
      const canonical = canonicalJsonStringify(payload);
      return cryptoVerify(
        null,
        Buffer.from(canonical, 'utf8'),
        key,
        Buffer.from(signature, 'base64url'),
      );
    } catch {
      return false;
    }
  }

  // ---------------------------------------------------------------------------
  // Cle publique (endpoint GET /mock-exams/qr-public-key)
  // ---------------------------------------------------------------------------

  /**
   * Cles publiques a embarquer cote mobile pour la verification hors ligne.
   *
   * `algorithm`, `publicKey` et `configured` gardent EXACTEMENT leur semantique
   * d'origine : des clients deja deployes ne lisent que ces trois champs et ne
   * doivent rien voir changer.
   *
   * `kid` et `keys` sont l'apport du lot K. AVANT, le mobile ne connaissait
   * qu'une cle, qu'il ecrasait a chaque rafraichissement : une rotation lui
   * faisait perdre d'un coup la capacite de verifier tout ce qui avait ete
   * signe avant, donc la rotation etait de fait impossible et une cle
   * compromise restait en service. APRES, le client met en cache le TABLEAU
   * (dictionnaire `kid` vers PEM) et continue de verifier les artefacts
   * anterieurs a la rotation.
   *
   * Les champs de revocation du DTO (`revokedDeviceIdHashes`,
   * `revocationIssuedAt`, `revocationSignature`) sont composes par le
   * controleur depuis `MockExamDeviceService` : ce service ne touche pas la
   * base.
   */
  getPublicKeyInfo(): Omit<
    MockExamQrPublicKeyDto,
    'revokedDeviceIdHashes' | 'revocationIssuedAt' | 'revocationSignature'
  > {
    return {
      algorithm: QR_SIGNATURE_ALGORITHM,
      publicKey: this.publicKeyPem,
      configured: this.publicKeyPem !== null,
      kid: this.privateKeyId,
      // Copie defensive : le catalogue interne ne doit jamais etre mutable
      // depuis l'exterieur du service.
      keys: this.keyCatalog.map((entry) => ({ ...entry })),
    };
  }

  // ---------------------------------------------------------------------------
  // Prive
  // ---------------------------------------------------------------------------

  /**
   * Langue de reference indicative de la session : la plus frequente parmi
   * les participants actuellement inscrits (egalite = premiere rencontree),
   * ou le defaut FR si aucun participant. PUREMENT INFORMATIF - la langue de
   * composition reelle de chaque candidat suit toujours son propre profil
   * local (learningLanguage), jamais ce champ (cf. MockExamParticipant.languageCode,
   * fige individuellement par candidat a la publication).
   */
  private resolveLanguage(codes: string[]): string {
    if (codes.length === 0) return DEFAULT_QR_LANGUAGE;

    const counts = new Map<string, number>();
    for (const code of codes) {
      counts.set(code, (counts.get(code) ?? 0) + 1);
    }

    let best = codes[0];
    let bestCount = 0;
    for (const [code, count] of counts) {
      if (count > bestCount) {
        best = code;
        bestCount = count;
      }
    }
    return best;
  }
}

// ---------------------------------------------------------------------------
// Identifiant de cle (`kid`)
// ---------------------------------------------------------------------------

/**
 * Identifiant court et deterministe d'une cle publique : les huit premiers
 * octets (seize caracteres hexadecimaux) du SHA-256 de son DER SPKI.
 *
 * DERIVE de la cle elle-meme, jamais configure a part : impossible de le
 * desynchroniser de la cle qu'il designe, et une rotation ne demande aucune
 * variable d'environnement supplementaire - il suffit de deplacer l'ancienne
 * cle publique dans MOCK_EXAM_QR_RETIRED_PUBLIC_KEYS.
 *
 * Ce n'est PAS un secret ni une preuve : il designe une cle, il n'authentifie
 * rien. Sa valeur de securite vient de sa presence DANS la portion signee du
 * payload et du certificat, ou il ne peut plus etre substitue.
 */
export function computeKeyId(publicKey: KeyObject): string {
  return createHash('sha256')
    .update(publicKey.export({ type: 'spki', format: 'der' }))
    .digest('hex')
    .slice(0, 16);
}

// ---------------------------------------------------------------------------
// Serialisation JSON canonique (cles triees recursivement)
// ---------------------------------------------------------------------------
// Necessaire pour que la signature soit deterministe independamment de
// l'ordre de construction de l'objet JS. V8 preserve l'ordre d'insertion des
// cles string, mais un artefact cryptographique ne doit jamais en dependre
// implicitement (refactor futur du code de construction, etc.).

// Exporte (nommement) pour verrouiller l'interoperabilite crypto cross-stack :
// le spec `qr-golden-vectors.spec.ts` et le generateur de vecteurs figes
// (`__fixtures__/generate-qr-golden-vectors.mts`) l'importent tel quel, afin de
// garantir que la chaine canonique testee est bien CELLE utilisee en production
// (et non une reimplementation). Reste une fonction module-level pure.
export function canonicalJsonStringify(value: unknown): string {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) {
    return `[${value.map((item) => canonicalJsonStringify(item)).join(',')}]`;
  }
  const record = value as Record<string, unknown>;
  const entries = Object.keys(record)
    .filter((key) => record[key] !== undefined)
    .sort()
    .map(
      (key) => `${JSON.stringify(key)}:${canonicalJsonStringify(record[key])}`,
    );
  return `{${entries.join(',')}}`;
}
