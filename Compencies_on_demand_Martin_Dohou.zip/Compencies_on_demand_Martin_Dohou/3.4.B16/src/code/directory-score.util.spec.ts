// =============================================================================
// directory-score.util - Tests unitaires (ADR-019 / PP-12)
// =============================================================================

import {
  bayesianRating,
  computeCompleteness,
  computeDirectoryScore,
  sumDirectoryWeights,
  type DirectoryScoreConfig,
  type DirectoryScoreSignals,
} from './directory-score.util';

// Config de référence = valeurs initiales de l'ADR-019 (§5/§4/§7).
const baseConfig: DirectoryScoreConfig = {
  weightSuccess: 0.3,
  weightRating: 0.2,
  weightCompleteness: 0.15,
  weightActivity: 0.12,
  weightVerified: 0.1,
  weightSeniority: 0.08,
  weightVolume: 0.05,
  bayesianPriorMean: 3.5,
  bayesianPriorCount: 10,
  defaultSuccessRate: 50,
  seniorityCapYears: 10,
  activityCap: 20,
  activityWindowDays: 90,
  volumeLogBase: 1000,
};

// Signaux « vides » : profil neutre sans aucune donnée.
const emptySignals: DirectoryScoreSignals = {
  successRate: null,
  rating: null,
  reviewCount: 0,
  completeness: 0,
  activeRecentCount: 0,
  isVerified: false,
  seniorityYears: 0,
  volumeCount: 0,
};

describe('directory-score.util', () => {
  // ---------------------------------------------------------------------------
  // Invariant : somme des poids = 1
  // ---------------------------------------------------------------------------

  it('la somme des 7 poids de mérite vaut 1', () => {
    expect(sumDirectoryWeights(baseConfig)).toBeCloseTo(1, 10);
  });

  // ---------------------------------------------------------------------------
  // Sortie bornée [0,1]
  // ---------------------------------------------------------------------------

  it('retourne toujours une valeur dans [0,1] (profil vide)', () => {
    const score = computeDirectoryScore(emptySignals, baseConfig);
    expect(score).toBeGreaterThanOrEqual(0);
    expect(score).toBeLessThanOrEqual(1);
  });

  it('retourne 1 pour un profil parfait sur tous les signaux', () => {
    const perfect: DirectoryScoreSignals = {
      successRate: 100,
      rating: 5,
      reviewCount: 100000,
      completeness: 1,
      activeRecentCount: 1000,
      isVerified: true,
      seniorityYears: 50,
      volumeCount: 1000,
    };
    // rating bayésien plafonne < 5, donc score très proche de 1 sans l'atteindre.
    const score = computeDirectoryScore(perfect, baseConfig);
    expect(score).toBeGreaterThan(0.98);
    expect(score).toBeLessThanOrEqual(1);
  });

  it('borne les entrées aberrantes (NaN/négatif) sans casser', () => {
    const weird: DirectoryScoreSignals = {
      successRate: 999,
      rating: 12,
      reviewCount: -5,
      completeness: 4,
      activeRecentCount: -10,
      isVerified: false,
      seniorityYears: -3,
      volumeCount: -100,
    };
    const score = computeDirectoryScore(weird, baseConfig);
    expect(score).toBeGreaterThanOrEqual(0);
    expect(score).toBeLessThanOrEqual(1);
  });

  // ---------------------------------------------------------------------------
  // Complétude : complet > vide à métriques égales
  // ---------------------------------------------------------------------------

  it('un profil complet score plus haut qu’un profil vide, métriques égales', () => {
    const common = {
      successRate: 70,
      rating: 4,
      reviewCount: 20,
      activeRecentCount: 5,
      isVerified: false,
      seniorityYears: 5,
      volumeCount: 50,
    };
    const full = computeDirectoryScore(
      { ...common, completeness: 1 },
      baseConfig,
    );
    const empty = computeDirectoryScore(
      { ...common, completeness: 0 },
      baseConfig,
    );
    expect(full).toBeGreaterThan(empty);
    // L'écart vaut exactement le poids de complétude (0.15).
    expect(full - empty).toBeCloseTo(baseConfig.weightCompleteness, 10);
  });

  // ---------------------------------------------------------------------------
  // Amortissement bayésien : 5/5 sur 1 avis < 4.6/5 sur 80 avis
  // ---------------------------------------------------------------------------

  it('amortissement bayésien : 5/5 sur 1 avis < 4.6/5 sur 80 avis', () => {
    // Valeurs de contrôle de l'ADR-019 §4.
    expect(bayesianRating(5, 1, 3.5, 10)).toBeCloseTo(3.64, 2);
    expect(bayesianRating(4.6, 80, 3.5, 10)).toBeCloseTo(4.48, 2);

    const highFewReviews = computeDirectoryScore(
      { ...emptySignals, rating: 5, reviewCount: 1 },
      baseConfig,
    );
    const goodManyReviews = computeDirectoryScore(
      { ...emptySignals, rating: 4.6, reviewCount: 80 },
      baseConfig,
    );
    expect(goodManyReviews).toBeGreaterThan(highFewReviews);
  });

  it('sans avis, la note bayésienne vaut le prior (neutre)', () => {
    expect(bayesianRating(null, 0, 3.5, 10)).toBeCloseTo(3.5, 10);
  });

  // ---------------------------------------------------------------------------
  // Ancienneté plafonnée à 10 ans
  // ---------------------------------------------------------------------------

  it('l’ancienneté est plafonnée : 40 ans ne bat pas 10 ans', () => {
    const tenYears = computeDirectoryScore(
      { ...emptySignals, seniorityYears: 10 },
      baseConfig,
    );
    const fortyYears = computeDirectoryScore(
      { ...emptySignals, seniorityYears: 40 },
      baseConfig,
    );
    expect(fortyYears).toBeCloseTo(tenYears, 10);
    // Contribution d'ancienneté pleine = poids seniority.
    expect(
      tenYears - computeDirectoryScore(emptySignals, baseConfig),
    ).toBeCloseTo(baseConfig.weightSeniority, 10);
  });

  // ---------------------------------------------------------------------------
  // Volume plafonné (log borné)
  // ---------------------------------------------------------------------------

  it('le volume est plafonné : au-delà de la base log, la contribution sature', () => {
    const atBase = computeDirectoryScore(
      { ...emptySignals, volumeCount: 1000 },
      baseConfig,
    );
    const wayAbove = computeDirectoryScore(
      { ...emptySignals, volumeCount: 1_000_000 },
      baseConfig,
    );
    expect(wayAbove).toBeCloseTo(atBase, 10);
    // Volume à la base = contribution pleine = poids volume.
    expect(
      atBase - computeDirectoryScore(emptySignals, baseConfig),
    ).toBeCloseTo(baseConfig.weightVolume, 10);
  });

  // ---------------------------------------------------------------------------
  // Vérification : +0.10
  // ---------------------------------------------------------------------------

  it('isVerified ajoute exactement le poids de vérification (0.10)', () => {
    const notVerified = computeDirectoryScore(emptySignals, baseConfig);
    const verified = computeDirectoryScore(
      { ...emptySignals, isVerified: true },
      baseConfig,
    );
    expect(verified - notVerified).toBeCloseTo(baseConfig.weightVerified, 10);
  });

  // ---------------------------------------------------------------------------
  // successRate = null -> défaut 50
  // ---------------------------------------------------------------------------

  it('successRate=null est traité comme le défaut neutre (50)', () => {
    const nullRate = computeDirectoryScore(emptySignals, baseConfig);
    const fifty = computeDirectoryScore(
      { ...emptySignals, successRate: 50 },
      baseConfig,
    );
    expect(nullRate).toBeCloseTo(fifty, 10);
  });

  // ---------------------------------------------------------------------------
  // computeCompleteness
  // ---------------------------------------------------------------------------

  describe('computeCompleteness', () => {
    it('retourne 0 pour une liste vide', () => {
      expect(computeCompleteness([])).toBe(0);
    });

    it('somme pondérée des champs présents / total pondéré', () => {
      const c = computeCompleteness([
        { present: true, weight: 2 },
        { present: false, weight: 1 },
        { present: true, weight: 1 },
      ]);
      expect(c).toBeCloseTo(3 / 4, 10);
    });

    it('tout rempli = 1, rien rempli = 0', () => {
      const fields = [
        { present: true, weight: 1 },
        { present: true, weight: 3 },
      ];
      expect(computeCompleteness(fields)).toBe(1);
      expect(
        computeCompleteness(fields.map((f) => ({ ...f, present: false }))),
      ).toBe(0);
    });
  });

  // ---------------------------------------------------------------------------
  // Simulation de classement bout-en-bout (mérite pur)
  // ---------------------------------------------------------------------------

  it('classe une fiche de qualité au-dessus d’une grosse fiche vide', () => {
    // Profil "qualité récente" : bonne réussite, avis solides, complet, vérifié,
    // mais faible volume cumulé.
    const quality = computeDirectoryScore(
      {
        successRate: 85,
        rating: 4.7,
        reviewCount: 60,
        completeness: 0.9,
        activeRecentCount: 15,
        isVerified: true,
        seniorityYears: 6,
        volumeCount: 40,
      },
      baseConfig,
    );
    // Profil "gros mais vide" : énorme volume cumulé, rien d'autre.
    const bigButEmpty = computeDirectoryScore(
      {
        successRate: null,
        rating: null,
        reviewCount: 0,
        completeness: 0.1,
        activeRecentCount: 0,
        isVerified: false,
        seniorityYears: 0,
        volumeCount: 5000,
      },
      baseConfig,
    );
    expect(quality).toBeGreaterThan(bigButEmpty);
  });
});
