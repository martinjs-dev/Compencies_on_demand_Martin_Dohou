// =============================================================================
// directory-score.util - Fonction pure de scoring de l'annuaire (ADR-019 / PP-12)
// =============================================================================
//
// Classement au MÉRITE PUR : aucun signal payant/sponsorisé. Chaque composante
// est normalisée dans [0,1], pondérée par un vecteur de poids sommant à 1, puis
// sommée. Les avis sont amortis par une moyenne bayésienne pour qu'un faible
// volume ne domine pas. L'ancienneté et le volume sont plafonnés (anti-gaming).
//
// Fonction PURE et testée unitairement (cf. directory-score.util.spec.ts) :
// aucune dépendance NestJS/Prisma. Utilisée par DirectoryMetricsService pour
// alimenter la colonne dénormalisée `directoryScore` (école + moniteur).
// =============================================================================

/**
 * Configuration de scoring (poids, priors bayésiens, plafonds). Structurellement
 * compatible avec `DirectoryRankingSettings` (app-settings) mais redéclarée ici
 * pour garder le domaine annuaire pur (aucun import inter-module). Le service
 * passe la config lue depuis AppSetting.
 */
export interface DirectoryScoreConfig {
  weightSuccess: number;
  weightRating: number;
  weightCompleteness: number;
  weightActivity: number;
  weightVerified: number;
  weightSeniority: number;
  weightVolume: number;
  bayesianPriorMean: number;
  bayesianPriorCount: number;
  defaultSuccessRate: number;
  seniorityCapYears: number;
  activityCap: number;
  activityWindowDays: number;
  volumeLogBase: number;
}

/**
 * Signaux bruts d'un profil (école ou moniteur), tels qu'extraits en base au
 * moment du recalcul. La normalisation [0,1] est faite dans computeDirectoryScore
 * SAUF `completeness` (spécifique à la forme école/moniteur) déjà normalisée.
 */
export interface DirectoryScoreSignals {
  /** Taux de réussite en % [0,100], ou null si non calculé. */
  successRate: number | null;
  /** Note moyenne brute [0,5], ou null si aucun avis. */
  rating: number | null;
  /** Nombre d'avis (n de la moyenne bayésienne). */
  reviewCount: number;
  /** Complétude du profil déjà normalisée [0,1] (cf. computeCompleteness). */
  completeness: number;
  /** Nombre de candidats actifs récents (avant plafonnement). */
  activeRecentCount: number;
  /** Fiche vérifiée par l'équipe (bonus binaire admin). */
  isVerified: boolean;
  /** Ancienneté déclarée en années (foundedYear -> âge, ou yearsExperience). */
  seniorityYears: number;
  /** Volume cumulé de candidats (candidateCount / totalCandidates). */
  volumeCount: number;
}

/** Borne une valeur dans [0,1]. */
function clamp01(value: number): number {
  if (!Number.isFinite(value)) return 0;
  if (value < 0) return 0;
  if (value > 1) return 1;
  return value;
}

/**
 * Somme des 7 poids de mérite. Sert d'invariant testable (doit valoir 1).
 */
export function sumDirectoryWeights(config: DirectoryScoreConfig): number {
  return (
    config.weightSuccess +
    config.weightRating +
    config.weightCompleteness +
    config.weightActivity +
    config.weightVerified +
    config.weightSeniority +
    config.weightVolume
  );
}

/**
 * Moyenne bayésienne des avis : ratingBayes = (C*m + n*r) / (C + n).
 * - m = moyenne globale a priori (prior), C = poids du prior en nb d'avis.
 * - Sans avis (n=0) -> retourne m (neutre). Une 5/5 sur 1 avis reste tirée
 *   vers le prior ; une 4,6/5 sur 80 avis converge vers sa vraie note.
 */
export function bayesianRating(
  rating: number | null,
  reviewCount: number,
  priorMean: number,
  priorCount: number,
): number {
  const n = Math.max(reviewCount, 0);
  const r = rating ?? priorMean;
  const denom = priorCount + n;
  if (denom <= 0) return priorMean;
  return (priorCount * priorMean + n * r) / denom;
}

/**
 * Complétude pondérée : somme des poids des champs réellement remplis divisée
 * par la somme totale des poids. Ne récompense QUE des champs présents (pas de
 * bourrage). Retourne [0,1]. Une liste vide -> 0.
 */
export function computeCompleteness(
  fields: ReadonlyArray<{ present: boolean; weight: number }>,
): number {
  let total = 0;
  let filled = 0;
  for (const f of fields) {
    total += f.weight;
    if (f.present) filled += f.weight;
  }
  if (total <= 0) return 0;
  return clamp01(filled / total);
}

/**
 * Calcule le score de classement dénormalisé `directoryScore` ∈ [0,1].
 *
 * directoryScore =
 *     wSuccess     * successNorm      (COALESCE(successRate, défaut)/100)
 *   + wRating      * ratingBayesNorm  (moyenne bayésienne / 5)
 *   + wCompleteness* completenessNorm (champs remplis / total pondéré)
 *   + wActivity    * activityNorm     (min(actifsRécents, CAP)/CAP)
 *   + wVerified    * verifiedNorm     (isVerified ? 1 : 0)
 *   + wSeniority   * seniorityNorm    (min(ancienneté, CAP=10)/CAP)
 *   + wVolume      * volumeNorm       (min(LOG(max(count,1))/LOG(base), 1))
 *
 * La proximité géo est EXCLUE (signal contextuel appliqué à la requête).
 */
export function computeDirectoryScore(
  signals: DirectoryScoreSignals,
  config: DirectoryScoreConfig,
): number {
  const successNorm = clamp01(
    (signals.successRate ?? config.defaultSuccessRate) / 100,
  );

  const ratingBayes = bayesianRating(
    signals.rating,
    signals.reviewCount,
    config.bayesianPriorMean,
    config.bayesianPriorCount,
  );
  const ratingBayesNorm = clamp01(ratingBayes / 5);

  const completenessNorm = clamp01(signals.completeness);

  const activityCap = Math.max(config.activityCap, 1);
  const activityNorm = clamp01(
    Math.min(Math.max(signals.activeRecentCount, 0), activityCap) / activityCap,
  );

  const verifiedNorm = signals.isVerified ? 1 : 0;

  const seniorityCap = Math.max(config.seniorityCapYears, 1);
  const seniorityNorm = clamp01(
    Math.min(Math.max(signals.seniorityYears, 0), seniorityCap) / seniorityCap,
  );

  const logBase = Math.max(config.volumeLogBase, 2);
  const volumeNorm = clamp01(
    Math.min(Math.log(Math.max(signals.volumeCount, 1)) / Math.log(logBase), 1),
  );

  const score =
    config.weightSuccess * successNorm +
    config.weightRating * ratingBayesNorm +
    config.weightCompleteness * completenessNorm +
    config.weightActivity * activityNorm +
    config.weightVerified * verifiedNorm +
    config.weightSeniority * seniorityNorm +
    config.weightVolume * volumeNorm;

  return clamp01(score);
}
