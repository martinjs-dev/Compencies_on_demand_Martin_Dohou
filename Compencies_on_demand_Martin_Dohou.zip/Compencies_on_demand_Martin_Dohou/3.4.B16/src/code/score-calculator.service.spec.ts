// =============================================================================
// ScoreCalculator - Tests unitaires de la formule D-78 (2 composantes)
// =============================================================================
//
// D-78 (2026-09-20) : 90 % couverture des questions, 10 % leçons des COURS
// PRINCIPAUX. Les sujets sont sortis de la formule - un sujet est fait de
// questions, donc le traiter fait deja monter la maitrise.

import { readFileSync, readdirSync, statSync } from 'fs';
import { join } from 'path';
import {
  computeGlobalScore,
  READINESS_THRESHOLD,
  scoreOn20,
  subjectCredit,
  SUBJECT_CREDIT_FLOOR_PCT,
  SUBJECT_PASS_BASE_CREDIT,
  SUBJECT_PASS_THRESHOLD_PCT,
  WEIGHT_LESSONS,
  WEIGHT_MASTERY,
  WEIGHT_SUBJECTS,
} from './score-calculator.service';
import { OFFICIAL_EXAM_PASS_SCORE_PERCENT } from '../../../common/constants/exam-rules.constants';

const SOURCE_OF_TRUTH_FILE = 'score-calculator.service.ts';
/**
 * Un jour, D-65 a été à moitié appliquée : la formule vivait à la fois ici
 * ET dans candidates/app/candidate-home.service.ts, avec des poids v6
 * différents, ce qui affichait deux scores différents au moniteur et au
 * candidat pour le même candidat. Ce test échoue si une déclaration des
 * poids (WEIGHT_MASTERY/WEIGHT_LESSONS/WEIGHT_SUBJECTS = <nombre>) réapparaît
 * ailleurs que dans ce fichier. `computeGlobalScore` doit rester l'unique
 * source de vérité, importée et jamais redéfinie.
 */
function findWeightDeclarations(rootDir: string): string[] {
  const declarationPattern =
    /\b(WEIGHT_MASTERY|WEIGHT_LESSONS|WEIGHT_SUBJECTS)\s*=\s*[\d.]+/;
  const offenders: string[] = [];

  const walk = (dir: string) => {
    for (const entry of readdirSync(dir)) {
      if (entry === 'node_modules' || entry === 'generated') continue;
      const fullPath = join(dir, entry);
      const stats = statSync(fullPath);
      if (stats.isDirectory()) {
        walk(fullPath);
        continue;
      }
      if (!entry.endsWith('.ts') || entry.endsWith('.spec.ts')) continue;
      if (entry === SOURCE_OF_TRUTH_FILE) continue;
      const content = readFileSync(fullPath, 'utf-8');
      if (declarationPattern.test(content)) offenders.push(fullPath);
    }
  };

  walk(rootDir);
  return offenders;
}

/**
 * Agregats complets, tous a zero. Chaque test ne surcharge QUE les compteurs
 * qui l'interessent : on voit alors d'un coup d'oeil ce qui pese et ce qui ne
 * pese pas, et un champ ajoute au contrat ne reecrit pas dix litteraux.
 */
const agg = (
  over: Partial<Parameters<typeof computeGlobalScore>[0]> = {},
): Parameters<typeof computeGlobalScore>[0] => ({
  questionsMastered: 0,
  questionsTotal: 0,
  lessonsCompleted: 0,
  lessonsTotal: 0,
  mainLessonsCompleted: 0,
  mainLessonsTotal: 0,
  subjectsCompleted: 0,
  subjectsTotal: 0,
  subjectAverageScorePct: null,
  ...over,
});

describe('computeGlobalScore', () => {
  it('retourne 0 pour un candidat sans aucune activité', () => {
    expect(computeGlobalScore(agg())).toBe(0);
  });

  it('retourne 100 pour un candidat parfait', () => {
    expect(
      computeGlobalScore(
        agg({
          questionsMastered: 100,
          questionsTotal: 100,
          mainLessonsCompleted: 50,
          mainLessonsTotal: 50,
        }),
      ),
    ).toBe(100);
  });

  it('applique la pondération D-78 (mastery 90%, leçons des cours principaux 10%)', () => {
    // 786 questions du permis B, 400 maitrisees -> 50,89 % ; 120 leçons lues
    // sur les 507 des cours principaux -> 23,66 %.
    // 0,90 x 50,89 + 0,10 x 23,66 = 45,80 + 2,36 = 48,17 -> 48
    expect(
      computeGlobalScore(
        agg({
          questionsMastered: 400,
          questionsTotal: 786,
          mainLessonsCompleted: 120,
          mainLessonsTotal: 507,
        }),
      ),
    ).toBe(48);
  });

  it('un candidat qui a TOUT lu sans repondre a une seule question plafonne a 10', () => {
    // C'est l'intention de D-78, et c'est plus severe que les 15 % de D-65.
    expect(
      computeGlobalScore(
        agg({ mainLessonsCompleted: 507, mainLessonsTotal: 507 }),
      ),
    ).toBe(10);
  });

  it('⛔ les SUJETS ne pesent plus rien : tout les traiter ne change pas le score', () => {
    // Un sujet est fait de questions : il fait monter la maitrise, et c'est
    // par la qu'il compte. Lui garder un terme propre, c'etait le compter
    // deux fois (D-78).
    const sans = computeGlobalScore(
      agg({ questionsMastered: 400, questionsTotal: 786 }),
    );
    const avec = computeGlobalScore(
      agg({
        questionsMastered: 400,
        questionsTotal: 786,
        subjectsCompleted: 70,
        subjectsTotal: 70,
        subjectAverageScorePct: 100,
      }),
    );
    expect(avec).toBe(sans);
  });

  it('⛔ le terme leçons lit les COURS PRINCIPAUX, jamais toutes les leçons', () => {
    // `lessonsCompleted/lessonsTotal` compte TOUTES les leçons de la categorie
    // (911 pour le permis B, cours annexes compris). Le score doit suivre le
    // couple que le candidat lit sur son accueil (« Leçons lues X/507 »), sans
    // quoi le chiffre affiche et le chiffre qui compte divergent.
    expect(
      computeGlobalScore(agg({ lessonsCompleted: 911, lessonsTotal: 911 })),
    ).toBe(0);
  });

  it('ignore les compteurs à zéro (pas de division par 0)', () => {
    // Seul mastery contribue : 90% × (50/50 × 100) = 90
    expect(
      computeGlobalScore(agg({ questionsMastered: 50, questionsTotal: 50 })),
    ).toBe(90);
  });

  it('subjectAverageScorePct est ignoré par la formule (plus de terme "moyenne" depuis D-65)', () => {
    const base = {
      questionsMastered: 100,
      questionsTotal: 100,
      mainLessonsCompleted: 100,
      mainLessonsTotal: 100,
    };
    expect(computeGlobalScore(agg({ ...base }))).toBe(100);
    // valeur arbitraire, ne doit rien changer
    expect(
      computeGlobalScore(agg({ ...base, subjectAverageScorePct: 12 })),
    ).toBe(100);
  });

  it('tronque vers le bas (floor) et les poids somment à 1', () => {
    expect(
      computeGlobalScore(
        agg({
          questionsMastered: 99,
          questionsTotal: 100,
          mainLessonsCompleted: 100,
          mainLessonsTotal: 100,
        }),
      ),
    ).toBeLessThanOrEqual(100);
    expect(WEIGHT_MASTERY + WEIGHT_LESSONS + WEIGHT_SUBJECTS).toBeCloseTo(1);
  });

  it('READINESS_THRESHOLD est exporté à 70', () => {
    expect(READINESS_THRESHOLD).toBe(70);
  });

  it('SUBJECT_CREDIT_FLOOR_PCT EST le seuil officiel partagé, pas une valeur dupliquée', () => {
    // exam-rules.constants.ts : SUBJECT_CREDIT_FLOOR_PCT doit referencer
    // OFFICIAL_EXAM_PASS_SCORE_PERCENT plutot que de le recopier - sinon les
    // deux peuvent diverger silencieusement a la prochaine revision du seuil.
    expect(SUBJECT_CREDIT_FLOOR_PCT).toBe(OFFICIAL_EXAM_PASS_SCORE_PERCENT);
  });
});

describe('Définition unique de la formule (garde anti-duplication)', () => {
  it("n'existe nulle part ailleurs dans apps/api/src qu'une redéclaration des poids D-78", () => {
    // Racine apps/api/src, deux niveaux au-dessus de ce fichier
    // (modules/progression/app/ -> apps/api/src).
    const srcRoot = join(__dirname, '..', '..', '..');
    const offenders = findWeightDeclarations(srcRoot);
    expect(offenders).toEqual([]);
  });

  /**
   * Le garde ci-dessus ne scanne QUE `apps/api/src`. Resultat : les poids
   * recopies dans `prisma/scripts/set-global-progression.ts` ont dormi sur les
   * valeurs de D-65 pendant que la formule passait a D-78, et le script aurait
   * seede des scores faux sans que rien ne bronche (constate le 2026-09-20).
   *
   * Ce script ne PEUT pas importer le service (ses alias tsconfig ne sont pas
   * resolus dans l'image conteneur, cf. son en-tete) : la recopie est assumee,
   * c'est sa DERIVE qui ne doit pas l'etre. On verifie donc l'egalite des
   * valeurs, sans exiger l'import.
   */
  it('les poids recopiés dans prisma/scripts/set-global-progression.ts valent ceux du service', () => {
    const scriptPath = join(
      __dirname,
      '..',
      '..',
      '..',
      '..',
      '..',
      '..',
      'prisma',
      'scripts',
      'set-global-progression.ts',
    );
    const content = readFileSync(scriptPath, 'utf-8');
    const weightOf = (name: string): number => {
      const match = new RegExp(`const ${name} = ([\\d.]+);`).exec(content);
      if (!match) throw new Error(`${name} introuvable dans ${scriptPath}`);
      return Number(match[1]);
    };
    expect(weightOf('WEIGHT_MASTERY')).toBe(WEIGHT_MASTERY);
    expect(weightOf('WEIGHT_LESSONS')).toBe(WEIGHT_LESSONS);
    expect(weightOf('WEIGHT_SUBJECTS')).toBe(WEIGHT_SUBJECTS);
  });
});

describe('scoreOn20', () => {
  it('null → null', () => {
    expect(scoreOn20(null)).toBeNull();
  });

  it('0 → 0', () => {
    expect(scoreOn20(0)).toBe(0);
  });

  it('100 → 20', () => {
    expect(scoreOn20(100)).toBe(20);
  });

  it('50 → 10', () => {
    expect(scoreOn20(50)).toBe(10);
  });

  it('tronque vers le bas (75 → 15)', () => {
    expect(scoreOn20(75)).toBe(15);
  });

  it('tronque (79 → 15.8 → 15)', () => {
    expect(scoreOn20(79)).toBe(15);
  });
});

describe('subjectCredit', () => {
  it('nul sous le plancher (< 70%, soit < 14/20)', () => {
    expect(subjectCredit(0)).toBe(0);
    expect(subjectCredit(69)).toBe(0);
    expect(subjectCredit(SUBJECT_CREDIT_FLOOR_PCT - 1)).toBe(0);
  });

  it('crédit partiel continu entre 70% et 80% (14 à 16/20)', () => {
    expect(subjectCredit(70)).toBeCloseTo(0);
    expect(subjectCredit(75)).toBeCloseTo(0.4);
    expect(subjectCredit(79)).toBeCloseTo(0.72);
  });

  it('vaut exactement 0.8 au seuil de réussite (80%, 16/20)', () => {
    expect(subjectCredit(SUBJECT_PASS_THRESHOLD_PCT)).toBeCloseTo(
      SUBJECT_PASS_BASE_CREDIT,
    );
  });

  it('bonus de qualité continu entre 80% et 100% (16 à 20/20)', () => {
    expect(subjectCredit(85)).toBeCloseTo(0.85);
    expect(subjectCredit(90)).toBeCloseTo(0.9);
    expect(subjectCredit(95)).toBeCloseTo(0.95);
  });

  it('vaut 1.0 à la note parfaite (100%, 20/20)', () => {
    expect(subjectCredit(100)).toBeCloseTo(1.0);
  });

  it("est continue au seuil de réussite (pas de marche d'escalier)", () => {
    const justBelow = subjectCredit(SUBJECT_PASS_THRESHOLD_PCT - 0.001);
    const at = subjectCredit(SUBJECT_PASS_THRESHOLD_PCT);
    expect(Math.abs(at - justBelow)).toBeLessThan(0.001);
  });
});
