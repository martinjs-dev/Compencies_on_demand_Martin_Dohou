// =============================================================================
// Score Calculator - Formule de progression candidat (D-65, 2026-08-04).
// Remplace la formule v6 (4 composantes) par une formule à 3 composantes.
// Partagée entre monitor-home, candidate-home (via import direct pour les
// consommateurs qui l'utilisent déjà), l'annuaire candidats moniteur et le
// module progression. Fonctions pures, sans dépendance.
// =============================================================================

import { OFFICIAL_EXAM_PASS_SCORE_PERCENT } from '../../../common/constants/exam-rules.constants';

/**
 * Agrégats nécessaires au calcul du globalScore d'un candidat.
 * Tous les compteurs sont scopés à la catégorie de permis du candidat
 * (ou globaux si User.permitCategory est null).
 */
export interface CandidateAggregates {
  questionsMastered: number;
  questionsTotal: number;
  /**
   * ⚠️ TOUTES les leçons de la catégorie, cours principaux ou non.
   * N'EST PLUS utilisé par `computeGlobalScore` depuis D-78 : le terme leçons
   * porte désormais sur les seuls COURS PRINCIPAUX (`mainLessons*` ci-dessous),
   * parce que c'est ce couple-là, et lui seul, que le candidat voit sur son
   * accueil - le chiffre affiché et le chiffre qui compte doivent être le même.
   * Conservé pour les appelants qui l'exposent par ailleurs.
   */
  lessonsCompleted: number;
  lessonsTotal: number;
  /**
   * Leçons lues / total des leçons des COURS PRINCIPAUX de la catégorie
   * (`mainCourseChapterFilter`). LE terme leçons de la formule depuis D-78.
   */
  mainLessonsCompleted: number;
  mainLessonsTotal: number;
  /**
   * ⚠️ N'EST PLUS utilisé par `computeGlobalScore` depuis D-78 : les sujets
   * sont sortis de la formule. Ils n'en ont pas disparu pour autant - un sujet
   * est fait de QUESTIONS, donc le traiter fait monter la maîtrise, qui pèse
   * 90 %. Les compter en plus, c'était les compter deux fois.
   * Conservé : plusieurs appelants exposent ce couple à l'écran.
   */
  subjectsCompleted: number;
  subjectsTotal: number;
  /**
   * Moyenne des % (0-100) sur les SUBJECT validés. null si aucun.
   * Conservé pour compatibilité de type avec les appelants existants
   * (monitors, monitor-home, monitor-groups) mais N'EST PLUS utilisé par
   * `computeGlobalScore` depuis D-65 : la formule à 3 composantes n'a plus
   * de terme "moyenne" distinct (voir DECISIONS-RETOURS-TERRAIN.md, D-65).
   */
  subjectAverageScorePct: number | null;
}

// Pondération D-78 (2026-09-20) : maîtrise 90%, leçons 10%.
// Remplace D-65 (maîtrise 50 / leçons 15 / sujets 35), qui remplaçait elle-même
// la formule v6 (mastery 55 / lessons 25 / subjects 10 / average 10).
//
// Motif de Martin, qui POUSSE À SON TERME celui de D-65 : « je voudrais bien
// que 90 % soit calculé sur la couverture des questions - sur la dernière
// tentative sur une question, s'il a trouvé la bonne réponse, c'est que c'est
// bon ». L'examen du permis EST un QCM : la couverture des questions n'est pas
// un indicateur parmi d'autres du résultat réel, c'est le résultat réel.
//
// ⚠️ Les SUJETS sortent de la formule, et ce n'est pas un oubli. Un sujet est
// fait de questions : le traiter fait monter la maîtrise. Lui garder un terme
// propre, c'était compter la même chose deux fois.
//
// Les LEÇONS gardent 10 %, sur les seuls COURS PRINCIPAUX - le couple exact
// que le candidat lit sur son accueil (tuile « Leçons lues »). Un candidat qui
// lit tout sans jamais répondre à une question plafonne donc à 10 %, c'est
// voulu, et c'est plus sévère que les 15 % de D-65.
export const WEIGHT_MASTERY = 0.9;
export const WEIGHT_LESSONS = 0.1;
/**
 * @deprecated D-78 (2026-09-20) : les sujets ne pèsent plus dans le score.
 * Laissé à 0 plutôt que supprimé pour que tout appelant resté sur l'ancienne
 * pondération donne un résultat FAUX de façon visible (un terme qui s'annule)
 * plutôt que de ne plus compiler pendant un déploiement en deux temps.
 */
export const WEIGHT_SUBJECTS = 0;

/** Seuil de "candidat prêt" pour readinessRate du dashboard moniteur. */
export const READINESS_THRESHOLD = 70;

/**
 * Calcule le score global d'un candidat (0-100, entier tronqué).
 * Pondération D-78 : 90% couverture des questions, 10% leçons des cours
 * principaux. Les deux termes sont scopés à la CATÉGORIE du candidat.
 *
 * « Couverture des questions » = parmi les questions actives que sa catégorie
 * concerne, celles dont la DERNIÈRE réponse du candidat est juste
 * (`questionsMastered`, calculé en SQL par un `DISTINCT ON (questionId)`
 * trié par `answeredAt DESC`). Se tromper puis revenir dessus et réussir
 * compte comme maîtrisé ; réussir puis se retromper ne compte plus.
 */
export function computeGlobalScore(agg: CandidateAggregates): number {
  const masteryPct =
    agg.questionsTotal > 0
      ? (agg.questionsMastered / agg.questionsTotal) * 100
      : 0;
  const lessonsPct =
    agg.mainLessonsTotal > 0
      ? (agg.mainLessonsCompleted / agg.mainLessonsTotal) * 100
      : 0;
  return Math.floor(WEIGHT_MASTERY * masteryPct + WEIGHT_LESSONS * lessonsPct);
}

/**
 * Convertit un score 0-100 vers une note 0-20 (entier tronqué).
 * null en entrée → null en sortie (aucune donnée).
 */
export function scoreOn20(score100: number | null): number | null {
  if (score100 === null) return null;
  return Math.floor((score100 * 20) / 100);
}

// -----------------------------------------------------------------------------
// Crédit d'un sujet (D-65 point 3, docs/specs/progression-algorithm.md §4.3).
// Fonction PURE, testée, mais PAS ENCORE câblée dans `subjectsCompleted`
// (voir le rapport de livraison CAD-09/backend pour le détail : le câblage
// touche findHomeAggregates/findHomeAggregatesBatch, consommés par des
// modules hors périmètre de cette vague - candidates, monitors). Exposée ici
// pour que l'agent qui fera ce câblage n'ait pas à redéfinir la courbe.
// -----------------------------------------------------------------------------

/** "Sujet réussi" = dernière note >= 16/20 (80%). */
export const SUBJECT_PASS_THRESHOLD_PCT = 80;
/**
 * Plancher du crédit partiel = 14/20 (70%), seuil officiel de l'examen.
 * EST le seuil officiel (`OFFICIAL_EXAM_PASS_SCORE_PERCENT`), donc référence
 * la constante partagée plutôt que de la dupliquer (cf. exam-rules.constants.ts).
 */
export const SUBJECT_CREDIT_FLOOR_PCT = OFFICIAL_EXAM_PASS_SCORE_PERCENT;
/** Crédit d'un sujet tout juste réussi (au seuil de 16/20). */
export const SUBJECT_PASS_BASE_CREDIT = 0.8;

/**
 * Crédit d'un sujet selon sa dernière note (pourcentage 0-100) → [0, 1].
 * - < 70% (14/20) : nul.
 * - 70-80% (14-16/20) : crédit partiel progressif ("presque").
 * - >= 80% (16/20) : réussi, avec bonus de qualité jusqu'à 1.0 à 20/20.
 * Continue au seuil de réussite (pas de marche d'escalier), cf. D-65 point 3.
 */
export function subjectCredit(percentageScore: number): number {
  if (percentageScore < SUBJECT_CREDIT_FLOOR_PCT) return 0;
  if (percentageScore < SUBJECT_PASS_THRESHOLD_PCT) {
    return (
      SUBJECT_PASS_BASE_CREDIT *
      ((percentageScore - SUBJECT_CREDIT_FLOOR_PCT) /
        (SUBJECT_PASS_THRESHOLD_PCT - SUBJECT_CREDIT_FLOOR_PCT))
    );
  }
  return (
    SUBJECT_PASS_BASE_CREDIT +
    (1 - SUBJECT_PASS_BASE_CREDIT) *
      ((percentageScore - SUBJECT_PASS_THRESHOLD_PCT) /
        (100 - SUBJECT_PASS_THRESHOLD_PCT))
  );
}
