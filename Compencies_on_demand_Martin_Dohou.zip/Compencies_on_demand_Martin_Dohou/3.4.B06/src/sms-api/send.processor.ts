import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { PrismaService } from '../../../common/prisma/prisma.service';
import { SEND_QUEUE, SendJobData } from '../domain/queue.constants';
import { DeliveryService } from '../app/delivery.service';

/**
 * La chaine de repli vit dans DeliveryService, pas dans les reessais BullMQ :
 * un reessai de job reprendrait la sequence depuis le debut, alors que la
 * cascade doit avancer de passerelle en passerelle sans repasser par les
 * precedentes.
 */
@Processor(SEND_QUEUE, { concurrency: 10 })
export class SendProcessor extends WorkerHost {
  private readonly logger = new Logger(SendProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly delivery: DeliveryService,
  ) {
    super();
  }

  async process(job: Job<SendJobData>): Promise<void> {
    const message = await this.prisma.message.findUnique({ where: { id: job.data.messageId } });

    if (!message) {
      this.logger.error(`Message ${job.data.messageId} introuvable, job abandonne`);
      return;
    }

    await this.delivery.deliver(message);
  }
}
