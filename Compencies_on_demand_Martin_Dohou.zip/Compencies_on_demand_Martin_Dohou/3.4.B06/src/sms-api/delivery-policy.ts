import { MessageType } from '@prisma/client';

export interface DeliveryPolicy {
  /** Budget de latence d'une tentative, avant passage au repli. */
  timeoutMs: number;
  /** Un OTP ignore l'opt-out : c'est un message transactionnel demande par l'usager. */
  respectsOptOut: boolean;
  /** Nombre maximal de passerelles du pool a essayer. */
  maxAttempts: number;
  /** Priorite BullMQ, la plus basse passe en premier. */
  queuePriority: number;
}

/**
 * Traduction du tableau de la section 4 de l'architecture. C'est le seul
 * endroit ou le type d'un message devient un comportement : les adaptateurs
 * n'en savent rien, ils recoivent un budget deja calcule.
 *
 * Le budget d'un OTP est court a dessein : la facade doit rendre son echec
 * assez tot pour que le projet appelant ait encore le temps d'essayer son
 * propre fournisseur avant que l'utilisateur n'abandonne.
 */
export const DELIVERY_POLICIES: Record<MessageType, DeliveryPolicy> = {
  [MessageType.OTP]: {
    timeoutMs: 4_000,
    respectsOptOut: false,
    maxAttempts: 3,
    queuePriority: 1,
  },
  [MessageType.NOTIFICATION]: {
    timeoutMs: 30_000,
    respectsOptOut: true,
    maxAttempts: 2,
    queuePriority: 5,
  },
  [MessageType.MARKETING]: {
    timeoutMs: 300_000,
    respectsOptOut: true,
    maxAttempts: 1,
    queuePriority: 10,
  },
};
