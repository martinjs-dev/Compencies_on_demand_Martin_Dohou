import { GatewayKind, MessageType, Operator } from '@prisma/client';
import { PrismaService } from '../../../common/prisma/prisma.service';
import { GatewayRouterService } from './gateway-router.service';

const RECIPIENT = '2290159001550';

type GatewayRow = {
  id: string;
  name: string;
  kind: GatewayKind;
  devices: Array<Record<string, unknown>>;
};

function buildRouter(gateways: GatewayRow[], attemptsToday = 0) {
  const prisma = {
    gateway: { findMany: jest.fn().mockResolvedValue(gateways) },
    messageAttempt: { count: jest.fn().mockResolvedValue(attemptsToday) },
  } as unknown as PrismaService;

  return new GatewayRouterService(prisma);
}

const sim = (overrides: Record<string, unknown> = {}) => ({
  id: 'd1',
  operator: Operator.SBIN,
  simSubscriptionId: 3,
  dailySendLimit: -1,
  ...overrides,
});

describe('GatewayRouterService.plan', () => {
  it('ecarte une passerelle TextBee dont aucune SIM n est utilisable', async () => {
    // Le cas qui produisait un NO_DEVICE a l'envoi : la requete a deja filtre
    // les SIM inactives ou desactivees, la liste arrive donc vide.
    const router = buildRouter([
      { id: 'g1', name: 'TextBee', kind: GatewayKind.TEXTBEE, devices: [] },
    ]);

    await expect(router.plan(RECIPIENT, MessageType.OTP, Operator.MTN)).resolves.toEqual(
      [],
    );
  });

  it('retient une passerelle sans parc qui n en a pas besoin', async () => {
    const router = buildRouter([
      { id: 'g2', name: 'Lien SMPP', kind: GatewayKind.SMPP, devices: [] },
    ]);

    const plans = await router.plan(RECIPIENT, MessageType.OTP, Operator.MTN);

    expect(plans).toHaveLength(1);
    expect(plans[0].device).toBeUndefined();
  });

  it('retient une passerelle TextBee avec une SIM disponible', async () => {
    const router = buildRouter([
      {
        id: 'g1',
        name: 'TextBee',
        kind: GatewayKind.TEXTBEE,
        devices: [sim()],
      },
    ]);

    const plans = await router.plan(RECIPIENT, MessageType.OTP, Operator.MTN);

    expect(plans).toHaveLength(1);
    expect(plans[0].device).toEqual(expect.objectContaining({ id: 'd1' }));
  });

  it('prefere une SIM du meme operateur que le destinataire', async () => {
    const router = buildRouter([
      {
        id: 'g1',
        name: 'TextBee',
        kind: GatewayKind.TEXTBEE,
        devices: [
          sim({ id: 'celtiis', operator: Operator.SBIN }),
          sim({ id: 'mtn', operator: Operator.MTN }),
        ],
      },
    ]);

    const plans = await router.plan(RECIPIENT, MessageType.OTP, Operator.MTN);

    expect(plans[0].device).toEqual(expect.objectContaining({ id: 'mtn' }));
  });

  it('ecarte la passerelle quand toutes ses SIM ont atteint leur quota', async () => {
    const router = buildRouter(
      [
        {
          id: 'g1',
          name: 'TextBee',
          kind: GatewayKind.TEXTBEE,
          devices: [sim({ dailySendLimit: 10 })],
        },
      ],
      10,
    );

    await expect(router.plan(RECIPIENT, MessageType.OTP, Operator.MTN)).resolves.toEqual(
      [],
    );
  });
});
