import { generateApiKey, hashApiKey, matchesHash, parseApiKey } from './api-key';

describe('parseApiKey', () => {
  it('accepte une cle dont le secret contient le caractere de separation', () => {
    // Cas qui rendait une cle sur deux inutilisable : base64url produit des
    // underscores, et le decoupage naif les prenait pour des separateurs.
    expect(parseApiKey('osk_139d899f_4bI_XyZ-01')).toEqual({ prefix: '139d899f' });
  });

  it('accepte une cle sans separateur dans le secret', () => {
    expect(parseApiKey('osk_139d899f_4bIXyZ01')).toEqual({ prefix: '139d899f' });
  });

  it('rejette un prefixe de longueur incorrecte', () => {
    expect(parseApiKey('osk_139d89_secret')).toBeNull();
  });

  it('rejette un prefixe qui n est pas hexadecimal', () => {
    expect(parseApiKey('osk_139d899z_secret')).toBeNull();
  });

  it('rejette une cle sans secret', () => {
    expect(parseApiKey('osk_139d899f_')).toBeNull();
  });

  it('rejette une cle d un autre service', () => {
    expect(parseApiKey('sk_139d899f_secret')).toBeNull();
  });
});

describe('generateApiKey', () => {
  it('produit des cles que parseApiKey reconnait toutes', () => {
    // Un secret de 43 caracteres base64url contient un underscore une fois sur
    // deux environ : cent tirages suffisent a rattraper toute regression.
    for (let i = 0; i < 100; i++) {
      const key = generateApiKey();
      expect(parseApiKey(key.plainKey)).toEqual({ prefix: key.prefix });
      expect(matchesHash(key.plainKey, key.hashedKey)).toBe(true);
    }
  });

  it('stocke le condensat, jamais la cle', () => {
    const key = generateApiKey();
    expect(key.hashedKey).toBe(hashApiKey(key.plainKey));
    expect(key.hashedKey).not.toContain(key.plainKey);
  });
});

describe('matchesHash', () => {
  it('rejette un condensat de longueur differente', () => {
    expect(matchesHash('osk_139d899f_secret', 'ab12')).toBe(false);
  });

  it('rejette une cle voisine', () => {
    const key = generateApiKey();
    expect(matchesHash(`${key.plainKey}x`, key.hashedKey)).toBe(false);
  });
});
