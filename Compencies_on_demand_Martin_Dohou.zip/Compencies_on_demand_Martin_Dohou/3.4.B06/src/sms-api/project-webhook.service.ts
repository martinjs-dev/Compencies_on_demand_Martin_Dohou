import { Injectable, Logger } from '@nestjs/common';
import { Message } from '@prisma/client';
import axios from 'axios';
import { createHmac } from 'node:crypto';
import { PrismaService } from '../../../common/prisma/prisma.service';
import { MessageResponseDto } from './dto/message-response.dto';

const DELIVERY_TIMEOUT_MS = 10_000;

/**
 * Notification sortante vers le projet proprietaire du message, signee sur le
 * meme principe que celle de TextBee vers nous.
 *
 * L'echec de notification n'est jamais propage a l'appelant : un projet dont
 * le webhook est casse ne doit pas empecher la mise a jour des statuts des
 * autres projets.
 */
@Injectable()
export class ProjectWebhookService {
  private readonly logger = new Logger(ProjectWebhookService.name);

  constructor(private readonly prisma: PrismaService) {}

  async notify(message: Message): Promise<void> {
    const project = await this.prisma.project.findUnique({
      where: { id: message.projectId },
      select: { webhookUrl: true, webhookSigningSecret: true, slug: true },
    });

    if (!project?.webhookUrl || !project.webhookSigningSecret) {
      return;
    }

    // Le corps du message n'est jamais renvoye : il contient des codes a
    // usage unique, et le projet le connait deja, il l'a ecrit.
    const payload = { event: 'message.status', data: MessageResponseDto.from(message) };
    const body = JSON.stringify(payload);
    const signature = createHmac('sha256', project.webhookSigningSecret)
      .update(body)
      .digest('hex');

    try {
      await axios.post(project.webhookUrl, body, {
        headers: { 'Content-Type': 'application/json', 'X-Signature': signature },
        timeout: DELIVERY_TIMEOUT_MS,
      });
    } catch (error) {
      this.logger.warn(
        `Webhook du projet ${project.slug} en echec pour le message ${message.id} : ` +
          describe(error),
      );
    }
  }
}

function describe(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}
