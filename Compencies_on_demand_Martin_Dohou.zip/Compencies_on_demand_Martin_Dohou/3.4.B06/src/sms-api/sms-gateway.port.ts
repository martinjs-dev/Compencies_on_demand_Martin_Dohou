import { GatewayKind, MessageType, Operator } from '@prisma/client';

export interface GatewaySendRequest {
  /** E.164 sans le plus, tel que stocke. */
  recipient: string;
  body: string;
  type: MessageType;
  operator: Operator;
  /** Identifiant de l'appareil chez le fournisseur, quand la passerelle en a. */
  providerDeviceId?: string;
  simSubscriptionId?: number;
  /** Delai au-dela duquel l'appelant passera au repli. */
  timeoutMs: number;
}

export interface GatewaySendResult {
  /** Identifiant du message chez le fournisseur, quand il en renvoie un. */
  providerMessageId?: string;
  /**
   * Identifiant de lot. Avec la file activee, TextBee ne renvoie que celui-ci :
   * c'est par lui que ses webhooks de statut se correlent a nos messages.
   */
  providerBatchId?: string;
}

export class GatewaySendError extends Error {
  constructor(
    readonly code: string,
    message: string,
    readonly retryable = true,
  ) {
    super(message);
  }
}

/**
 * Contrat que toute passerelle doit remplir. C'est ce qui rend le fournisseur
 * remplacable : un lien SMPP direct viendra s'y conformer sans qu'aucun projet
 * client ne bouge.
 */
export interface SmsGatewayPort {
  readonly kind: GatewayKind;

  /** Leve GatewaySendError en cas d'echec ; ne retourne jamais un echec silencieux. */
  send(request: GatewaySendRequest): Promise<GatewaySendResult>;

  /** Appele par le health check uniquement, jamais dans le chemin d'envoi. */
  ping(): Promise<boolean>;
}

/** Passerelle capable de decrire son parc de SIM. */
export interface DiscoverableGateway {
  listDevices(): Promise<DiscoveredDevice[]>;
}

export interface DiscoveredDevice {
  providerDeviceId: string;
  label?: string;
  enabled: boolean;
  lastSeenAt?: Date;
  sims: DiscoveredSim[];
}

export interface DiscoveredSim {
  subscriptionId: number;
  slotIndex?: number;
  carrierName?: string;
  mcc?: string;
  mnc?: string;
}
