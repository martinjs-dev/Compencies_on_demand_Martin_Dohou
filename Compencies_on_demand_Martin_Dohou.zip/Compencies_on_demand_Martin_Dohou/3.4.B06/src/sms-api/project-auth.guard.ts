import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { Request } from 'express';
import { AuthenticatedProject, ProjectsService } from '../app/projects.service';

export interface RequestWithProject extends Request {
  project: AuthenticatedProject;
}

/**
 * Point de cloisonnement unique du service : c'est ici que la cle devient un
 * projectId, et toute lecture en aval est filtree dessus. Rien d'autre dans
 * le code ne doit deriver un projet de la requete.
 */
@Injectable()
export class ProjectAuthGuard implements CanActivate {
  constructor(private readonly projects: ProjectsService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<RequestWithProject>();
    const key = extractKey(request);

    if (!key) {
      throw new UnauthorizedException('Cle API manquante');
    }

    const project = await this.projects.authenticate(key);
    if (!project) {
      throw new UnauthorizedException('Cle API invalide');
    }

    request.project = project;
    return true;
  }
}

function extractKey(request: Request): string | undefined {
  const authorization = request.headers.authorization;
  if (authorization?.startsWith('Bearer ')) {
    return authorization.slice('Bearer '.length).trim();
  }

  const header = request.headers['x-api-key'];
  return typeof header === 'string' ? header.trim() : undefined;
}
