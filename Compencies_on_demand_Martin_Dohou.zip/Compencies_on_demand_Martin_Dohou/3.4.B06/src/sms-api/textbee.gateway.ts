import { Logger } from '@nestjs/common';
import { GatewayKind } from '@prisma/client';
import axios, { AxiosInstance, isAxiosError } from 'axios';
import { toE164 } from '../../../common/phone/phone';
import {
  DiscoverableGateway,
  DiscoveredDevice,
  GatewaySendError,
  GatewaySendRequest,
  GatewaySendResult,
  SmsGatewayPort,
} from '../domain/sms-gateway.port';

interface TextBeeSendResponse {
  data?: {
    success?: boolean;
    smsBatchId?: string;
    recipientCount?: number;
    successCount?: number;
  };
}

interface TextBeeDeviceResponse {
  data?: Array<{
    _id: string;
    name?: string;
    model?: string;
    enabled?: boolean;
    lastHeartbeat?: string;
    simInfo?: {
      sims?: Array<{
        subscriptionId: number;
        simSlotIndex?: number;
        carrierName?: string;
        mcc?: string;
        mnc?: string;
      }>;
    };
  }>;
}

/**
 * Adaptateur TextBee. Un seul destinataire par appel : la facade tient un
 * message par destinataire, et le lot renvoye par TextBee sert uniquement
 * de cle de correlation pour ses webhooks.
 */
export class TextBeeGateway implements SmsGatewayPort, DiscoverableGateway {
  readonly kind = GatewayKind.TEXTBEE;

  private readonly logger = new Logger(TextBeeGateway.name);
  private readonly http: AxiosInstance;

  constructor(baseUrl: string, apiKey: string) {
    this.http = axios.create({
      baseURL: `${baseUrl.replace(/\/+$/, '')}/api/v1/gateway`,
      headers: { 'x-api-key': apiKey },
    });
  }

  async send(request: GatewaySendRequest): Promise<GatewaySendResult> {
    if (!request.providerDeviceId) {
      throw new GatewaySendError('NO_DEVICE', 'Aucun appareil disponible', false);
    }

    try {
      const { data } = await this.http.post<TextBeeSendResponse>(
        `/devices/${request.providerDeviceId}/send-sms`,
        {
          recipients: [toE164(request.recipient)],
          message: request.body,
          ...(request.simSubscriptionId !== undefined
            ? { simSubscriptionId: request.simSubscriptionId }
            : {}),
        },
        { timeout: request.timeoutMs },
      );

      const batchId = data?.data?.smsBatchId;
      if (!batchId) {
        throw new GatewaySendError('NO_BATCH_ID', 'Reponse TextBee sans identifiant de lot');
      }

      return { providerBatchId: batchId };
    } catch (error) {
      throw toGatewayError(error);
    }
  }

  async ping(): Promise<boolean> {
    try {
      await this.http.get('/devices', { timeout: 5000 });
      return true;
    } catch (error) {
      this.logger.warn(`Health check TextBee en echec : ${describe(error)}`);
      return false;
    }
  }

  async listDevices(): Promise<DiscoveredDevice[]> {
    const { data } = await this.http.get<TextBeeDeviceResponse>('/devices', { timeout: 10000 });

    return (data?.data ?? []).map((device) => ({
      providerDeviceId: device._id,
      label: device.name ?? device.model,
      enabled: device.enabled ?? false,
      lastSeenAt: device.lastHeartbeat ? new Date(device.lastHeartbeat) : undefined,
      sims: (device.simInfo?.sims ?? []).map((sim) => ({
        subscriptionId: sim.subscriptionId,
        slotIndex: sim.simSlotIndex,
        carrierName: sim.carrierName,
        mcc: sim.mcc,
        mnc: sim.mnc,
      })),
    }));
  }
}

function toGatewayError(error: unknown): GatewaySendError {
  if (error instanceof GatewaySendError) {
    return error;
  }

  if (isAxiosError(error)) {
    if (error.code === 'ECONNABORTED') {
      return new GatewaySendError('TIMEOUT', 'Budget de latence depasse');
    }

    const status = error.response?.status;
    const detail =
      (error.response?.data as { error?: string } | undefined)?.error ?? error.message;

    // Un 4xx signale une requete invalide ou un appareil hors service :
    // rejouer a l'identique ne changerait rien.
    const retryable = status === undefined || status >= 500 || status === 429;
    return new GatewaySendError(`HTTP_${status ?? 'NETWORK'}`, detail, retryable);
  }

  return new GatewaySendError('UNKNOWN', describe(error));
}

function describe(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}
