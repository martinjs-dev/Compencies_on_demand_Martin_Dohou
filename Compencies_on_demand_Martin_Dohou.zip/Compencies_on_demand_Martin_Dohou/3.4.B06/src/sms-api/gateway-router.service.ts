import { Injectable, Logger } from '@nestjs/common';
import {
  Gateway,
  GatewayDevice,
  GatewayKind,
  MessageType,
  Operator,
} from '@prisma/client';
import { countryCodeOf } from '../../../common/phone/phone';
import { PrismaService } from '../../../common/prisma/prisma.service';

/** Une tentative possible, dans l'ordre ou la chaine de livraison les essaiera. */
export interface RoutePlan {
  gateway: Gateway;
  device?: GatewayDevice;
}

@Injectable()
export class GatewayRouterService {
  private readonly logger = new Logger(GatewayRouterService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Ordonne les tentatives pour un destinataire donne.
   *
   * Le destinataire decide d'abord de la passerelle, puis seulement de la SIM :
   *   destinataire -> indicatif pays -> passerelle -> operateur -> appareil -> SIM
   *
   * Les passerelles a couverture mondiale, sans indicatif declare, restent
   * candidates pour tout le monde : ce sont les replis.
   */
  async plan(recipient: string, type: MessageType, operator: Operator): Promise<RoutePlan[]> {
    const countryCode = countryCodeOf(recipient);

    const gateways = await this.prisma.gateway.findMany({
      where: {
        isActive: true,
        servesTypes: { has: type },
        OR: [
          { countryCodes: { isEmpty: true } },
          ...(countryCode ? [{ countryCodes: { has: countryCode } }] : []),
        ],
      },
      orderBy: { priority: 'asc' },
      include: {
        devices: {
          where: { isActive: true, enabled: true, servesTypes: { has: type } },
        },
      },
    });

    const plans: RoutePlan[] = [];

    for (const gateway of gateways) {
      const { devices, ...bare } = gateway;

      // Une passerelle sans parc, comme un lien SMPP, s'appelle telle quelle.
      // Une passerelle TextBee, elle, n'existe QUE par ses SIM : la retenir
      // sans appareil produisait un NO_DEVICE au moment de l'envoi, c'est a
      // dire une tentative perdue, une alerte, et un retard sur le repli,
      // pour une passerelle dont on savait deja qu'elle ne pouvait rien.
      if (devices.length === 0) {
        if (gateway.kind === GatewayKind.TEXTBEE) {
          this.logger.warn(
            `${gateway.name} ecartee : aucune SIM active et autorisee pour ce type de message`,
          );
          continue;
        }

        plans.push({ gateway: bare });
        continue;
      }

      const device = await this.pickDevice(devices, operator);
      if (device) {
        plans.push({ gateway: bare, device });
      } else {
        this.logger.warn(
          `${gateway.name} ecartee : toutes ses SIM ont atteint leur quota du jour`,
        );
      }
    }

    return plans;
  }

  /**
   * Choisit une SIM. Le routage on-net passe avant tout : une SIM du meme
   * operateur que le destinataire coute moins cher et se remet mieux. A
   * defaut, n'importe quelle SIM disponible fait l'affaire.
   *
   * Les SIM ayant atteint leur quota du jour sont ecartees : le but est de
   * ne pas se faire couper par l'operateur.
   */
  private async pickDevice(
    devices: GatewayDevice[],
    operator: Operator,
  ): Promise<GatewayDevice | undefined> {
    const onNet = devices.filter((device) => device.operator === operator);
    const ordered = operator === Operator.UNKNOWN ? devices : [...onNet, ...devices];

    const seen = new Set<string>();
    for (const device of ordered) {
      if (seen.has(device.id)) {
        continue;
      }
      seen.add(device.id);

      if (await this.hasQuotaLeft(device)) {
        return device;
      }
    }

    return undefined;
  }

  private async hasQuotaLeft(device: GatewayDevice): Promise<boolean> {
    if (device.dailySendLimit < 0) {
      return true;
    }

    const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const sent = await this.prisma.messageAttempt.count({
      where: { deviceId: device.id, startedAt: { gte: since } },
    });

    return sent < device.dailySendLimit;
  }
}
